﻿namespace Restaurant_Reservation_System_FinalProject_26
{
    partial class Form5
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form5));
            this.tabControl1 = new System.Windows.Forms.TabControl();
            this.tabPage2 = new System.Windows.Forms.TabPage();
            this.cbTime_Vino = new System.Windows.Forms.ComboBox();
            this.label20 = new System.Windows.Forms.Label();
            this.lblNoOfSeats_Vino = new System.Windows.Forms.Label();
            this.TxtNoOfGuests_Vino = new System.Windows.Forms.TextBox();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.btnHomeVino = new System.Windows.Forms.Button();
            this.btnSubmit_Vino = new System.Windows.Forms.Button();
            this.txtRequest_Vino = new System.Windows.Forms.TextBox();
            this.label12 = new System.Windows.Forms.Label();
            this.txtOther_Vino = new System.Windows.Forms.TextBox();
            this.label11 = new System.Windows.Forms.Label();
            this.cbReserveType_Vino = new System.Windows.Forms.ComboBox();
            this.label10 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.dateTime_Vino = new System.Windows.Forms.DateTimePicker();
            this.label8 = new System.Windows.Forms.Label();
            this.txtPhone_Vino = new System.Windows.Forms.TextBox();
            this.label7 = new System.Windows.Forms.Label();
            this.txtEmail_Vino = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.LName_Vino = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.txtFName_Vino = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.tabPage3 = new System.Windows.Forms.TabPage();
            this.btnBack_pg2 = new System.Windows.Forms.Button();
            this.tabControl2 = new System.Windows.Forms.TabControl();
            this.tabPage1 = new System.Windows.Forms.TabPage();
            this.btnSkip_Vino = new System.Windows.Forms.Button();
            this.btnNext_Vino = new System.Windows.Forms.Button();
            this.label21 = new System.Windows.Forms.Label();
            this.rtxtAllergies_Vino = new System.Windows.Forms.RichTextBox();
            this.cbAllergies_Vino = new System.Windows.Forms.CheckBox();
            this.groupBox6 = new System.Windows.Forms.GroupBox();
            this.pbDeserts_Vino = new System.Windows.Forms.PictureBox();
            this.cbDesert5_Vino = new System.Windows.Forms.CheckBox();
            this.cbDesert4_Vino = new System.Windows.Forms.CheckBox();
            this.cbDesert3_Vino = new System.Windows.Forms.CheckBox();
            this.cbDesert2_Vino = new System.Windows.Forms.CheckBox();
            this.cbDesert1_Vino = new System.Windows.Forms.CheckBox();
            this.groupBox4 = new System.Windows.Forms.GroupBox();
            this.pbMain_Vino = new System.Windows.Forms.PictureBox();
            this.cbMain8_Vino = new System.Windows.Forms.CheckBox();
            this.cbMain7_Vino = new System.Windows.Forms.CheckBox();
            this.cbMain6_Vino = new System.Windows.Forms.CheckBox();
            this.cbMain5_Vino = new System.Windows.Forms.CheckBox();
            this.cbMain4_Vino = new System.Windows.Forms.CheckBox();
            this.cbMain3_Vino = new System.Windows.Forms.CheckBox();
            this.cbMain2_Vino = new System.Windows.Forms.CheckBox();
            this.cbMain1_Vino = new System.Windows.Forms.CheckBox();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.pbAppetizers_Vino = new System.Windows.Forms.PictureBox();
            this.cbStarter5_Vino = new System.Windows.Forms.CheckBox();
            this.cbStarter4_Vino = new System.Windows.Forms.CheckBox();
            this.cbStarter3_Vino = new System.Windows.Forms.CheckBox();
            this.cbStarter2_Vino = new System.Windows.Forms.CheckBox();
            this.cbStarter1_Vino = new System.Windows.Forms.CheckBox();
            this.tabPage6 = new System.Windows.Forms.TabPage();
            this.btnBack1_Vino = new System.Windows.Forms.Button();
            this.groupBox10 = new System.Windows.Forms.GroupBox();
            this.pbHotBev_Vino = new System.Windows.Forms.PictureBox();
            this.cbHotBev5_Vino = new System.Windows.Forms.CheckBox();
            this.cbHotBev4_Vino = new System.Windows.Forms.CheckBox();
            this.cbHotBev3_Vino = new System.Windows.Forms.CheckBox();
            this.cbHotBev2_Vino = new System.Windows.Forms.CheckBox();
            this.cbHotBev1_Vino = new System.Windows.Forms.CheckBox();
            this.groupBox9 = new System.Windows.Forms.GroupBox();
            this.pbNonBev_Vino = new System.Windows.Forms.PictureBox();
            this.cbNonBev5_Vino = new System.Windows.Forms.CheckBox();
            this.cbNonBev4_Vino = new System.Windows.Forms.CheckBox();
            this.cbNonBev3_Vino = new System.Windows.Forms.CheckBox();
            this.cbNonBev2_Vino = new System.Windows.Forms.CheckBox();
            this.cbNonBev1_Vino = new System.Windows.Forms.CheckBox();
            this.groupBox8 = new System.Windows.Forms.GroupBox();
            this.pbWines_Vino = new System.Windows.Forms.PictureBox();
            this.cbWine5_Vino = new System.Windows.Forms.CheckBox();
            this.cbWine4_Vino = new System.Windows.Forms.CheckBox();
            this.cbWine3_Vino = new System.Windows.Forms.CheckBox();
            this.cbWine2_Vino = new System.Windows.Forms.CheckBox();
            this.cbWine1_Vino = new System.Windows.Forms.CheckBox();
            this.groupBox7 = new System.Windows.Forms.GroupBox();
            this.pbCocktails_Vino = new System.Windows.Forms.PictureBox();
            this.cbCocktail5_Vino = new System.Windows.Forms.CheckBox();
            this.cbCocktail4_Vino = new System.Windows.Forms.CheckBox();
            this.cbCocktail3_Vino = new System.Windows.Forms.CheckBox();
            this.cbcocktail2_Vino = new System.Windows.Forms.CheckBox();
            this.cbcocktail1_Vino = new System.Windows.Forms.CheckBox();
            this.btnRemove_Vino = new System.Windows.Forms.Button();
            this.btnSubmitOrder_Vino = new System.Windows.Forms.Button();
            this.groupBox5 = new System.Windows.Forms.GroupBox();
            this.lbOrder_Vino = new System.Windows.Forms.ListBox();
            this.tabPage4 = new System.Windows.Forms.TabPage();
            this.btnBackVino_pg3 = new System.Windows.Forms.Button();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.btnPay_Vino = new System.Windows.Forms.Button();
            this.lblSubTotal_Vino = new System.Windows.Forms.Label();
            this.lblTotal_Vino = new System.Windows.Forms.Label();
            this.label17 = new System.Windows.Forms.Label();
            this.lbSummary_Vino = new System.Windows.Forms.ListBox();
            this.label19 = new System.Windows.Forms.Label();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.pictureBox3 = new System.Windows.Forms.PictureBox();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.txtCVV_Vino = new System.Windows.Forms.TextBox();
            this.label16 = new System.Windows.Forms.Label();
            this.txtExpirydate_Vino = new System.Windows.Forms.TextBox();
            this.label15 = new System.Windows.Forms.Label();
            this.pbVino_pay = new System.Windows.Forms.PictureBox();
            this.txtcrdNo_Vino = new System.Windows.Forms.TextBox();
            this.label14 = new System.Windows.Forms.Label();
            this.txtcrdholder_Vino = new System.Windows.Forms.TextBox();
            this.label13 = new System.Windows.Forms.Label();
            this.tabPage5 = new System.Windows.Forms.TabPage();
            this.label18 = new System.Windows.Forms.Label();
            this.rtxtReview_Vino = new System.Windows.Forms.RichTextBox();
            this.btnReview_Vino = new System.Windows.Forms.Button();
            this.lbReview_Vino = new System.Windows.Forms.ListBox();
            this.pictureBox5 = new System.Windows.Forms.PictureBox();
            this.tabControl1.SuspendLayout();
            this.tabPage2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.tabPage3.SuspendLayout();
            this.tabControl2.SuspendLayout();
            this.tabPage1.SuspendLayout();
            this.groupBox6.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pbDeserts_Vino)).BeginInit();
            this.groupBox4.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pbMain_Vino)).BeginInit();
            this.groupBox3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pbAppetizers_Vino)).BeginInit();
            this.tabPage6.SuspendLayout();
            this.groupBox10.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pbHotBev_Vino)).BeginInit();
            this.groupBox9.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pbNonBev_Vino)).BeginInit();
            this.groupBox8.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pbWines_Vino)).BeginInit();
            this.groupBox7.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pbCocktails_Vino)).BeginInit();
            this.groupBox5.SuspendLayout();
            this.tabPage4.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.groupBox1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbVino_pay)).BeginInit();
            this.tabPage5.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox5)).BeginInit();
            this.SuspendLayout();
            // 
            // tabControl1
            // 
            this.tabControl1.Controls.Add(this.tabPage2);
            this.tabControl1.Controls.Add(this.tabPage3);
            this.tabControl1.Controls.Add(this.tabPage4);
            this.tabControl1.Controls.Add(this.tabPage5);
            this.tabControl1.Cursor = System.Windows.Forms.Cursors.Hand;
            this.tabControl1.Font = new System.Drawing.Font("Microsoft PhagsPa", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tabControl1.Location = new System.Drawing.Point(12, 12);
            this.tabControl1.Name = "tabControl1";
            this.tabControl1.SelectedIndex = 0;
            this.tabControl1.Size = new System.Drawing.Size(1220, 507);
            this.tabControl1.TabIndex = 1;
            // 
            // tabPage2
            // 
            this.tabPage2.BackColor = System.Drawing.Color.Silver;
            this.tabPage2.BackgroundImage = global::Restaurant_Reservation_System_FinalProject_26.Properties.Resources._330_768x5911;
            this.tabPage2.Controls.Add(this.cbTime_Vino);
            this.tabPage2.Controls.Add(this.label20);
            this.tabPage2.Controls.Add(this.lblNoOfSeats_Vino);
            this.tabPage2.Controls.Add(this.TxtNoOfGuests_Vino);
            this.tabPage2.Controls.Add(this.pictureBox1);
            this.tabPage2.Controls.Add(this.btnHomeVino);
            this.tabPage2.Controls.Add(this.btnSubmit_Vino);
            this.tabPage2.Controls.Add(this.txtRequest_Vino);
            this.tabPage2.Controls.Add(this.label12);
            this.tabPage2.Controls.Add(this.txtOther_Vino);
            this.tabPage2.Controls.Add(this.label11);
            this.tabPage2.Controls.Add(this.cbReserveType_Vino);
            this.tabPage2.Controls.Add(this.label10);
            this.tabPage2.Controls.Add(this.label9);
            this.tabPage2.Controls.Add(this.dateTime_Vino);
            this.tabPage2.Controls.Add(this.label8);
            this.tabPage2.Controls.Add(this.txtPhone_Vino);
            this.tabPage2.Controls.Add(this.label7);
            this.tabPage2.Controls.Add(this.txtEmail_Vino);
            this.tabPage2.Controls.Add(this.label6);
            this.tabPage2.Controls.Add(this.LName_Vino);
            this.tabPage2.Controls.Add(this.label5);
            this.tabPage2.Controls.Add(this.txtFName_Vino);
            this.tabPage2.Controls.Add(this.label4);
            this.tabPage2.Controls.Add(this.label3);
            this.tabPage2.Controls.Add(this.label2);
            this.tabPage2.Controls.Add(this.label1);
            this.tabPage2.Location = new System.Drawing.Point(4, 23);
            this.tabPage2.Name = "tabPage2";
            this.tabPage2.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage2.Size = new System.Drawing.Size(1212, 480);
            this.tabPage2.TabIndex = 1;
            this.tabPage2.Text = "Reserving";
            // 
            // cbTime_Vino
            // 
            this.cbTime_Vino.FormattingEnabled = true;
            this.cbTime_Vino.Items.AddRange(new object[] {
            "Choose time to book:",
            "09:00 pm",
            "11:00 pm",
            "13:00 pm",
            "15:00 pm",
            "18:00 pm",
            "21:00 pm"});
            this.cbTime_Vino.Location = new System.Drawing.Point(438, 327);
            this.cbTime_Vino.Name = "cbTime_Vino";
            this.cbTime_Vino.Size = new System.Drawing.Size(155, 22);
            this.cbTime_Vino.TabIndex = 53;
            // 
            // label20
            // 
            this.label20.AutoSize = true;
            this.label20.BackColor = System.Drawing.Color.Transparent;
            this.label20.Font = new System.Drawing.Font("Microsoft PhagsPa", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label20.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.label20.Location = new System.Drawing.Point(434, 304);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(45, 20);
            this.label20.TabIndex = 52;
            this.label20.Text = "Time:";
            // 
            // lblNoOfSeats_Vino
            // 
            this.lblNoOfSeats_Vino.AutoSize = true;
            this.lblNoOfSeats_Vino.BackColor = System.Drawing.Color.Transparent;
            this.lblNoOfSeats_Vino.Font = new System.Drawing.Font("Microsoft PhagsPa", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblNoOfSeats_Vino.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.lblNoOfSeats_Vino.Location = new System.Drawing.Point(46, 352);
            this.lblNoOfSeats_Vino.Name = "lblNoOfSeats_Vino";
            this.lblNoOfSeats_Vino.Size = new System.Drawing.Size(54, 15);
            this.lblNoOfSeats_Vino.TabIndex = 51;
            this.lblNoOfSeats_Vino.Text = "Seats left";
            // 
            // TxtNoOfGuests_Vino
            // 
            this.TxtNoOfGuests_Vino.Location = new System.Drawing.Point(46, 327);
            this.TxtNoOfGuests_Vino.Name = "TxtNoOfGuests_Vino";
            this.TxtNoOfGuests_Vino.Size = new System.Drawing.Size(108, 22);
            this.TxtNoOfGuests_Vino.TabIndex = 49;
            // 
            // pictureBox1
            // 
            this.pictureBox1.BackgroundImage = global::Restaurant_Reservation_System_FinalProject_26.Properties.Resources.vin_santo;
            this.pictureBox1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pictureBox1.Location = new System.Drawing.Point(1001, 6);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(205, 152);
            this.pictureBox1.TabIndex = 48;
            this.pictureBox1.TabStop = false;
            // 
            // btnHomeVino
            // 
            this.btnHomeVino.BackColor = System.Drawing.Color.Crimson;
            this.btnHomeVino.Font = new System.Drawing.Font("Microsoft PhagsPa", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnHomeVino.ForeColor = System.Drawing.Color.LavenderBlush;
            this.btnHomeVino.Location = new System.Drawing.Point(1092, 411);
            this.btnHomeVino.Name = "btnHomeVino";
            this.btnHomeVino.Size = new System.Drawing.Size(89, 40);
            this.btnHomeVino.TabIndex = 23;
            this.btnHomeVino.Text = "Home";
            this.btnHomeVino.UseVisualStyleBackColor = false;
            this.btnHomeVino.Click += new System.EventHandler(this.btnHomeVino_Click);
            // 
            // btnSubmit_Vino
            // 
            this.btnSubmit_Vino.BackColor = System.Drawing.Color.Lime;
            this.btnSubmit_Vino.Font = new System.Drawing.Font("Microsoft PhagsPa", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSubmit_Vino.ForeColor = System.Drawing.SystemColors.HighlightText;
            this.btnSubmit_Vino.Location = new System.Drawing.Point(822, 339);
            this.btnSubmit_Vino.Name = "btnSubmit_Vino";
            this.btnSubmit_Vino.Size = new System.Drawing.Size(135, 41);
            this.btnSubmit_Vino.TabIndex = 22;
            this.btnSubmit_Vino.Text = "Submit";
            this.btnSubmit_Vino.UseVisualStyleBackColor = false;
            this.btnSubmit_Vino.Click += new System.EventHandler(this.btnSubmit_Vino_Click);
            // 
            // txtRequest_Vino
            // 
            this.txtRequest_Vino.Location = new System.Drawing.Point(782, 282);
            this.txtRequest_Vino.Name = "txtRequest_Vino";
            this.txtRequest_Vino.Size = new System.Drawing.Size(199, 22);
            this.txtRequest_Vino.TabIndex = 21;
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.BackColor = System.Drawing.Color.Transparent;
            this.label12.Font = new System.Drawing.Font("Microsoft PhagsPa", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label12.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.label12.Location = new System.Drawing.Point(781, 259);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(143, 20);
            this.label12.TabIndex = 20;
            this.label12.Text = "Any special requests";
            // 
            // txtOther_Vino
            // 
            this.txtOther_Vino.Location = new System.Drawing.Point(785, 206);
            this.txtOther_Vino.Name = "txtOther_Vino";
            this.txtOther_Vino.Size = new System.Drawing.Size(199, 22);
            this.txtOther_Vino.TabIndex = 19;
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.BackColor = System.Drawing.Color.Transparent;
            this.label11.Font = new System.Drawing.Font("Microsoft PhagsPa", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label11.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.label11.Location = new System.Drawing.Point(781, 186);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(204, 20);
            this.label11.TabIndex = 18;
            this.label11.Text = "If Other above, please specify";
            // 
            // cbReserveType_Vino
            // 
            this.cbReserveType_Vino.FormattingEnabled = true;
            this.cbReserveType_Vino.Items.AddRange(new object[] {
            "Choose reservation type...",
            "Charity Event",
            "Retirement Party",
            "Engagement Party",
            "Wedding Reception",
            "Corporate Event",
            "Birthday Celebration"});
            this.cbReserveType_Vino.Location = new System.Drawing.Point(785, 128);
            this.cbReserveType_Vino.Name = "cbReserveType_Vino";
            this.cbReserveType_Vino.Size = new System.Drawing.Size(196, 22);
            this.cbReserveType_Vino.TabIndex = 17;
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.BackColor = System.Drawing.Color.Transparent;
            this.label10.Font = new System.Drawing.Font("Microsoft PhagsPa", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label10.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.label10.Location = new System.Drawing.Point(781, 105);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(122, 20);
            this.label10.TabIndex = 16;
            this.label10.Text = "Reservation Type";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.BackColor = System.Drawing.Color.Transparent;
            this.label9.Font = new System.Drawing.Font("Microsoft PhagsPa", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.label9.Location = new System.Drawing.Point(434, 186);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(86, 20);
            this.label9.TabIndex = 15;
            this.label9.Text = "Reservation";
            // 
            // dateTime_Vino
            // 
            this.dateTime_Vino.Location = new System.Drawing.Point(438, 206);
            this.dateTime_Vino.Name = "dateTime_Vino";
            this.dateTime_Vino.Size = new System.Drawing.Size(200, 22);
            this.dateTime_Vino.TabIndex = 14;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.BackColor = System.Drawing.Color.Transparent;
            this.label8.Font = new System.Drawing.Font("Microsoft PhagsPa", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.label8.Location = new System.Drawing.Point(42, 304);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(97, 20);
            this.label8.TabIndex = 12;
            this.label8.Text = "No. of Guests";
            // 
            // txtPhone_Vino
            // 
            this.txtPhone_Vino.Location = new System.Drawing.Point(46, 263);
            this.txtPhone_Vino.Name = "txtPhone_Vino";
            this.txtPhone_Vino.Size = new System.Drawing.Size(285, 22);
            this.txtPhone_Vino.TabIndex = 11;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.BackColor = System.Drawing.Color.Transparent;
            this.label7.Font = new System.Drawing.Font("Microsoft PhagsPa", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.label7.Location = new System.Drawing.Point(45, 240);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(50, 20);
            this.label7.TabIndex = 10;
            this.label7.Text = "Phone";
            // 
            // txtEmail_Vino
            // 
            this.txtEmail_Vino.Location = new System.Drawing.Point(49, 209);
            this.txtEmail_Vino.Name = "txtEmail_Vino";
            this.txtEmail_Vino.Size = new System.Drawing.Size(285, 22);
            this.txtEmail_Vino.TabIndex = 9;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.BackColor = System.Drawing.Color.Transparent;
            this.label6.Font = new System.Drawing.Font("Microsoft PhagsPa", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.label6.Location = new System.Drawing.Point(42, 186);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(52, 20);
            this.label6.TabIndex = 8;
            this.label6.Text = "E-mail";
            // 
            // LName_Vino
            // 
            this.LName_Vino.Location = new System.Drawing.Point(278, 140);
            this.LName_Vino.Name = "LName_Vino";
            this.LName_Vino.Size = new System.Drawing.Size(199, 22);
            this.LName_Vino.TabIndex = 7;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.BackColor = System.Drawing.Color.Transparent;
            this.label5.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.label5.Location = new System.Drawing.Point(275, 165);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(59, 14);
            this.label5.TabIndex = 6;
            this.label5.Text = "Last Name";
            // 
            // txtFName_Vino
            // 
            this.txtFName_Vino.Location = new System.Drawing.Point(46, 140);
            this.txtFName_Vino.Name = "txtFName_Vino";
            this.txtFName_Vino.Size = new System.Drawing.Size(199, 22);
            this.txtFName_Vino.TabIndex = 5;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.BackColor = System.Drawing.Color.Transparent;
            this.label4.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.label4.Location = new System.Drawing.Point(43, 165);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(60, 14);
            this.label4.TabIndex = 4;
            this.label4.Text = "First Name";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.BackColor = System.Drawing.Color.Transparent;
            this.label3.Font = new System.Drawing.Font("Microsoft PhagsPa", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.label3.Location = new System.Drawing.Point(42, 105);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(76, 20);
            this.label3.TabIndex = 3;
            this.label3.Text = "Full Name";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.BackColor = System.Drawing.Color.Transparent;
            this.label2.Font = new System.Drawing.Font("Microsoft PhagsPa", 11F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.label2.Location = new System.Drawing.Point(23, 62);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(669, 20);
            this.label2.TabIndex = 2;
            this.label2.Text = "Please fill the form below accurately to enable us to serve you better!.. Welcome" +
    " to Vino Santo";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.Color.Transparent;
            this.label1.Font = new System.Drawing.Font("Microsoft PhagsPa", 16F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.label1.Location = new System.Drawing.Point(22, 23);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(157, 29);
            this.label1.TabIndex = 1;
            this.label1.Text = "Reserve Table";
            // 
            // tabPage3
            // 
            this.tabPage3.BackColor = System.Drawing.Color.Silver;
            this.tabPage3.BackgroundImage = global::Restaurant_Reservation_System_FinalProject_26.Properties.Resources._330_768x5911;
            this.tabPage3.Controls.Add(this.btnBack_pg2);
            this.tabPage3.Controls.Add(this.tabControl2);
            this.tabPage3.Location = new System.Drawing.Point(4, 23);
            this.tabPage3.Name = "tabPage3";
            this.tabPage3.Size = new System.Drawing.Size(1212, 480);
            this.tabPage3.TabIndex = 2;
            this.tabPage3.Text = "Menu";
            // 
            // btnBack_pg2
            // 
            this.btnBack_pg2.BackColor = System.Drawing.Color.Crimson;
            this.btnBack_pg2.Font = new System.Drawing.Font("Microsoft PhagsPa", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnBack_pg2.ForeColor = System.Drawing.SystemColors.Window;
            this.btnBack_pg2.Location = new System.Drawing.Point(1154, 448);
            this.btnBack_pg2.Name = "btnBack_pg2";
            this.btnBack_pg2.Size = new System.Drawing.Size(56, 29);
            this.btnBack_pg2.TabIndex = 0;
            this.btnBack_pg2.Text = "Back";
            this.btnBack_pg2.UseVisualStyleBackColor = false;
            this.btnBack_pg2.Click += new System.EventHandler(this.btnBack_pg2_Click);
            // 
            // tabControl2
            // 
            this.tabControl2.Controls.Add(this.tabPage1);
            this.tabControl2.Controls.Add(this.tabPage6);
            this.tabControl2.Location = new System.Drawing.Point(3, 3);
            this.tabControl2.Name = "tabControl2";
            this.tabControl2.SelectedIndex = 0;
            this.tabControl2.Size = new System.Drawing.Size(1206, 440);
            this.tabControl2.TabIndex = 1;
            // 
            // tabPage1
            // 
            this.tabPage1.BackColor = System.Drawing.Color.DarkGray;
            this.tabPage1.Controls.Add(this.btnSkip_Vino);
            this.tabPage1.Controls.Add(this.btnNext_Vino);
            this.tabPage1.Controls.Add(this.label21);
            this.tabPage1.Controls.Add(this.rtxtAllergies_Vino);
            this.tabPage1.Controls.Add(this.cbAllergies_Vino);
            this.tabPage1.Controls.Add(this.groupBox6);
            this.tabPage1.Controls.Add(this.groupBox4);
            this.tabPage1.Controls.Add(this.groupBox3);
            this.tabPage1.Location = new System.Drawing.Point(4, 23);
            this.tabPage1.Name = "tabPage1";
            this.tabPage1.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage1.Size = new System.Drawing.Size(1198, 413);
            this.tabPage1.TabIndex = 0;
            this.tabPage1.Text = "Food";
            // 
            // btnSkip_Vino
            // 
            this.btnSkip_Vino.BackColor = System.Drawing.Color.Green;
            this.btnSkip_Vino.Font = new System.Drawing.Font("Microsoft PhagsPa", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSkip_Vino.ForeColor = System.Drawing.SystemColors.Control;
            this.btnSkip_Vino.Location = new System.Drawing.Point(1131, 6);
            this.btnSkip_Vino.Name = "btnSkip_Vino";
            this.btnSkip_Vino.Size = new System.Drawing.Size(64, 23);
            this.btnSkip_Vino.TabIndex = 11;
            this.btnSkip_Vino.Text = "Skip";
            this.btnSkip_Vino.UseVisualStyleBackColor = false;
            this.btnSkip_Vino.Click += new System.EventHandler(this.btnSkip_Vino_Click);
            // 
            // btnNext_Vino
            // 
            this.btnNext_Vino.BackColor = System.Drawing.Color.Blue;
            this.btnNext_Vino.Font = new System.Drawing.Font("Microsoft PhagsPa", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnNext_Vino.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.btnNext_Vino.Location = new System.Drawing.Point(1087, 354);
            this.btnNext_Vino.Name = "btnNext_Vino";
            this.btnNext_Vino.Size = new System.Drawing.Size(88, 34);
            this.btnNext_Vino.TabIndex = 9;
            this.btnNext_Vino.Text = "Next";
            this.btnNext_Vino.UseVisualStyleBackColor = false;
            this.btnNext_Vino.Click += new System.EventHandler(this.btnNext_Vino_Click);
            // 
            // label21
            // 
            this.label21.AutoSize = true;
            this.label21.Font = new System.Drawing.Font("Microsoft PhagsPa", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label21.Location = new System.Drawing.Point(817, 167);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(196, 15);
            this.label21.TabIndex = 8;
            this.label21.Text = "Please specify your allergies below...";
            // 
            // rtxtAllergies_Vino
            // 
            this.rtxtAllergies_Vino.Location = new System.Drawing.Point(820, 191);
            this.rtxtAllergies_Vino.Name = "rtxtAllergies_Vino";
            this.rtxtAllergies_Vino.Size = new System.Drawing.Size(299, 96);
            this.rtxtAllergies_Vino.TabIndex = 7;
            this.rtxtAllergies_Vino.Text = "";
            // 
            // cbAllergies_Vino
            // 
            this.cbAllergies_Vino.AutoSize = true;
            this.cbAllergies_Vino.Font = new System.Drawing.Font("Microsoft PhagsPa", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cbAllergies_Vino.Location = new System.Drawing.Point(820, 125);
            this.cbAllergies_Vino.Name = "cbAllergies_Vino";
            this.cbAllergies_Vino.Size = new System.Drawing.Size(210, 19);
            this.cbAllergies_Vino.TabIndex = 6;
            this.cbAllergies_Vino.Text = "If you have allergies, click the box...";
            this.cbAllergies_Vino.UseVisualStyleBackColor = true;
            this.cbAllergies_Vino.CheckedChanged += new System.EventHandler(this.cbAllergies_Vino_CheckedChanged);
            // 
            // groupBox6
            // 
            this.groupBox6.Controls.Add(this.pbDeserts_Vino);
            this.groupBox6.Controls.Add(this.cbDesert5_Vino);
            this.groupBox6.Controls.Add(this.cbDesert4_Vino);
            this.groupBox6.Controls.Add(this.cbDesert3_Vino);
            this.groupBox6.Controls.Add(this.cbDesert2_Vino);
            this.groupBox6.Controls.Add(this.cbDesert1_Vino);
            this.groupBox6.Font = new System.Drawing.Font("Microsoft PhagsPa", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox6.Location = new System.Drawing.Point(6, 202);
            this.groupBox6.Name = "groupBox6";
            this.groupBox6.Size = new System.Drawing.Size(351, 186);
            this.groupBox6.TabIndex = 1;
            this.groupBox6.TabStop = false;
            this.groupBox6.Text = "Deserts";
            // 
            // pbDeserts_Vino
            // 
            this.pbDeserts_Vino.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pbDeserts_Vino.Location = new System.Drawing.Point(156, 48);
            this.pbDeserts_Vino.Name = "pbDeserts_Vino";
            this.pbDeserts_Vino.Size = new System.Drawing.Size(150, 119);
            this.pbDeserts_Vino.TabIndex = 6;
            this.pbDeserts_Vino.TabStop = false;
            // 
            // cbDesert5_Vino
            // 
            this.cbDesert5_Vino.AutoSize = true;
            this.cbDesert5_Vino.Location = new System.Drawing.Point(7, 148);
            this.cbDesert5_Vino.Name = "cbDesert5_Vino";
            this.cbDesert5_Vino.Size = new System.Drawing.Size(86, 19);
            this.cbDesert5_Vino.TabIndex = 5;
            this.cbDesert5_Vino.Text = "Cheesecake";
            this.cbDesert5_Vino.UseVisualStyleBackColor = true;
            this.cbDesert5_Vino.CheckedChanged += new System.EventHandler(this.cbDesert5_Vino_CheckedChanged);
            // 
            // cbDesert4_Vino
            // 
            this.cbDesert4_Vino.AutoSize = true;
            this.cbDesert4_Vino.Location = new System.Drawing.Point(7, 123);
            this.cbDesert4_Vino.Name = "cbDesert4_Vino";
            this.cbDesert4_Vino.Size = new System.Drawing.Size(90, 19);
            this.cbDesert4_Vino.TabIndex = 4;
            this.cbDesert4_Vino.Text = "Panna Cotta";
            this.cbDesert4_Vino.UseVisualStyleBackColor = true;
            this.cbDesert4_Vino.CheckedChanged += new System.EventHandler(this.cbDesert4_Vino_CheckedChanged);
            // 
            // cbDesert3_Vino
            // 
            this.cbDesert3_Vino.AutoSize = true;
            this.cbDesert3_Vino.Location = new System.Drawing.Point(7, 98);
            this.cbDesert3_Vino.Name = "cbDesert3_Vino";
            this.cbDesert3_Vino.Size = new System.Drawing.Size(125, 19);
            this.cbDesert3_Vino.TabIndex = 3;
            this.cbDesert3_Vino.Text = "Chocolate Fondant";
            this.cbDesert3_Vino.UseVisualStyleBackColor = true;
            this.cbDesert3_Vino.CheckedChanged += new System.EventHandler(this.cbDesert3_Vino_CheckedChanged);
            // 
            // cbDesert2_Vino
            // 
            this.cbDesert2_Vino.AutoSize = true;
            this.cbDesert2_Vino.Location = new System.Drawing.Point(7, 73);
            this.cbDesert2_Vino.Name = "cbDesert2_Vino";
            this.cbDesert2_Vino.Size = new System.Drawing.Size(70, 19);
            this.cbDesert2_Vino.TabIndex = 2;
            this.cbDesert2_Vino.Text = "Tiramisu";
            this.cbDesert2_Vino.UseVisualStyleBackColor = true;
            this.cbDesert2_Vino.CheckedChanged += new System.EventHandler(this.cbDesert2_Vino_CheckedChanged);
            // 
            // cbDesert1_Vino
            // 
            this.cbDesert1_Vino.AutoSize = true;
            this.cbDesert1_Vino.Location = new System.Drawing.Point(7, 48);
            this.cbDesert1_Vino.Name = "cbDesert1_Vino";
            this.cbDesert1_Vino.Size = new System.Drawing.Size(95, 19);
            this.cbDesert1_Vino.TabIndex = 1;
            this.cbDesert1_Vino.Text = "Creme Brulee";
            this.cbDesert1_Vino.UseVisualStyleBackColor = true;
            this.cbDesert1_Vino.CheckedChanged += new System.EventHandler(this.cbDesert1_Vino_CheckedChanged);
            // 
            // groupBox4
            // 
            this.groupBox4.Controls.Add(this.pbMain_Vino);
            this.groupBox4.Controls.Add(this.cbMain8_Vino);
            this.groupBox4.Controls.Add(this.cbMain7_Vino);
            this.groupBox4.Controls.Add(this.cbMain6_Vino);
            this.groupBox4.Controls.Add(this.cbMain5_Vino);
            this.groupBox4.Controls.Add(this.cbMain4_Vino);
            this.groupBox4.Controls.Add(this.cbMain3_Vino);
            this.groupBox4.Controls.Add(this.cbMain2_Vino);
            this.groupBox4.Controls.Add(this.cbMain1_Vino);
            this.groupBox4.Font = new System.Drawing.Font("Microsoft PhagsPa", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox4.Location = new System.Drawing.Point(396, 79);
            this.groupBox4.Name = "groupBox4";
            this.groupBox4.Size = new System.Drawing.Size(360, 240);
            this.groupBox4.TabIndex = 1;
            this.groupBox4.TabStop = false;
            this.groupBox4.Text = "Main Courses(Entrees)";
            // 
            // pbMain_Vino
            // 
            this.pbMain_Vino.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pbMain_Vino.Location = new System.Drawing.Point(177, 60);
            this.pbMain_Vino.Name = "pbMain_Vino";
            this.pbMain_Vino.Size = new System.Drawing.Size(150, 119);
            this.pbMain_Vino.TabIndex = 9;
            this.pbMain_Vino.TabStop = false;
            // 
            // cbMain8_Vino
            // 
            this.cbMain8_Vino.AutoSize = true;
            this.cbMain8_Vino.Location = new System.Drawing.Point(6, 210);
            this.cbMain8_Vino.Name = "cbMain8_Vino";
            this.cbMain8_Vino.Size = new System.Drawing.Size(110, 19);
            this.cbMain8_Vino.TabIndex = 8;
            this.cbMain8_Vino.Text = "Beef Wellington";
            this.cbMain8_Vino.UseVisualStyleBackColor = true;
            this.cbMain8_Vino.CheckedChanged += new System.EventHandler(this.cbMain8_Vino_CheckedChanged);
            // 
            // cbMain7_Vino
            // 
            this.cbMain7_Vino.AutoSize = true;
            this.cbMain7_Vino.Location = new System.Drawing.Point(6, 185);
            this.cbMain7_Vino.Name = "cbMain7_Vino";
            this.cbMain7_Vino.Size = new System.Drawing.Size(83, 19);
            this.cbMain7_Vino.TabIndex = 7;
            this.cbMain7_Vino.Text = "Coq au Vin";
            this.cbMain7_Vino.UseVisualStyleBackColor = true;
            this.cbMain7_Vino.CheckedChanged += new System.EventHandler(this.cbMain7_Vino_CheckedChanged);
            // 
            // cbMain6_Vino
            // 
            this.cbMain6_Vino.AutoSize = true;
            this.cbMain6_Vino.Location = new System.Drawing.Point(6, 160);
            this.cbMain6_Vino.Name = "cbMain6_Vino";
            this.cbMain6_Vino.Size = new System.Drawing.Size(119, 19);
            this.cbMain6_Vino.TabIndex = 6;
            this.cbMain6_Vino.Text = "Salmon en Croute";
            this.cbMain6_Vino.UseVisualStyleBackColor = true;
            this.cbMain6_Vino.CheckedChanged += new System.EventHandler(this.cbMain6_Vino_CheckedChanged);
            // 
            // cbMain5_Vino
            // 
            this.cbMain5_Vino.AutoSize = true;
            this.cbMain5_Vino.Location = new System.Drawing.Point(6, 135);
            this.cbMain5_Vino.Name = "cbMain5_Vino";
            this.cbMain5_Vino.Size = new System.Drawing.Size(63, 19);
            this.cbMain5_Vino.TabIndex = 5;
            this.cbMain5_Vino.Text = "Risotto";
            this.cbMain5_Vino.UseVisualStyleBackColor = true;
            this.cbMain5_Vino.CheckedChanged += new System.EventHandler(this.cbMain5_Vino_CheckedChanged);
            // 
            // cbMain4_Vino
            // 
            this.cbMain4_Vino.AutoSize = true;
            this.cbMain4_Vino.Location = new System.Drawing.Point(6, 110);
            this.cbMain4_Vino.Name = "cbMain4_Vino";
            this.cbMain4_Vino.Size = new System.Drawing.Size(96, 19);
            this.cbMain4_Vino.TabIndex = 4;
            this.cbMain4_Vino.Text = "Rack of Lamb";
            this.cbMain4_Vino.UseVisualStyleBackColor = true;
            this.cbMain4_Vino.CheckedChanged += new System.EventHandler(this.cbMain4_Vino_CheckedChanged);
            // 
            // cbMain3_Vino
            // 
            this.cbMain3_Vino.AutoSize = true;
            this.cbMain3_Vino.Location = new System.Drawing.Point(6, 85);
            this.cbMain3_Vino.Name = "cbMain3_Vino";
            this.cbMain3_Vino.Size = new System.Drawing.Size(122, 19);
            this.cbMain3_Vino.TabIndex = 3;
            this.cbMain3_Vino.Text = "Lobster Thermidor";
            this.cbMain3_Vino.UseVisualStyleBackColor = true;
            this.cbMain3_Vino.CheckedChanged += new System.EventHandler(this.cbMain3_Vino_CheckedChanged);
            // 
            // cbMain2_Vino
            // 
            this.cbMain2_Vino.AutoSize = true;
            this.cbMain2_Vino.Location = new System.Drawing.Point(6, 60);
            this.cbMain2_Vino.Name = "cbMain2_Vino";
            this.cbMain2_Vino.Size = new System.Drawing.Size(108, 19);
            this.cbMain2_Vino.TabIndex = 2;
            this.cbMain2_Vino.Text = "Duck a l\'Orange";
            this.cbMain2_Vino.UseVisualStyleBackColor = true;
            this.cbMain2_Vino.CheckedChanged += new System.EventHandler(this.cbMain2_Vino_CheckedChanged);
            // 
            // cbMain1_Vino
            // 
            this.cbMain1_Vino.AutoSize = true;
            this.cbMain1_Vino.Location = new System.Drawing.Point(6, 35);
            this.cbMain1_Vino.Name = "cbMain1_Vino";
            this.cbMain1_Vino.Size = new System.Drawing.Size(93, 19);
            this.cbMain1_Vino.TabIndex = 1;
            this.cbMain1_Vino.Text = "Filet Mignon";
            this.cbMain1_Vino.UseVisualStyleBackColor = true;
            this.cbMain1_Vino.CheckedChanged += new System.EventHandler(this.cbMain1_Vino_CheckedChanged);
            // 
            // groupBox3
            // 
            this.groupBox3.Controls.Add(this.pbAppetizers_Vino);
            this.groupBox3.Controls.Add(this.cbStarter5_Vino);
            this.groupBox3.Controls.Add(this.cbStarter4_Vino);
            this.groupBox3.Controls.Add(this.cbStarter3_Vino);
            this.groupBox3.Controls.Add(this.cbStarter2_Vino);
            this.groupBox3.Controls.Add(this.cbStarter1_Vino);
            this.groupBox3.Font = new System.Drawing.Font("Microsoft PhagsPa", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox3.Location = new System.Drawing.Point(6, 6);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Size = new System.Drawing.Size(351, 190);
            this.groupBox3.TabIndex = 0;
            this.groupBox3.TabStop = false;
            this.groupBox3.Text = "Appetizers (Starters)";
            // 
            // pbAppetizers_Vino
            // 
            this.pbAppetizers_Vino.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pbAppetizers_Vino.Location = new System.Drawing.Point(156, 35);
            this.pbAppetizers_Vino.Name = "pbAppetizers_Vino";
            this.pbAppetizers_Vino.Size = new System.Drawing.Size(150, 119);
            this.pbAppetizers_Vino.TabIndex = 5;
            this.pbAppetizers_Vino.TabStop = false;
            // 
            // cbStarter5_Vino
            // 
            this.cbStarter5_Vino.AutoSize = true;
            this.cbStarter5_Vino.Location = new System.Drawing.Point(7, 135);
            this.cbStarter5_Vino.Name = "cbStarter5_Vino";
            this.cbStarter5_Vino.Size = new System.Drawing.Size(102, 19);
            this.cbStarter5_Vino.TabIndex = 4;
            this.cbStarter5_Vino.Text = "Beef Carpaccio";
            this.cbStarter5_Vino.UseVisualStyleBackColor = true;
            this.cbStarter5_Vino.CheckedChanged += new System.EventHandler(this.cbStarter5_Vino_CheckedChanged);
            // 
            // cbStarter4_Vino
            // 
            this.cbStarter4_Vino.AutoSize = true;
            this.cbStarter4_Vino.Location = new System.Drawing.Point(7, 110);
            this.cbStarter4_Vino.Name = "cbStarter4_Vino";
            this.cbStarter4_Vino.Size = new System.Drawing.Size(70, 19);
            this.cbStarter4_Vino.TabIndex = 3;
            this.cbStarter4_Vino.Text = "Escargot";
            this.cbStarter4_Vino.UseVisualStyleBackColor = true;
            this.cbStarter4_Vino.CheckedChanged += new System.EventHandler(this.cbStarter4_Vino_CheckedChanged);
            // 
            // cbStarter3_Vino
            // 
            this.cbStarter3_Vino.AutoSize = true;
            this.cbStarter3_Vino.Location = new System.Drawing.Point(7, 85);
            this.cbStarter3_Vino.Name = "cbStarter3_Vino";
            this.cbStarter3_Vino.Size = new System.Drawing.Size(91, 19);
            this.cbStarter3_Vino.TabIndex = 2;
            this.cbStarter3_Vino.Text = "Tuna Tartare";
            this.cbStarter3_Vino.UseVisualStyleBackColor = true;
            this.cbStarter3_Vino.CheckedChanged += new System.EventHandler(this.cbStarter3_Vino_CheckedChanged);
            // 
            // cbStarter2_Vino
            // 
            this.cbStarter2_Vino.AutoSize = true;
            this.cbStarter2_Vino.Location = new System.Drawing.Point(6, 60);
            this.cbStarter2_Vino.Name = "cbStarter2_Vino";
            this.cbStarter2_Vino.Size = new System.Drawing.Size(124, 19);
            this.cbStarter2_Vino.TabIndex = 1;
            this.cbStarter2_Vino.Text = "Oysters Rockefeller";
            this.cbStarter2_Vino.UseVisualStyleBackColor = true;
            this.cbStarter2_Vino.CheckedChanged += new System.EventHandler(this.cbStarter2_Vino_CheckedChanged);
            // 
            // cbStarter1_Vino
            // 
            this.cbStarter1_Vino.AutoSize = true;
            this.cbStarter1_Vino.Location = new System.Drawing.Point(7, 35);
            this.cbStarter1_Vino.Name = "cbStarter1_Vino";
            this.cbStarter1_Vino.Size = new System.Drawing.Size(113, 19);
            this.cbStarter1_Vino.TabIndex = 0;
            this.cbStarter1_Vino.Text = "Foie Gras Terrine";
            this.cbStarter1_Vino.UseVisualStyleBackColor = true;
            this.cbStarter1_Vino.CheckedChanged += new System.EventHandler(this.cbStarter1_Vino_CheckedChanged);
            // 
            // tabPage6
            // 
            this.tabPage6.BackColor = System.Drawing.Color.DarkGray;
            this.tabPage6.Controls.Add(this.btnBack1_Vino);
            this.tabPage6.Controls.Add(this.groupBox10);
            this.tabPage6.Controls.Add(this.groupBox9);
            this.tabPage6.Controls.Add(this.groupBox8);
            this.tabPage6.Controls.Add(this.groupBox7);
            this.tabPage6.Controls.Add(this.btnRemove_Vino);
            this.tabPage6.Controls.Add(this.btnSubmitOrder_Vino);
            this.tabPage6.Controls.Add(this.groupBox5);
            this.tabPage6.Location = new System.Drawing.Point(4, 23);
            this.tabPage6.Name = "tabPage6";
            this.tabPage6.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage6.Size = new System.Drawing.Size(1198, 413);
            this.tabPage6.TabIndex = 1;
            this.tabPage6.Text = "Drinks";
            // 
            // btnBack1_Vino
            // 
            this.btnBack1_Vino.BackColor = System.Drawing.Color.Red;
            this.btnBack1_Vino.Font = new System.Drawing.Font("Microsoft PhagsPa", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnBack1_Vino.ForeColor = System.Drawing.SystemColors.MenuBar;
            this.btnBack1_Vino.Location = new System.Drawing.Point(1130, 3);
            this.btnBack1_Vino.Name = "btnBack1_Vino";
            this.btnBack1_Vino.Size = new System.Drawing.Size(62, 29);
            this.btnBack1_Vino.TabIndex = 16;
            this.btnBack1_Vino.Text = "Food";
            this.btnBack1_Vino.UseVisualStyleBackColor = false;
            this.btnBack1_Vino.Click += new System.EventHandler(this.btnBack1_Vino_Click);
            // 
            // groupBox10
            // 
            this.groupBox10.Controls.Add(this.pbHotBev_Vino);
            this.groupBox10.Controls.Add(this.cbHotBev5_Vino);
            this.groupBox10.Controls.Add(this.cbHotBev4_Vino);
            this.groupBox10.Controls.Add(this.cbHotBev3_Vino);
            this.groupBox10.Controls.Add(this.cbHotBev2_Vino);
            this.groupBox10.Controls.Add(this.cbHotBev1_Vino);
            this.groupBox10.Font = new System.Drawing.Font("Microsoft PhagsPa", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox10.Location = new System.Drawing.Point(399, 218);
            this.groupBox10.Name = "groupBox10";
            this.groupBox10.Size = new System.Drawing.Size(354, 192);
            this.groupBox10.TabIndex = 10;
            this.groupBox10.TabStop = false;
            this.groupBox10.Text = "Hot Beverages";
            // 
            // pbHotBev_Vino
            // 
            this.pbHotBev_Vino.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pbHotBev_Vino.Location = new System.Drawing.Point(198, 37);
            this.pbHotBev_Vino.Name = "pbHotBev_Vino";
            this.pbHotBev_Vino.Size = new System.Drawing.Size(150, 119);
            this.pbHotBev_Vino.TabIndex = 10;
            this.pbHotBev_Vino.TabStop = false;
            // 
            // cbHotBev5_Vino
            // 
            this.cbHotBev5_Vino.AutoSize = true;
            this.cbHotBev5_Vino.Location = new System.Drawing.Point(15, 137);
            this.cbHotBev5_Vino.Name = "cbHotBev5_Vino";
            this.cbHotBev5_Vino.Size = new System.Drawing.Size(81, 19);
            this.cbHotBev5_Vino.TabIndex = 9;
            this.cbHotBev5_Vino.Text = "Herbal Tea";
            this.cbHotBev5_Vino.UseVisualStyleBackColor = true;
            this.cbHotBev5_Vino.CheckedChanged += new System.EventHandler(this.cbHotBev5_Vino_CheckedChanged);
            // 
            // cbHotBev4_Vino
            // 
            this.cbHotBev4_Vino.AutoSize = true;
            this.cbHotBev4_Vino.Location = new System.Drawing.Point(15, 112);
            this.cbHotBev4_Vino.Name = "cbHotBev4_Vino";
            this.cbHotBev4_Vino.Size = new System.Drawing.Size(74, 19);
            this.cbHotBev4_Vino.TabIndex = 8;
            this.cbHotBev4_Vino.Text = "Black Tea";
            this.cbHotBev4_Vino.UseVisualStyleBackColor = true;
            this.cbHotBev4_Vino.CheckedChanged += new System.EventHandler(this.cbHotBev4_Vino_CheckedChanged);
            // 
            // cbHotBev3_Vino
            // 
            this.cbHotBev3_Vino.AutoSize = true;
            this.cbHotBev3_Vino.Location = new System.Drawing.Point(15, 87);
            this.cbHotBev3_Vino.Name = "cbHotBev3_Vino";
            this.cbHotBev3_Vino.Size = new System.Drawing.Size(52, 19);
            this.cbHotBev3_Vino.TabIndex = 7;
            this.cbHotBev3_Vino.Text = "Latte";
            this.cbHotBev3_Vino.UseVisualStyleBackColor = true;
            this.cbHotBev3_Vino.CheckedChanged += new System.EventHandler(this.cbHotBev3_Vino_CheckedChanged);
            // 
            // cbHotBev2_Vino
            // 
            this.cbHotBev2_Vino.AutoSize = true;
            this.cbHotBev2_Vino.Location = new System.Drawing.Point(15, 62);
            this.cbHotBev2_Vino.Name = "cbHotBev2_Vino";
            this.cbHotBev2_Vino.Size = new System.Drawing.Size(82, 19);
            this.cbHotBev2_Vino.TabIndex = 6;
            this.cbHotBev2_Vino.Text = "Cuppacino";
            this.cbHotBev2_Vino.UseVisualStyleBackColor = true;
            this.cbHotBev2_Vino.CheckedChanged += new System.EventHandler(this.cbHotBev2_Vino_CheckedChanged);
            // 
            // cbHotBev1_Vino
            // 
            this.cbHotBev1_Vino.AutoSize = true;
            this.cbHotBev1_Vino.Location = new System.Drawing.Point(15, 37);
            this.cbHotBev1_Vino.Name = "cbHotBev1_Vino";
            this.cbHotBev1_Vino.Size = new System.Drawing.Size(72, 19);
            this.cbHotBev1_Vino.TabIndex = 5;
            this.cbHotBev1_Vino.Text = "Expresso";
            this.cbHotBev1_Vino.UseVisualStyleBackColor = true;
            this.cbHotBev1_Vino.CheckedChanged += new System.EventHandler(this.cbHotBev1_Vino_CheckedChanged);
            // 
            // groupBox9
            // 
            this.groupBox9.Controls.Add(this.pbNonBev_Vino);
            this.groupBox9.Controls.Add(this.cbNonBev5_Vino);
            this.groupBox9.Controls.Add(this.cbNonBev4_Vino);
            this.groupBox9.Controls.Add(this.cbNonBev3_Vino);
            this.groupBox9.Controls.Add(this.cbNonBev2_Vino);
            this.groupBox9.Controls.Add(this.cbNonBev1_Vino);
            this.groupBox9.Font = new System.Drawing.Font("Microsoft PhagsPa", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox9.Location = new System.Drawing.Point(399, 6);
            this.groupBox9.Name = "groupBox9";
            this.groupBox9.Size = new System.Drawing.Size(354, 203);
            this.groupBox9.TabIndex = 9;
            this.groupBox9.TabStop = false;
            this.groupBox9.Text = "Non-Alcoholic Beverages";
            // 
            // pbNonBev_Vino
            // 
            this.pbNonBev_Vino.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pbNonBev_Vino.Location = new System.Drawing.Point(198, 48);
            this.pbNonBev_Vino.Name = "pbNonBev_Vino";
            this.pbNonBev_Vino.Size = new System.Drawing.Size(150, 119);
            this.pbNonBev_Vino.TabIndex = 10;
            this.pbNonBev_Vino.TabStop = false;
            // 
            // cbNonBev5_Vino
            // 
            this.cbNonBev5_Vino.AutoSize = true;
            this.cbNonBev5_Vino.Location = new System.Drawing.Point(14, 142);
            this.cbNonBev5_Vino.Name = "cbNonBev5_Vino";
            this.cbNonBev5_Vino.Size = new System.Drawing.Size(124, 19);
            this.cbNonBev5_Vino.TabIndex = 9;
            this.cbNonBev5_Vino.Text = "100% Mango Juice";
            this.cbNonBev5_Vino.UseVisualStyleBackColor = true;
            this.cbNonBev5_Vino.CheckedChanged += new System.EventHandler(this.cbNonBev5_Vino_CheckedChanged);
            // 
            // cbNonBev4_Vino
            // 
            this.cbNonBev4_Vino.AutoSize = true;
            this.cbNonBev4_Vino.Location = new System.Drawing.Point(14, 117);
            this.cbNonBev4_Vino.Name = "cbNonBev4_Vino";
            this.cbNonBev4_Vino.Size = new System.Drawing.Size(71, 19);
            this.cbNonBev4_Vino.TabIndex = 8;
            this.cbNonBev4_Vino.Text = "Mocktail";
            this.cbNonBev4_Vino.UseVisualStyleBackColor = true;
            this.cbNonBev4_Vino.CheckedChanged += new System.EventHandler(this.cbNonBev4_Vino_CheckedChanged);
            // 
            // cbNonBev3_Vino
            // 
            this.cbNonBev3_Vino.AutoSize = true;
            this.cbNonBev3_Vino.Location = new System.Drawing.Point(14, 92);
            this.cbNonBev3_Vino.Name = "cbNonBev3_Vino";
            this.cbNonBev3_Vino.Size = new System.Drawing.Size(68, 19);
            this.cbNonBev3_Vino.TabIndex = 7;
            this.cbNonBev3_Vino.Text = "Iced Tea";
            this.cbNonBev3_Vino.UseVisualStyleBackColor = true;
            this.cbNonBev3_Vino.CheckedChanged += new System.EventHandler(this.cbNonBev3_Vino_CheckedChanged);
            // 
            // cbNonBev2_Vino
            // 
            this.cbNonBev2_Vino.AutoSize = true;
            this.cbNonBev2_Vino.Location = new System.Drawing.Point(14, 67);
            this.cbNonBev2_Vino.Name = "cbNonBev2_Vino";
            this.cbNonBev2_Vino.Size = new System.Drawing.Size(186, 19);
            this.cbNonBev2_Vino.TabIndex = 6;
            this.cbNonBev2_Vino.Text = "Freshly Squeezed Orange Juice";
            this.cbNonBev2_Vino.UseVisualStyleBackColor = true;
            this.cbNonBev2_Vino.CheckedChanged += new System.EventHandler(this.cbNonBev2_Vino_CheckedChanged);
            // 
            // cbNonBev1_Vino
            // 
            this.cbNonBev1_Vino.AutoSize = true;
            this.cbNonBev1_Vino.Location = new System.Drawing.Point(14, 42);
            this.cbNonBev1_Vino.Name = "cbNonBev1_Vino";
            this.cbNonBev1_Vino.Size = new System.Drawing.Size(109, 19);
            this.cbNonBev1_Vino.TabIndex = 5;
            this.cbNonBev1_Vino.Text = "Sparkling Water";
            this.cbNonBev1_Vino.UseVisualStyleBackColor = true;
            this.cbNonBev1_Vino.CheckedChanged += new System.EventHandler(this.cbNonBev1_Vino_CheckedChanged);
            // 
            // groupBox8
            // 
            this.groupBox8.Controls.Add(this.pbWines_Vino);
            this.groupBox8.Controls.Add(this.cbWine5_Vino);
            this.groupBox8.Controls.Add(this.cbWine4_Vino);
            this.groupBox8.Controls.Add(this.cbWine3_Vino);
            this.groupBox8.Controls.Add(this.cbWine2_Vino);
            this.groupBox8.Controls.Add(this.cbWine1_Vino);
            this.groupBox8.Font = new System.Drawing.Font("Microsoft PhagsPa", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox8.Location = new System.Drawing.Point(6, 215);
            this.groupBox8.Name = "groupBox8";
            this.groupBox8.Size = new System.Drawing.Size(348, 192);
            this.groupBox8.TabIndex = 9;
            this.groupBox8.TabStop = false;
            this.groupBox8.Text = "Wines";
            // 
            // pbWines_Vino
            // 
            this.pbWines_Vino.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pbWines_Vino.Location = new System.Drawing.Point(161, 40);
            this.pbWines_Vino.Name = "pbWines_Vino";
            this.pbWines_Vino.Size = new System.Drawing.Size(150, 119);
            this.pbWines_Vino.TabIndex = 6;
            this.pbWines_Vino.TabStop = false;
            // 
            // cbWine5_Vino
            // 
            this.cbWine5_Vino.AutoSize = true;
            this.cbWine5_Vino.Location = new System.Drawing.Point(10, 137);
            this.cbWine5_Vino.Name = "cbWine5_Vino";
            this.cbWine5_Vino.Size = new System.Drawing.Size(61, 19);
            this.cbWine5_Vino.TabIndex = 9;
            this.cbWine5_Vino.Text = "Merlot";
            this.cbWine5_Vino.UseVisualStyleBackColor = true;
            this.cbWine5_Vino.CheckedChanged += new System.EventHandler(this.cbWine5_Vino_CheckedChanged);
            // 
            // cbWine4_Vino
            // 
            this.cbWine4_Vino.AutoSize = true;
            this.cbWine4_Vino.Location = new System.Drawing.Point(10, 112);
            this.cbWine4_Vino.Name = "cbWine4_Vino";
            this.cbWine4_Vino.Size = new System.Drawing.Size(113, 19);
            this.cbWine4_Vino.TabIndex = 8;
            this.cbWine4_Vino.Text = "Sauvignon Blanc";
            this.cbWine4_Vino.UseVisualStyleBackColor = true;
            this.cbWine4_Vino.CheckedChanged += new System.EventHandler(this.cbWine4_Vino_CheckedChanged);
            // 
            // cbWine3_Vino
            // 
            this.cbWine3_Vino.AutoSize = true;
            this.cbWine3_Vino.Location = new System.Drawing.Point(10, 87);
            this.cbWine3_Vino.Name = "cbWine3_Vino";
            this.cbWine3_Vino.Size = new System.Drawing.Size(80, 19);
            this.cbWine3_Vino.TabIndex = 7;
            this.cbWine3_Vino.Text = "Pinot Noir";
            this.cbWine3_Vino.UseVisualStyleBackColor = true;
            this.cbWine3_Vino.CheckedChanged += new System.EventHandler(this.cbWine3_Vino_CheckedChanged);
            // 
            // cbWine2_Vino
            // 
            this.cbWine2_Vino.AutoSize = true;
            this.cbWine2_Vino.Location = new System.Drawing.Point(10, 62);
            this.cbWine2_Vino.Name = "cbWine2_Vino";
            this.cbWine2_Vino.Size = new System.Drawing.Size(90, 19);
            this.cbWine2_Vino.TabIndex = 6;
            this.cbWine2_Vino.Text = "Chardonnay";
            this.cbWine2_Vino.UseVisualStyleBackColor = true;
            this.cbWine2_Vino.CheckedChanged += new System.EventHandler(this.cbWine2_Vino_CheckedChanged);
            // 
            // cbWine1_Vino
            // 
            this.cbWine1_Vino.AutoSize = true;
            this.cbWine1_Vino.Location = new System.Drawing.Point(10, 37);
            this.cbWine1_Vino.Name = "cbWine1_Vino";
            this.cbWine1_Vino.Size = new System.Drawing.Size(132, 19);
            this.cbWine1_Vino.TabIndex = 5;
            this.cbWine1_Vino.Text = "Cabernet Sauvignon";
            this.cbWine1_Vino.UseVisualStyleBackColor = true;
            this.cbWine1_Vino.CheckedChanged += new System.EventHandler(this.cbWine1_Vino_CheckedChanged);
            // 
            // groupBox7
            // 
            this.groupBox7.Controls.Add(this.pbCocktails_Vino);
            this.groupBox7.Controls.Add(this.cbCocktail5_Vino);
            this.groupBox7.Controls.Add(this.cbCocktail4_Vino);
            this.groupBox7.Controls.Add(this.cbCocktail3_Vino);
            this.groupBox7.Controls.Add(this.cbcocktail2_Vino);
            this.groupBox7.Controls.Add(this.cbcocktail1_Vino);
            this.groupBox7.Font = new System.Drawing.Font("Microsoft PhagsPa", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox7.Location = new System.Drawing.Point(6, 6);
            this.groupBox7.Name = "groupBox7";
            this.groupBox7.Size = new System.Drawing.Size(348, 203);
            this.groupBox7.TabIndex = 8;
            this.groupBox7.TabStop = false;
            this.groupBox7.Text = "Cocktails";
            // 
            // pbCocktails_Vino
            // 
            this.pbCocktails_Vino.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pbCocktails_Vino.Location = new System.Drawing.Point(161, 48);
            this.pbCocktails_Vino.Name = "pbCocktails_Vino";
            this.pbCocktails_Vino.Size = new System.Drawing.Size(150, 119);
            this.pbCocktails_Vino.TabIndex = 5;
            this.pbCocktails_Vino.TabStop = false;
            // 
            // cbCocktail5_Vino
            // 
            this.cbCocktail5_Vino.AutoSize = true;
            this.cbCocktail5_Vino.Location = new System.Drawing.Point(7, 148);
            this.cbCocktail5_Vino.Name = "cbCocktail5_Vino";
            this.cbCocktail5_Vino.Size = new System.Drawing.Size(61, 19);
            this.cbCocktail5_Vino.TabIndex = 4;
            this.cbCocktail5_Vino.Text = "Mojito";
            this.cbCocktail5_Vino.UseVisualStyleBackColor = true;
            this.cbCocktail5_Vino.CheckedChanged += new System.EventHandler(this.cbCocktail5_Vino_CheckedChanged);
            // 
            // cbCocktail4_Vino
            // 
            this.cbCocktail4_Vino.AutoSize = true;
            this.cbCocktail4_Vino.Location = new System.Drawing.Point(7, 123);
            this.cbCocktail4_Vino.Name = "cbCocktail4_Vino";
            this.cbCocktail4_Vino.Size = new System.Drawing.Size(62, 19);
            this.cbCocktail4_Vino.TabIndex = 3;
            this.cbCocktail4_Vino.Text = "Negori";
            this.cbCocktail4_Vino.UseVisualStyleBackColor = true;
            this.cbCocktail4_Vino.CheckedChanged += new System.EventHandler(this.cbCocktail4_Vino_CheckedChanged);
            // 
            // cbCocktail3_Vino
            // 
            this.cbCocktail3_Vino.AutoSize = true;
            this.cbCocktail3_Vino.Location = new System.Drawing.Point(7, 98);
            this.cbCocktail3_Vino.Name = "cbCocktail3_Vino";
            this.cbCocktail3_Vino.Size = new System.Drawing.Size(101, 19);
            this.cbCocktail3_Vino.TabIndex = 2;
            this.cbCocktail3_Vino.Text = "Old Fashioned";
            this.cbCocktail3_Vino.UseVisualStyleBackColor = true;
            this.cbCocktail3_Vino.CheckedChanged += new System.EventHandler(this.cbCocktail3_Vino_CheckedChanged);
            // 
            // cbcocktail2_Vino
            // 
            this.cbcocktail2_Vino.AutoSize = true;
            this.cbcocktail2_Vino.Location = new System.Drawing.Point(7, 73);
            this.cbcocktail2_Vino.Name = "cbcocktail2_Vino";
            this.cbcocktail2_Vino.Size = new System.Drawing.Size(77, 19);
            this.cbcocktail2_Vino.TabIndex = 1;
            this.cbcocktail2_Vino.Text = "Margarita";
            this.cbcocktail2_Vino.UseVisualStyleBackColor = true;
            this.cbcocktail2_Vino.CheckedChanged += new System.EventHandler(this.cbcocktail2_Vino_CheckedChanged);
            // 
            // cbcocktail1_Vino
            // 
            this.cbcocktail1_Vino.AutoSize = true;
            this.cbcocktail1_Vino.Location = new System.Drawing.Point(7, 48);
            this.cbcocktail1_Vino.Name = "cbcocktail1_Vino";
            this.cbcocktail1_Vino.Size = new System.Drawing.Size(64, 19);
            this.cbcocktail1_Vino.TabIndex = 0;
            this.cbcocktail1_Vino.Text = "Martini";
            this.cbcocktail1_Vino.UseVisualStyleBackColor = true;
            this.cbcocktail1_Vino.CheckedChanged += new System.EventHandler(this.cbcocktail1_Vino_CheckedChanged);
            // 
            // btnRemove_Vino
            // 
            this.btnRemove_Vino.BackColor = System.Drawing.Color.Red;
            this.btnRemove_Vino.Font = new System.Drawing.Font("Microsoft PhagsPa", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnRemove_Vino.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.btnRemove_Vino.Location = new System.Drawing.Point(1005, 326);
            this.btnRemove_Vino.Name = "btnRemove_Vino";
            this.btnRemove_Vino.Size = new System.Drawing.Size(82, 44);
            this.btnRemove_Vino.TabIndex = 7;
            this.btnRemove_Vino.Text = "Remove Item(s)";
            this.btnRemove_Vino.UseVisualStyleBackColor = false;
            this.btnRemove_Vino.Click += new System.EventHandler(this.btnRemove_Vino_Click);
            // 
            // btnSubmitOrder_Vino
            // 
            this.btnSubmitOrder_Vino.BackColor = System.Drawing.Color.Lime;
            this.btnSubmitOrder_Vino.Font = new System.Drawing.Font("Microsoft PhagsPa", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSubmitOrder_Vino.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.btnSubmitOrder_Vino.Location = new System.Drawing.Point(845, 326);
            this.btnSubmitOrder_Vino.Name = "btnSubmitOrder_Vino";
            this.btnSubmitOrder_Vino.Size = new System.Drawing.Size(83, 44);
            this.btnSubmitOrder_Vino.TabIndex = 6;
            this.btnSubmitOrder_Vino.Text = "Submit Order";
            this.btnSubmitOrder_Vino.UseVisualStyleBackColor = false;
            this.btnSubmitOrder_Vino.Click += new System.EventHandler(this.btnSubmitOrder_Vino_Click);
            // 
            // groupBox5
            // 
            this.groupBox5.Controls.Add(this.lbOrder_Vino);
            this.groupBox5.Font = new System.Drawing.Font("Microsoft PhagsPa", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox5.Location = new System.Drawing.Point(774, 32);
            this.groupBox5.Name = "groupBox5";
            this.groupBox5.Size = new System.Drawing.Size(405, 288);
            this.groupBox5.TabIndex = 5;
            this.groupBox5.TabStop = false;
            this.groupBox5.Text = "Order Summary";
            // 
            // lbOrder_Vino
            // 
            this.lbOrder_Vino.FormattingEnabled = true;
            this.lbOrder_Vino.ItemHeight = 15;
            this.lbOrder_Vino.Location = new System.Drawing.Point(7, 22);
            this.lbOrder_Vino.Name = "lbOrder_Vino";
            this.lbOrder_Vino.Size = new System.Drawing.Size(392, 244);
            this.lbOrder_Vino.TabIndex = 0;
            // 
            // tabPage4
            // 
            this.tabPage4.BackColor = System.Drawing.Color.Silver;
            this.tabPage4.BackgroundImage = global::Restaurant_Reservation_System_FinalProject_26.Properties.Resources._330_768x5911;
            this.tabPage4.Controls.Add(this.btnBackVino_pg3);
            this.tabPage4.Controls.Add(this.groupBox2);
            this.tabPage4.Controls.Add(this.groupBox1);
            this.tabPage4.Location = new System.Drawing.Point(4, 23);
            this.tabPage4.Name = "tabPage4";
            this.tabPage4.Size = new System.Drawing.Size(1212, 480);
            this.tabPage4.TabIndex = 3;
            this.tabPage4.Text = "Payment";
            // 
            // btnBackVino_pg3
            // 
            this.btnBackVino_pg3.BackColor = System.Drawing.Color.Crimson;
            this.btnBackVino_pg3.Font = new System.Drawing.Font("Microsoft PhagsPa", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnBackVino_pg3.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.btnBackVino_pg3.Location = new System.Drawing.Point(1108, 414);
            this.btnBackVino_pg3.Name = "btnBackVino_pg3";
            this.btnBackVino_pg3.Size = new System.Drawing.Size(84, 41);
            this.btnBackVino_pg3.TabIndex = 4;
            this.btnBackVino_pg3.Text = "Back";
            this.btnBackVino_pg3.UseVisualStyleBackColor = false;
            this.btnBackVino_pg3.Click += new System.EventHandler(this.btnBackVino_Click);
            // 
            // groupBox2
            // 
            this.groupBox2.BackColor = System.Drawing.Color.Transparent;
            this.groupBox2.Controls.Add(this.btnPay_Vino);
            this.groupBox2.Controls.Add(this.lblSubTotal_Vino);
            this.groupBox2.Controls.Add(this.lblTotal_Vino);
            this.groupBox2.Controls.Add(this.label17);
            this.groupBox2.Controls.Add(this.lbSummary_Vino);
            this.groupBox2.Controls.Add(this.label19);
            this.groupBox2.Font = new System.Drawing.Font("Microsoft PhagsPa", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox2.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.groupBox2.Location = new System.Drawing.Point(603, 20);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(421, 441);
            this.groupBox2.TabIndex = 3;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Reservation Summary";
            // 
            // btnPay_Vino
            // 
            this.btnPay_Vino.BackColor = System.Drawing.Color.Blue;
            this.btnPay_Vino.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.btnPay_Vino.Location = new System.Drawing.Point(128, 394);
            this.btnPay_Vino.Name = "btnPay_Vino";
            this.btnPay_Vino.Size = new System.Drawing.Size(106, 41);
            this.btnPay_Vino.TabIndex = 7;
            this.btnPay_Vino.Text = "Pay";
            this.btnPay_Vino.UseVisualStyleBackColor = false;
            this.btnPay_Vino.Click += new System.EventHandler(this.btnPay_Vino_Click);
            // 
            // lblSubTotal_Vino
            // 
            this.lblSubTotal_Vino.AutoSize = true;
            this.lblSubTotal_Vino.Location = new System.Drawing.Point(70, 328);
            this.lblSubTotal_Vino.Name = "lblSubTotal_Vino";
            this.lblSubTotal_Vino.Size = new System.Drawing.Size(16, 15);
            this.lblSubTotal_Vino.TabIndex = 6;
            this.lblSubTotal_Vino.Text = "...";
            // 
            // lblTotal_Vino
            // 
            this.lblTotal_Vino.AutoSize = true;
            this.lblTotal_Vino.Location = new System.Drawing.Point(70, 365);
            this.lblTotal_Vino.Name = "lblTotal_Vino";
            this.lblTotal_Vino.Size = new System.Drawing.Size(16, 15);
            this.lblTotal_Vino.TabIndex = 5;
            this.lblTotal_Vino.Text = "...";
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Location = new System.Drawing.Point(6, 328);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(66, 15);
            this.label17.TabIndex = 4;
            this.label17.Text = "SubTotal R:";
            // 
            // lbSummary_Vino
            // 
            this.lbSummary_Vino.FormattingEnabled = true;
            this.lbSummary_Vino.ItemHeight = 15;
            this.lbSummary_Vino.Location = new System.Drawing.Point(6, 21);
            this.lbSummary_Vino.Name = "lbSummary_Vino";
            this.lbSummary_Vino.Size = new System.Drawing.Size(409, 304);
            this.lbSummary_Vino.TabIndex = 3;
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.Location = new System.Drawing.Point(6, 365);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(67, 15);
            this.label19.TabIndex = 2;
            this.label19.Text = "Total        R:";
            // 
            // groupBox1
            // 
            this.groupBox1.BackColor = System.Drawing.Color.Transparent;
            this.groupBox1.Controls.Add(this.pictureBox3);
            this.groupBox1.Controls.Add(this.pictureBox2);
            this.groupBox1.Controls.Add(this.txtCVV_Vino);
            this.groupBox1.Controls.Add(this.label16);
            this.groupBox1.Controls.Add(this.txtExpirydate_Vino);
            this.groupBox1.Controls.Add(this.label15);
            this.groupBox1.Controls.Add(this.pbVino_pay);
            this.groupBox1.Controls.Add(this.txtcrdNo_Vino);
            this.groupBox1.Controls.Add(this.label14);
            this.groupBox1.Controls.Add(this.txtcrdholder_Vino);
            this.groupBox1.Controls.Add(this.label13);
            this.groupBox1.Font = new System.Drawing.Font("Microsoft PhagsPa", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox1.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.groupBox1.Location = new System.Drawing.Point(27, 20);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(421, 380);
            this.groupBox1.TabIndex = 2;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Payment Details";
            // 
            // pictureBox3
            // 
            this.pictureBox3.BackgroundImage = global::Restaurant_Reservation_System_FinalProject_26.Properties.Resources.mastercard;
            this.pictureBox3.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pictureBox3.Location = new System.Drawing.Point(157, 308);
            this.pictureBox3.Name = "pictureBox3";
            this.pictureBox3.Size = new System.Drawing.Size(59, 48);
            this.pictureBox3.TabIndex = 10;
            this.pictureBox3.TabStop = false;
            // 
            // pictureBox2
            // 
            this.pictureBox2.BackgroundImage = global::Restaurant_Reservation_System_FinalProject_26.Properties.Resources.visa;
            this.pictureBox2.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pictureBox2.Location = new System.Drawing.Point(28, 308);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(53, 48);
            this.pictureBox2.TabIndex = 9;
            this.pictureBox2.TabStop = false;
            // 
            // txtCVV_Vino
            // 
            this.txtCVV_Vino.Location = new System.Drawing.Point(157, 251);
            this.txtCVV_Vino.Name = "txtCVV_Vino";
            this.txtCVV_Vino.Size = new System.Drawing.Size(98, 22);
            this.txtCVV_Vino.TabIndex = 8;
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Font = new System.Drawing.Font("Microsoft PhagsPa", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label16.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.label16.Location = new System.Drawing.Point(154, 234);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(30, 14);
            this.label16.TabIndex = 7;
            this.label16.Text = "CVV:";
            // 
            // txtExpirydate_Vino
            // 
            this.txtExpirydate_Vino.Location = new System.Drawing.Point(10, 251);
            this.txtExpirydate_Vino.Name = "txtExpirydate_Vino";
            this.txtExpirydate_Vino.Size = new System.Drawing.Size(98, 22);
            this.txtExpirydate_Vino.TabIndex = 6;
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Font = new System.Drawing.Font("Microsoft PhagsPa", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label15.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.label15.Location = new System.Drawing.Point(7, 234);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(63, 14);
            this.label15.TabIndex = 5;
            this.label15.Text = "Expiry date:";
            // 
            // pbVino_pay
            // 
            this.pbVino_pay.Location = new System.Drawing.Point(10, 139);
            this.pbVino_pay.Name = "pbVino_pay";
            this.pbVino_pay.Size = new System.Drawing.Size(42, 35);
            this.pbVino_pay.TabIndex = 4;
            this.pbVino_pay.TabStop = false;
            // 
            // txtcrdNo_Vino
            // 
            this.txtcrdNo_Vino.Location = new System.Drawing.Point(58, 152);
            this.txtcrdNo_Vino.Name = "txtcrdNo_Vino";
            this.txtcrdNo_Vino.Size = new System.Drawing.Size(272, 22);
            this.txtcrdNo_Vino.TabIndex = 3;
            this.txtcrdNo_Vino.TextChanged += new System.EventHandler(this.txtcrdNo_Vino_TextChanged);
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Font = new System.Drawing.Font("Microsoft PhagsPa", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label14.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.label14.Location = new System.Drawing.Point(7, 122);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(74, 14);
            this.label14.TabIndex = 2;
            this.label14.Text = "Card Number:";
            // 
            // txtcrdholder_Vino
            // 
            this.txtcrdholder_Vino.Location = new System.Drawing.Point(10, 55);
            this.txtcrdholder_Vino.Name = "txtcrdholder_Vino";
            this.txtcrdholder_Vino.Size = new System.Drawing.Size(320, 22);
            this.txtcrdholder_Vino.TabIndex = 1;
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Font = new System.Drawing.Font("Microsoft PhagsPa", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label13.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.label13.Location = new System.Drawing.Point(7, 36);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(101, 14);
            this.label13.TabIndex = 0;
            this.label13.Text = "Cardholder\'s name:";
            // 
            // tabPage5
            // 
            this.tabPage5.BackColor = System.Drawing.Color.Silver;
            this.tabPage5.BackgroundImage = global::Restaurant_Reservation_System_FinalProject_26.Properties.Resources._330_768x5911;
            this.tabPage5.Controls.Add(this.label18);
            this.tabPage5.Controls.Add(this.rtxtReview_Vino);
            this.tabPage5.Controls.Add(this.btnReview_Vino);
            this.tabPage5.Controls.Add(this.lbReview_Vino);
            this.tabPage5.Controls.Add(this.pictureBox5);
            this.tabPage5.Location = new System.Drawing.Point(4, 23);
            this.tabPage5.Name = "tabPage5";
            this.tabPage5.Size = new System.Drawing.Size(1212, 480);
            this.tabPage5.TabIndex = 4;
            this.tabPage5.Text = "Reviews";
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.BackColor = System.Drawing.Color.Transparent;
            this.label18.Font = new System.Drawing.Font("Microsoft PhagsPa", 11F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label18.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.label18.Location = new System.Drawing.Point(427, 322);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(248, 20);
            this.label18.TabIndex = 4;
            this.label18.Text = "Please leave a review down below:";
            // 
            // rtxtReview_Vino
            // 
            this.rtxtReview_Vino.Location = new System.Drawing.Point(431, 345);
            this.rtxtReview_Vino.Name = "rtxtReview_Vino";
            this.rtxtReview_Vino.Size = new System.Drawing.Size(413, 76);
            this.rtxtReview_Vino.TabIndex = 3;
            this.rtxtReview_Vino.Text = "";
            // 
            // btnReview_Vino
            // 
            this.btnReview_Vino.BackColor = System.Drawing.SystemColors.HotTrack;
            this.btnReview_Vino.Font = new System.Drawing.Font("Microsoft PhagsPa", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnReview_Vino.ForeColor = System.Drawing.SystemColors.Info;
            this.btnReview_Vino.Location = new System.Drawing.Point(859, 359);
            this.btnReview_Vino.Name = "btnReview_Vino";
            this.btnReview_Vino.Size = new System.Drawing.Size(95, 38);
            this.btnReview_Vino.TabIndex = 2;
            this.btnReview_Vino.Text = "Comment";
            this.btnReview_Vino.UseVisualStyleBackColor = false;
            this.btnReview_Vino.Click += new System.EventHandler(this.btnReview_Vino_Click);
            // 
            // lbReview_Vino
            // 
            this.lbReview_Vino.FormattingEnabled = true;
            this.lbReview_Vino.ItemHeight = 14;
            this.lbReview_Vino.Location = new System.Drawing.Point(388, 15);
            this.lbReview_Vino.Name = "lbReview_Vino";
            this.lbReview_Vino.Size = new System.Drawing.Size(632, 270);
            this.lbReview_Vino.TabIndex = 1;
            // 
            // pictureBox5
            // 
            this.pictureBox5.BackgroundImage = global::Restaurant_Reservation_System_FinalProject_26.Properties.Resources._330_768x591;
            this.pictureBox5.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pictureBox5.Location = new System.Drawing.Point(21, 15);
            this.pictureBox5.Name = "pictureBox5";
            this.pictureBox5.Size = new System.Drawing.Size(314, 228);
            this.pictureBox5.TabIndex = 0;
            this.pictureBox5.TabStop = false;
            // 
            // Form5
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.MenuHighlight;
            this.ClientSize = new System.Drawing.Size(1238, 541);
            this.Controls.Add(this.tabControl1);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "Form5";
            this.Text = "Vino Santo";
            this.tabControl1.ResumeLayout(false);
            this.tabPage2.ResumeLayout(false);
            this.tabPage2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.tabPage3.ResumeLayout(false);
            this.tabControl2.ResumeLayout(false);
            this.tabPage1.ResumeLayout(false);
            this.tabPage1.PerformLayout();
            this.groupBox6.ResumeLayout(false);
            this.groupBox6.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pbDeserts_Vino)).EndInit();
            this.groupBox4.ResumeLayout(false);
            this.groupBox4.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pbMain_Vino)).EndInit();
            this.groupBox3.ResumeLayout(false);
            this.groupBox3.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pbAppetizers_Vino)).EndInit();
            this.tabPage6.ResumeLayout(false);
            this.groupBox10.ResumeLayout(false);
            this.groupBox10.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pbHotBev_Vino)).EndInit();
            this.groupBox9.ResumeLayout(false);
            this.groupBox9.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pbNonBev_Vino)).EndInit();
            this.groupBox8.ResumeLayout(false);
            this.groupBox8.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pbWines_Vino)).EndInit();
            this.groupBox7.ResumeLayout(false);
            this.groupBox7.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pbCocktails_Vino)).EndInit();
            this.groupBox5.ResumeLayout(false);
            this.tabPage4.ResumeLayout(false);
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbVino_pay)).EndInit();
            this.tabPage5.ResumeLayout(false);
            this.tabPage5.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox5)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TabPage tabPage5;
        private System.Windows.Forms.TabPage tabPage4;
        private System.Windows.Forms.TabPage tabPage3;
        private System.Windows.Forms.TabPage tabPage2;
        private System.Windows.Forms.TabControl tabControl1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox LName_Vino;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox txtFName_Vino;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.TextBox txtPhone_Vino;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.TextBox txtEmail_Vino;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.DateTimePicker dateTime_Vino;
        private System.Windows.Forms.Button btnSubmit_Vino;
        private System.Windows.Forms.TextBox txtRequest_Vino;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.TextBox txtOther_Vino;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.ComboBox cbReserveType_Vino;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.Button btnPay_Vino;
        private System.Windows.Forms.Label lblSubTotal_Vino;
        private System.Windows.Forms.Label lblTotal_Vino;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.ListBox lbSummary_Vino;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.PictureBox pictureBox3;
        private System.Windows.Forms.PictureBox pictureBox2;
        private System.Windows.Forms.TextBox txtCVV_Vino;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.TextBox txtExpirydate_Vino;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.PictureBox pbVino_pay;
        private System.Windows.Forms.TextBox txtcrdNo_Vino;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.TextBox txtcrdholder_Vino;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Button btnBackVino_pg3;
        private System.Windows.Forms.Button btnHomeVino;
        private System.Windows.Forms.Button btnBack_pg2;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.PictureBox pictureBox5;
        private System.Windows.Forms.RichTextBox rtxtReview_Vino;
        private System.Windows.Forms.Button btnReview_Vino;
        private System.Windows.Forms.ListBox lbReview_Vino;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.TabControl tabControl2;
        private System.Windows.Forms.TabPage tabPage1;
        private System.Windows.Forms.GroupBox groupBox4;
        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.GroupBox groupBox6;
        private System.Windows.Forms.CheckBox cbDesert5_Vino;
        private System.Windows.Forms.CheckBox cbDesert4_Vino;
        private System.Windows.Forms.CheckBox cbDesert3_Vino;
        private System.Windows.Forms.CheckBox cbDesert2_Vino;
        private System.Windows.Forms.CheckBox cbDesert1_Vino;
        private System.Windows.Forms.CheckBox cbMain8_Vino;
        private System.Windows.Forms.CheckBox cbMain7_Vino;
        private System.Windows.Forms.CheckBox cbMain6_Vino;
        private System.Windows.Forms.CheckBox cbMain5_Vino;
        private System.Windows.Forms.CheckBox cbMain4_Vino;
        private System.Windows.Forms.CheckBox cbMain3_Vino;
        private System.Windows.Forms.CheckBox cbMain2_Vino;
        private System.Windows.Forms.CheckBox cbMain1_Vino;
        private System.Windows.Forms.CheckBox cbStarter5_Vino;
        private System.Windows.Forms.CheckBox cbStarter4_Vino;
        private System.Windows.Forms.CheckBox cbStarter3_Vino;
        private System.Windows.Forms.CheckBox cbStarter2_Vino;
        private System.Windows.Forms.CheckBox cbStarter1_Vino;
        private System.Windows.Forms.PictureBox pbDeserts_Vino;
        private System.Windows.Forms.PictureBox pbMain_Vino;
        private System.Windows.Forms.PictureBox pbAppetizers_Vino;
        private System.Windows.Forms.TabPage tabPage6;
        private System.Windows.Forms.Button btnRemove_Vino;
        private System.Windows.Forms.Button btnSubmitOrder_Vino;
        private System.Windows.Forms.GroupBox groupBox5;
        private System.Windows.Forms.ListBox lbOrder_Vino;
        private System.Windows.Forms.Label label21;
        private System.Windows.Forms.RichTextBox rtxtAllergies_Vino;
        private System.Windows.Forms.CheckBox cbAllergies_Vino;
        private System.Windows.Forms.Button btnNext_Vino;
        private System.Windows.Forms.Button btnSkip_Vino;
        private System.Windows.Forms.GroupBox groupBox9;
        private System.Windows.Forms.GroupBox groupBox8;
        private System.Windows.Forms.GroupBox groupBox7;
        private System.Windows.Forms.GroupBox groupBox10;
        private System.Windows.Forms.PictureBox pbHotBev_Vino;
        private System.Windows.Forms.CheckBox cbHotBev5_Vino;
        private System.Windows.Forms.CheckBox cbHotBev4_Vino;
        private System.Windows.Forms.CheckBox cbHotBev3_Vino;
        private System.Windows.Forms.CheckBox cbHotBev2_Vino;
        private System.Windows.Forms.CheckBox cbHotBev1_Vino;
        private System.Windows.Forms.PictureBox pbNonBev_Vino;
        private System.Windows.Forms.CheckBox cbNonBev5_Vino;
        private System.Windows.Forms.CheckBox cbNonBev4_Vino;
        private System.Windows.Forms.CheckBox cbNonBev3_Vino;
        private System.Windows.Forms.CheckBox cbNonBev2_Vino;
        private System.Windows.Forms.CheckBox cbNonBev1_Vino;
        private System.Windows.Forms.PictureBox pbWines_Vino;
        private System.Windows.Forms.CheckBox cbWine5_Vino;
        private System.Windows.Forms.CheckBox cbWine4_Vino;
        private System.Windows.Forms.CheckBox cbWine3_Vino;
        private System.Windows.Forms.CheckBox cbWine2_Vino;
        private System.Windows.Forms.CheckBox cbWine1_Vino;
        private System.Windows.Forms.PictureBox pbCocktails_Vino;
        private System.Windows.Forms.CheckBox cbCocktail5_Vino;
        private System.Windows.Forms.CheckBox cbCocktail4_Vino;
        private System.Windows.Forms.CheckBox cbCocktail3_Vino;
        private System.Windows.Forms.CheckBox cbcocktail2_Vino;
        private System.Windows.Forms.CheckBox cbcocktail1_Vino;
        private System.Windows.Forms.TextBox TxtNoOfGuests_Vino;
        private System.Windows.Forms.Label lblNoOfSeats_Vino;
        private System.Windows.Forms.Button btnBack1_Vino;
        private System.Windows.Forms.ComboBox cbTime_Vino;
        private System.Windows.Forms.Label label20;
    }
}