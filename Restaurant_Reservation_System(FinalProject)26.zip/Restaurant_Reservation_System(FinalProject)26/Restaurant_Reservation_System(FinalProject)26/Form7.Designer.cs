﻿namespace Restaurant_Reservation_System_FinalProject_26
{
    partial class Form7
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form7));
            this.tabControl1 = new System.Windows.Forms.TabControl();
            this.tabPage2 = new System.Windows.Forms.TabPage();
            this.cbTime_Asoka = new System.Windows.Forms.ComboBox();
            this.label20 = new System.Windows.Forms.Label();
            this.lblNoOfSeats_Asoka = new System.Windows.Forms.Label();
            this.TxtNoOfGuests_Asoka = new System.Windows.Forms.TextBox();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.btnHomeAsoka = new System.Windows.Forms.Button();
            this.btnSubmit_Asoka = new System.Windows.Forms.Button();
            this.txtAsoka = new System.Windows.Forms.TextBox();
            this.label12 = new System.Windows.Forms.Label();
            this.txtOther_Asoka = new System.Windows.Forms.TextBox();
            this.label11 = new System.Windows.Forms.Label();
            this.cbReserveType_Asoka = new System.Windows.Forms.ComboBox();
            this.label10 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.dateTime_Asoka = new System.Windows.Forms.DateTimePicker();
            this.label8 = new System.Windows.Forms.Label();
            this.txtPhone_Asoka = new System.Windows.Forms.TextBox();
            this.label7 = new System.Windows.Forms.Label();
            this.txtEmail_Asoka = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.txtLName_Asoka = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.txtFName_Asoka = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.tabPage3 = new System.Windows.Forms.TabPage();
            this.tabControl2 = new System.Windows.Forms.TabControl();
            this.tabPage1 = new System.Windows.Forms.TabPage();
            this.btnSkip_Asoka = new System.Windows.Forms.Button();
            this.btnNext_Asoka = new System.Windows.Forms.Button();
            this.label21 = new System.Windows.Forms.Label();
            this.rtxtAllergies_Asoka = new System.Windows.Forms.RichTextBox();
            this.cbAllergies_Asoka = new System.Windows.Forms.CheckBox();
            this.groupBox6 = new System.Windows.Forms.GroupBox();
            this.pbDeserts_Asoka = new System.Windows.Forms.PictureBox();
            this.cbDesert5_Asoka = new System.Windows.Forms.CheckBox();
            this.cbDesert4_Asoka = new System.Windows.Forms.CheckBox();
            this.cbDesert3_Asoka = new System.Windows.Forms.CheckBox();
            this.cbDesert2_Asoka = new System.Windows.Forms.CheckBox();
            this.cbDesert1_Asoka = new System.Windows.Forms.CheckBox();
            this.groupBox4 = new System.Windows.Forms.GroupBox();
            this.pbMain_Asoka = new System.Windows.Forms.PictureBox();
            this.cbMain8_Asoka = new System.Windows.Forms.CheckBox();
            this.cbMain7_Asoka = new System.Windows.Forms.CheckBox();
            this.cbMain6_Asoka = new System.Windows.Forms.CheckBox();
            this.cbMain5_Asoka = new System.Windows.Forms.CheckBox();
            this.cbMain4_Asoka = new System.Windows.Forms.CheckBox();
            this.cbMain3_Asoka = new System.Windows.Forms.CheckBox();
            this.cbMain2_Asoka = new System.Windows.Forms.CheckBox();
            this.cbMain1_Asoka = new System.Windows.Forms.CheckBox();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.pbAppetizers_Asoka = new System.Windows.Forms.PictureBox();
            this.cbStarter5_Asoka = new System.Windows.Forms.CheckBox();
            this.cbStarter4_Asoka = new System.Windows.Forms.CheckBox();
            this.cbStarter3_Asoka = new System.Windows.Forms.CheckBox();
            this.cbStarter2_Asoka = new System.Windows.Forms.CheckBox();
            this.cbStarter1_Asoka = new System.Windows.Forms.CheckBox();
            this.tabPage6 = new System.Windows.Forms.TabPage();
            this.btnBack1_Asoka = new System.Windows.Forms.Button();
            this.groupBox10 = new System.Windows.Forms.GroupBox();
            this.pbHotBev_Asoka = new System.Windows.Forms.PictureBox();
            this.cbHotBev5_Pace = new System.Windows.Forms.CheckBox();
            this.cbHotBev4_Pace = new System.Windows.Forms.CheckBox();
            this.cbHotBev3_Asoka = new System.Windows.Forms.CheckBox();
            this.cbHotBev2_Asoka = new System.Windows.Forms.CheckBox();
            this.cbHotBev1_Asoka = new System.Windows.Forms.CheckBox();
            this.groupBox9 = new System.Windows.Forms.GroupBox();
            this.pbNonBev_Asoka = new System.Windows.Forms.PictureBox();
            this.cbNonBev5_Asoka = new System.Windows.Forms.CheckBox();
            this.cbNonBev4_Asoka = new System.Windows.Forms.CheckBox();
            this.cbNonBev3_Asoka = new System.Windows.Forms.CheckBox();
            this.cbNonBev2_Asoka = new System.Windows.Forms.CheckBox();
            this.cbNonBev1_Asoka = new System.Windows.Forms.CheckBox();
            this.groupBox8 = new System.Windows.Forms.GroupBox();
            this.pbWines_Asoka = new System.Windows.Forms.PictureBox();
            this.cbWine5_Asoka = new System.Windows.Forms.CheckBox();
            this.cbWine4_Asoka = new System.Windows.Forms.CheckBox();
            this.cbWine3_Asoka = new System.Windows.Forms.CheckBox();
            this.cbWine2_Asoka = new System.Windows.Forms.CheckBox();
            this.cbWine1_Asoka = new System.Windows.Forms.CheckBox();
            this.groupBox7 = new System.Windows.Forms.GroupBox();
            this.pbCocktails_Asoka = new System.Windows.Forms.PictureBox();
            this.cbcocktail5_Asoka = new System.Windows.Forms.CheckBox();
            this.cbcocktail4_Asoka = new System.Windows.Forms.CheckBox();
            this.cbcocktail3_Asoka = new System.Windows.Forms.CheckBox();
            this.cbcocktail2_Asoka = new System.Windows.Forms.CheckBox();
            this.cbcocktail1_Asoka = new System.Windows.Forms.CheckBox();
            this.btnRemove_Asoka = new System.Windows.Forms.Button();
            this.btnSubmitOrder_Asoka = new System.Windows.Forms.Button();
            this.groupBox5 = new System.Windows.Forms.GroupBox();
            this.lbOrder_Asoka = new System.Windows.Forms.ListBox();
            this.btnBackAsoka_pg2 = new System.Windows.Forms.Button();
            this.tabPage4 = new System.Windows.Forms.TabPage();
            this.btnBackAsoka_pg3 = new System.Windows.Forms.Button();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.btnPay_Asoka = new System.Windows.Forms.Button();
            this.lblSubTotal_Asoka = new System.Windows.Forms.Label();
            this.lblTotal_Asoka = new System.Windows.Forms.Label();
            this.label17 = new System.Windows.Forms.Label();
            this.lbSummary_Asoka = new System.Windows.Forms.ListBox();
            this.label19 = new System.Windows.Forms.Label();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.pictureBox4 = new System.Windows.Forms.PictureBox();
            this.pictureBox3 = new System.Windows.Forms.PictureBox();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.txtCVV_Asoka = new System.Windows.Forms.TextBox();
            this.label16 = new System.Windows.Forms.Label();
            this.txtExpirydate_Asoka = new System.Windows.Forms.TextBox();
            this.label15 = new System.Windows.Forms.Label();
            this.pbAsoka = new System.Windows.Forms.PictureBox();
            this.txtcrdNo_Asoka = new System.Windows.Forms.TextBox();
            this.label14 = new System.Windows.Forms.Label();
            this.txtcrdholder_Asoka = new System.Windows.Forms.TextBox();
            this.label13 = new System.Windows.Forms.Label();
            this.tabPage5 = new System.Windows.Forms.TabPage();
            this.label18 = new System.Windows.Forms.Label();
            this.rtxtReview_Asoka = new System.Windows.Forms.RichTextBox();
            this.btnReview_Asoka = new System.Windows.Forms.Button();
            this.lbReview_Asoka = new System.Windows.Forms.ListBox();
            this.pictureBox5 = new System.Windows.Forms.PictureBox();
            this.tabControl1.SuspendLayout();
            this.tabPage2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.tabPage3.SuspendLayout();
            this.tabControl2.SuspendLayout();
            this.tabPage1.SuspendLayout();
            this.groupBox6.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pbDeserts_Asoka)).BeginInit();
            this.groupBox4.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pbMain_Asoka)).BeginInit();
            this.groupBox3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pbAppetizers_Asoka)).BeginInit();
            this.tabPage6.SuspendLayout();
            this.groupBox10.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pbHotBev_Asoka)).BeginInit();
            this.groupBox9.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pbNonBev_Asoka)).BeginInit();
            this.groupBox8.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pbWines_Asoka)).BeginInit();
            this.groupBox7.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pbCocktails_Asoka)).BeginInit();
            this.groupBox5.SuspendLayout();
            this.tabPage4.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.groupBox1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbAsoka)).BeginInit();
            this.tabPage5.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox5)).BeginInit();
            this.SuspendLayout();
            // 
            // tabControl1
            // 
            this.tabControl1.Controls.Add(this.tabPage2);
            this.tabControl1.Controls.Add(this.tabPage3);
            this.tabControl1.Controls.Add(this.tabPage4);
            this.tabControl1.Controls.Add(this.tabPage5);
            this.tabControl1.Cursor = System.Windows.Forms.Cursors.Hand;
            this.tabControl1.Font = new System.Drawing.Font("Microsoft PhagsPa", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tabControl1.Location = new System.Drawing.Point(12, 8);
            this.tabControl1.Name = "tabControl1";
            this.tabControl1.SelectedIndex = 0;
            this.tabControl1.Size = new System.Drawing.Size(1232, 507);
            this.tabControl1.TabIndex = 2;
            // 
            // tabPage2
            // 
            this.tabPage2.BackColor = System.Drawing.Color.Silver;
            this.tabPage2.BackgroundImage = global::Restaurant_Reservation_System_FinalProject_26.Properties.Resources.Asoka1;
            this.tabPage2.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.tabPage2.Controls.Add(this.cbTime_Asoka);
            this.tabPage2.Controls.Add(this.label20);
            this.tabPage2.Controls.Add(this.lblNoOfSeats_Asoka);
            this.tabPage2.Controls.Add(this.TxtNoOfGuests_Asoka);
            this.tabPage2.Controls.Add(this.pictureBox1);
            this.tabPage2.Controls.Add(this.btnHomeAsoka);
            this.tabPage2.Controls.Add(this.btnSubmit_Asoka);
            this.tabPage2.Controls.Add(this.txtAsoka);
            this.tabPage2.Controls.Add(this.label12);
            this.tabPage2.Controls.Add(this.txtOther_Asoka);
            this.tabPage2.Controls.Add(this.label11);
            this.tabPage2.Controls.Add(this.cbReserveType_Asoka);
            this.tabPage2.Controls.Add(this.label10);
            this.tabPage2.Controls.Add(this.label9);
            this.tabPage2.Controls.Add(this.dateTime_Asoka);
            this.tabPage2.Controls.Add(this.label8);
            this.tabPage2.Controls.Add(this.txtPhone_Asoka);
            this.tabPage2.Controls.Add(this.label7);
            this.tabPage2.Controls.Add(this.txtEmail_Asoka);
            this.tabPage2.Controls.Add(this.label6);
            this.tabPage2.Controls.Add(this.txtLName_Asoka);
            this.tabPage2.Controls.Add(this.label5);
            this.tabPage2.Controls.Add(this.txtFName_Asoka);
            this.tabPage2.Controls.Add(this.label4);
            this.tabPage2.Controls.Add(this.label3);
            this.tabPage2.Controls.Add(this.label2);
            this.tabPage2.Controls.Add(this.label1);
            this.tabPage2.Location = new System.Drawing.Point(4, 23);
            this.tabPage2.Name = "tabPage2";
            this.tabPage2.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage2.Size = new System.Drawing.Size(1224, 480);
            this.tabPage2.TabIndex = 1;
            this.tabPage2.Text = "Reserving";
            // 
            // cbTime_Asoka
            // 
            this.cbTime_Asoka.BackColor = System.Drawing.SystemColors.ScrollBar;
            this.cbTime_Asoka.FormattingEnabled = true;
            this.cbTime_Asoka.Items.AddRange(new object[] {
            "Choose time to book:",
            "09:00 pm",
            "11:00 pm",
            "13:00 pm",
            "15:00 pm",
            "18:00 pm",
            "21:00 pm"});
            this.cbTime_Asoka.Location = new System.Drawing.Point(400, 315);
            this.cbTime_Asoka.Name = "cbTime_Asoka";
            this.cbTime_Asoka.Size = new System.Drawing.Size(121, 22);
            this.cbTime_Asoka.TabIndex = 55;
            // 
            // label20
            // 
            this.label20.AutoSize = true;
            this.label20.BackColor = System.Drawing.Color.Transparent;
            this.label20.Font = new System.Drawing.Font("Microsoft PhagsPa", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label20.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.label20.Location = new System.Drawing.Point(397, 291);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(45, 20);
            this.label20.TabIndex = 54;
            this.label20.Text = "Time:";
            // 
            // lblNoOfSeats_Asoka
            // 
            this.lblNoOfSeats_Asoka.AutoSize = true;
            this.lblNoOfSeats_Asoka.BackColor = System.Drawing.Color.Transparent;
            this.lblNoOfSeats_Asoka.Font = new System.Drawing.Font("Microsoft PhagsPa", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblNoOfSeats_Asoka.ForeColor = System.Drawing.SystemColors.ControlText;
            this.lblNoOfSeats_Asoka.Location = new System.Drawing.Point(29, 369);
            this.lblNoOfSeats_Asoka.Name = "lblNoOfSeats_Asoka";
            this.lblNoOfSeats_Asoka.Size = new System.Drawing.Size(54, 15);
            this.lblNoOfSeats_Asoka.TabIndex = 51;
            this.lblNoOfSeats_Asoka.Text = "Seats left";
            // 
            // TxtNoOfGuests_Asoka
            // 
            this.TxtNoOfGuests_Asoka.BackColor = System.Drawing.SystemColors.ScrollBar;
            this.TxtNoOfGuests_Asoka.Location = new System.Drawing.Point(32, 336);
            this.TxtNoOfGuests_Asoka.Name = "TxtNoOfGuests_Asoka";
            this.TxtNoOfGuests_Asoka.Size = new System.Drawing.Size(115, 22);
            this.TxtNoOfGuests_Asoka.TabIndex = 48;
            // 
            // pictureBox1
            // 
            this.pictureBox1.BackgroundImage = global::Restaurant_Reservation_System_FinalProject_26.Properties.Resources.asoka_restaurant;
            this.pictureBox1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pictureBox1.Location = new System.Drawing.Point(1028, 6);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(190, 152);
            this.pictureBox1.TabIndex = 47;
            this.pictureBox1.TabStop = false;
            // 
            // btnHomeAsoka
            // 
            this.btnHomeAsoka.BackColor = System.Drawing.Color.Crimson;
            this.btnHomeAsoka.Font = new System.Drawing.Font("Microsoft PhagsPa", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnHomeAsoka.ForeColor = System.Drawing.Color.LavenderBlush;
            this.btnHomeAsoka.Location = new System.Drawing.Point(1068, 394);
            this.btnHomeAsoka.Name = "btnHomeAsoka";
            this.btnHomeAsoka.Size = new System.Drawing.Size(83, 38);
            this.btnHomeAsoka.TabIndex = 46;
            this.btnHomeAsoka.Text = "Home";
            this.btnHomeAsoka.UseVisualStyleBackColor = false;
            this.btnHomeAsoka.Click += new System.EventHandler(this.btnHomeAsoka_Click);
            // 
            // btnSubmit_Asoka
            // 
            this.btnSubmit_Asoka.BackColor = System.Drawing.Color.Lime;
            this.btnSubmit_Asoka.Font = new System.Drawing.Font("Microsoft PhagsPa", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSubmit_Asoka.ForeColor = System.Drawing.SystemColors.HighlightText;
            this.btnSubmit_Asoka.Location = new System.Drawing.Point(747, 282);
            this.btnSubmit_Asoka.Name = "btnSubmit_Asoka";
            this.btnSubmit_Asoka.Size = new System.Drawing.Size(135, 41);
            this.btnSubmit_Asoka.TabIndex = 45;
            this.btnSubmit_Asoka.Text = "Submit";
            this.btnSubmit_Asoka.UseVisualStyleBackColor = false;
            this.btnSubmit_Asoka.Click += new System.EventHandler(this.btnSubmit_Asoka_Click);
            // 
            // txtAsoka
            // 
            this.txtAsoka.BackColor = System.Drawing.SystemColors.ScrollBar;
            this.txtAsoka.Location = new System.Drawing.Point(746, 245);
            this.txtAsoka.Name = "txtAsoka";
            this.txtAsoka.Size = new System.Drawing.Size(199, 22);
            this.txtAsoka.TabIndex = 44;
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.BackColor = System.Drawing.Color.Transparent;
            this.label12.Font = new System.Drawing.Font("Microsoft PhagsPa", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label12.Location = new System.Drawing.Point(743, 222);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(143, 20);
            this.label12.TabIndex = 43;
            this.label12.Text = "Any special requests";
            // 
            // txtOther_Asoka
            // 
            this.txtOther_Asoka.BackColor = System.Drawing.SystemColors.ScrollBar;
            this.txtOther_Asoka.Location = new System.Drawing.Point(747, 191);
            this.txtOther_Asoka.Name = "txtOther_Asoka";
            this.txtOther_Asoka.Size = new System.Drawing.Size(199, 22);
            this.txtOther_Asoka.TabIndex = 42;
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.BackColor = System.Drawing.Color.Transparent;
            this.label11.Font = new System.Drawing.Font("Microsoft PhagsPa", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label11.Location = new System.Drawing.Point(742, 168);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(204, 20);
            this.label11.TabIndex = 41;
            this.label11.Text = "If Other above, please specify";
            // 
            // cbReserveType_Asoka
            // 
            this.cbReserveType_Asoka.BackColor = System.Drawing.SystemColors.ScrollBar;
            this.cbReserveType_Asoka.FormattingEnabled = true;
            this.cbReserveType_Asoka.Items.AddRange(new object[] {
            "Choose reservation type...",
            "Graduation Party",
            "Baby Shower",
            "Engagement Party",
            "Bridal Shower",
            "Retirement Party",
            "Charity Event"});
            this.cbReserveType_Asoka.Location = new System.Drawing.Point(746, 126);
            this.cbReserveType_Asoka.Name = "cbReserveType_Asoka";
            this.cbReserveType_Asoka.Size = new System.Drawing.Size(196, 22);
            this.cbReserveType_Asoka.TabIndex = 40;
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.BackColor = System.Drawing.Color.Transparent;
            this.label10.Font = new System.Drawing.Font("Microsoft PhagsPa", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label10.Location = new System.Drawing.Point(742, 103);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(122, 20);
            this.label10.TabIndex = 39;
            this.label10.Text = "Reservation Type";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.BackColor = System.Drawing.Color.Transparent;
            this.label9.Font = new System.Drawing.Font("Microsoft PhagsPa", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.Location = new System.Drawing.Point(397, 168);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(86, 20);
            this.label9.TabIndex = 38;
            this.label9.Text = "Reservation";
            // 
            // dateTime_Asoka
            // 
            this.dateTime_Asoka.CalendarMonthBackground = System.Drawing.SystemColors.ScrollBar;
            this.dateTime_Asoka.Location = new System.Drawing.Point(400, 191);
            this.dateTime_Asoka.Name = "dateTime_Asoka";
            this.dateTime_Asoka.Size = new System.Drawing.Size(200, 22);
            this.dateTime_Asoka.TabIndex = 37;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.BackColor = System.Drawing.Color.Transparent;
            this.label8.Font = new System.Drawing.Font("Microsoft PhagsPa", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.Location = new System.Drawing.Point(28, 313);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(97, 20);
            this.label8.TabIndex = 35;
            this.label8.Text = "No. of Guests";
            // 
            // txtPhone_Asoka
            // 
            this.txtPhone_Asoka.BackColor = System.Drawing.SystemColors.ScrollBar;
            this.txtPhone_Asoka.Location = new System.Drawing.Point(29, 270);
            this.txtPhone_Asoka.Name = "txtPhone_Asoka";
            this.txtPhone_Asoka.Size = new System.Drawing.Size(285, 22);
            this.txtPhone_Asoka.TabIndex = 34;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.BackColor = System.Drawing.Color.Transparent;
            this.label7.Font = new System.Drawing.Font("Microsoft PhagsPa", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.Location = new System.Drawing.Point(30, 247);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(50, 20);
            this.label7.TabIndex = 33;
            this.label7.Text = "Phone";
            // 
            // txtEmail_Asoka
            // 
            this.txtEmail_Asoka.BackColor = System.Drawing.SystemColors.ScrollBar;
            this.txtEmail_Asoka.Location = new System.Drawing.Point(32, 212);
            this.txtEmail_Asoka.Name = "txtEmail_Asoka";
            this.txtEmail_Asoka.Size = new System.Drawing.Size(285, 22);
            this.txtEmail_Asoka.TabIndex = 32;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.BackColor = System.Drawing.Color.Transparent;
            this.label6.Font = new System.Drawing.Font("Microsoft PhagsPa", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(28, 189);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(52, 20);
            this.label6.TabIndex = 31;
            this.label6.Text = "E-mail";
            // 
            // txtLName_Asoka
            // 
            this.txtLName_Asoka.BackColor = System.Drawing.SystemColors.ScrollBar;
            this.txtLName_Asoka.Location = new System.Drawing.Point(284, 126);
            this.txtLName_Asoka.Name = "txtLName_Asoka";
            this.txtLName_Asoka.Size = new System.Drawing.Size(199, 22);
            this.txtLName_Asoka.TabIndex = 30;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.BackColor = System.Drawing.Color.Transparent;
            this.label5.Location = new System.Drawing.Point(281, 159);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(59, 14);
            this.label5.TabIndex = 29;
            this.label5.Text = "Last Name";
            // 
            // txtFName_Asoka
            // 
            this.txtFName_Asoka.BackColor = System.Drawing.SystemColors.ScrollBar;
            this.txtFName_Asoka.Location = new System.Drawing.Point(29, 126);
            this.txtFName_Asoka.Name = "txtFName_Asoka";
            this.txtFName_Asoka.Size = new System.Drawing.Size(199, 22);
            this.txtFName_Asoka.TabIndex = 28;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.BackColor = System.Drawing.Color.Transparent;
            this.label4.Location = new System.Drawing.Point(26, 159);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(60, 14);
            this.label4.TabIndex = 27;
            this.label4.Text = "First Name";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.BackColor = System.Drawing.Color.Transparent;
            this.label3.Font = new System.Drawing.Font("Microsoft PhagsPa", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(25, 103);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(76, 20);
            this.label3.TabIndex = 26;
            this.label3.Text = "Full Name";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.BackColor = System.Drawing.Color.Transparent;
            this.label2.Font = new System.Drawing.Font("Microsoft PhagsPa", 11F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(25, 67);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(636, 20);
            this.label2.TabIndex = 25;
            this.label2.Text = "Please fill the form below accurately to enable us to serve you better!.. Welcome" +
    " to Asoka";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.Color.Transparent;
            this.label1.Font = new System.Drawing.Font("Microsoft PhagsPa", 16F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(24, 28);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(157, 29);
            this.label1.TabIndex = 24;
            this.label1.Text = "Reserve Table";
            // 
            // tabPage3
            // 
            this.tabPage3.BackColor = System.Drawing.Color.Silver;
            this.tabPage3.BackgroundImage = global::Restaurant_Reservation_System_FinalProject_26.Properties.Resources.Asoka2;
            this.tabPage3.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.tabPage3.Controls.Add(this.tabControl2);
            this.tabPage3.Controls.Add(this.btnBackAsoka_pg2);
            this.tabPage3.Location = new System.Drawing.Point(4, 23);
            this.tabPage3.Name = "tabPage3";
            this.tabPage3.Size = new System.Drawing.Size(1224, 480);
            this.tabPage3.TabIndex = 2;
            this.tabPage3.Text = "Menu";
            // 
            // tabControl2
            // 
            this.tabControl2.Controls.Add(this.tabPage1);
            this.tabControl2.Controls.Add(this.tabPage6);
            this.tabControl2.Location = new System.Drawing.Point(3, 3);
            this.tabControl2.Name = "tabControl2";
            this.tabControl2.SelectedIndex = 0;
            this.tabControl2.Size = new System.Drawing.Size(1218, 442);
            this.tabControl2.TabIndex = 2;
            // 
            // tabPage1
            // 
            this.tabPage1.BackColor = System.Drawing.Color.DarkGray;
            this.tabPage1.Controls.Add(this.btnSkip_Asoka);
            this.tabPage1.Controls.Add(this.btnNext_Asoka);
            this.tabPage1.Controls.Add(this.label21);
            this.tabPage1.Controls.Add(this.rtxtAllergies_Asoka);
            this.tabPage1.Controls.Add(this.cbAllergies_Asoka);
            this.tabPage1.Controls.Add(this.groupBox6);
            this.tabPage1.Controls.Add(this.groupBox4);
            this.tabPage1.Controls.Add(this.groupBox3);
            this.tabPage1.Location = new System.Drawing.Point(4, 23);
            this.tabPage1.Name = "tabPage1";
            this.tabPage1.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage1.Size = new System.Drawing.Size(1210, 415);
            this.tabPage1.TabIndex = 0;
            this.tabPage1.Text = "Food";
            // 
            // btnSkip_Asoka
            // 
            this.btnSkip_Asoka.BackColor = System.Drawing.Color.Green;
            this.btnSkip_Asoka.Font = new System.Drawing.Font("Microsoft PhagsPa", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSkip_Asoka.ForeColor = System.Drawing.SystemColors.Control;
            this.btnSkip_Asoka.Location = new System.Drawing.Point(1143, 6);
            this.btnSkip_Asoka.Name = "btnSkip_Asoka";
            this.btnSkip_Asoka.Size = new System.Drawing.Size(64, 23);
            this.btnSkip_Asoka.TabIndex = 10;
            this.btnSkip_Asoka.Text = "Skip";
            this.btnSkip_Asoka.UseVisualStyleBackColor = false;
            this.btnSkip_Asoka.Click += new System.EventHandler(this.btnSkip_Asoka_Click);
            // 
            // btnNext_Asoka
            // 
            this.btnNext_Asoka.BackColor = System.Drawing.Color.Blue;
            this.btnNext_Asoka.Font = new System.Drawing.Font("Microsoft PhagsPa", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnNext_Asoka.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.btnNext_Asoka.Location = new System.Drawing.Point(1116, 354);
            this.btnNext_Asoka.Name = "btnNext_Asoka";
            this.btnNext_Asoka.Size = new System.Drawing.Size(88, 34);
            this.btnNext_Asoka.TabIndex = 9;
            this.btnNext_Asoka.Text = "Next";
            this.btnNext_Asoka.UseVisualStyleBackColor = false;
            this.btnNext_Asoka.Click += new System.EventHandler(this.btnNext_Asoka_Click);
            // 
            // label21
            // 
            this.label21.AutoSize = true;
            this.label21.Font = new System.Drawing.Font("Microsoft PhagsPa", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label21.Location = new System.Drawing.Point(846, 163);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(196, 15);
            this.label21.TabIndex = 8;
            this.label21.Text = "Please specify your allergies below...";
            // 
            // rtxtAllergies_Asoka
            // 
            this.rtxtAllergies_Asoka.Location = new System.Drawing.Point(849, 187);
            this.rtxtAllergies_Asoka.Name = "rtxtAllergies_Asoka";
            this.rtxtAllergies_Asoka.Size = new System.Drawing.Size(299, 96);
            this.rtxtAllergies_Asoka.TabIndex = 7;
            this.rtxtAllergies_Asoka.Text = "";
            // 
            // cbAllergies_Asoka
            // 
            this.cbAllergies_Asoka.AutoSize = true;
            this.cbAllergies_Asoka.Font = new System.Drawing.Font("Microsoft PhagsPa", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cbAllergies_Asoka.Location = new System.Drawing.Point(849, 121);
            this.cbAllergies_Asoka.Name = "cbAllergies_Asoka";
            this.cbAllergies_Asoka.Size = new System.Drawing.Size(210, 19);
            this.cbAllergies_Asoka.TabIndex = 6;
            this.cbAllergies_Asoka.Text = "If you have allergies, click the box...";
            this.cbAllergies_Asoka.UseVisualStyleBackColor = true;
            // 
            // groupBox6
            // 
            this.groupBox6.Controls.Add(this.pbDeserts_Asoka);
            this.groupBox6.Controls.Add(this.cbDesert5_Asoka);
            this.groupBox6.Controls.Add(this.cbDesert4_Asoka);
            this.groupBox6.Controls.Add(this.cbDesert3_Asoka);
            this.groupBox6.Controls.Add(this.cbDesert2_Asoka);
            this.groupBox6.Controls.Add(this.cbDesert1_Asoka);
            this.groupBox6.Font = new System.Drawing.Font("Microsoft PhagsPa", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox6.Location = new System.Drawing.Point(6, 202);
            this.groupBox6.Name = "groupBox6";
            this.groupBox6.Size = new System.Drawing.Size(351, 186);
            this.groupBox6.TabIndex = 1;
            this.groupBox6.TabStop = false;
            this.groupBox6.Text = "Deserts";
            // 
            // pbDeserts_Asoka
            // 
            this.pbDeserts_Asoka.Location = new System.Drawing.Point(156, 48);
            this.pbDeserts_Asoka.Name = "pbDeserts_Asoka";
            this.pbDeserts_Asoka.Size = new System.Drawing.Size(150, 119);
            this.pbDeserts_Asoka.TabIndex = 6;
            this.pbDeserts_Asoka.TabStop = false;
            // 
            // cbDesert5_Asoka
            // 
            this.cbDesert5_Asoka.AutoSize = true;
            this.cbDesert5_Asoka.Location = new System.Drawing.Point(7, 148);
            this.cbDesert5_Asoka.Name = "cbDesert5_Asoka";
            this.cbDesert5_Asoka.Size = new System.Drawing.Size(86, 19);
            this.cbDesert5_Asoka.TabIndex = 5;
            this.cbDesert5_Asoka.Text = "Cheesecake";
            this.cbDesert5_Asoka.UseVisualStyleBackColor = true;
            // 
            // cbDesert4_Asoka
            // 
            this.cbDesert4_Asoka.AutoSize = true;
            this.cbDesert4_Asoka.Location = new System.Drawing.Point(7, 123);
            this.cbDesert4_Asoka.Name = "cbDesert4_Asoka";
            this.cbDesert4_Asoka.Size = new System.Drawing.Size(104, 19);
            this.cbDesert4_Asoka.TabIndex = 4;
            this.cbDesert4_Asoka.Text = "Bread Pudding";
            this.cbDesert4_Asoka.UseVisualStyleBackColor = true;
            // 
            // cbDesert3_Asoka
            // 
            this.cbDesert3_Asoka.AutoSize = true;
            this.cbDesert3_Asoka.Location = new System.Drawing.Point(7, 98);
            this.cbDesert3_Asoka.Name = "cbDesert3_Asoka";
            this.cbDesert3_Asoka.Size = new System.Drawing.Size(67, 19);
            this.cbDesert3_Asoka.TabIndex = 3;
            this.cbDesert3_Asoka.Text = "Pavlova";
            this.cbDesert3_Asoka.UseVisualStyleBackColor = true;
            // 
            // cbDesert2_Asoka
            // 
            this.cbDesert2_Asoka.AutoSize = true;
            this.cbDesert2_Asoka.Location = new System.Drawing.Point(7, 73);
            this.cbDesert2_Asoka.Name = "cbDesert2_Asoka";
            this.cbDesert2_Asoka.Size = new System.Drawing.Size(86, 19);
            this.cbDesert2_Asoka.TabIndex = 2;
            this.cbDesert2_Asoka.Text = "Profiteroles";
            this.cbDesert2_Asoka.UseVisualStyleBackColor = true;
            // 
            // cbDesert1_Asoka
            // 
            this.cbDesert1_Asoka.AutoSize = true;
            this.cbDesert1_Asoka.Location = new System.Drawing.Point(7, 48);
            this.cbDesert1_Asoka.Name = "cbDesert1_Asoka";
            this.cbDesert1_Asoka.Size = new System.Drawing.Size(85, 19);
            this.cbDesert1_Asoka.TabIndex = 1;
            this.cbDesert1_Asoka.Text = "Lemon Tart";
            this.cbDesert1_Asoka.UseVisualStyleBackColor = true;
            // 
            // groupBox4
            // 
            this.groupBox4.Controls.Add(this.pbMain_Asoka);
            this.groupBox4.Controls.Add(this.cbMain8_Asoka);
            this.groupBox4.Controls.Add(this.cbMain7_Asoka);
            this.groupBox4.Controls.Add(this.cbMain6_Asoka);
            this.groupBox4.Controls.Add(this.cbMain5_Asoka);
            this.groupBox4.Controls.Add(this.cbMain4_Asoka);
            this.groupBox4.Controls.Add(this.cbMain3_Asoka);
            this.groupBox4.Controls.Add(this.cbMain2_Asoka);
            this.groupBox4.Controls.Add(this.cbMain1_Asoka);
            this.groupBox4.Font = new System.Drawing.Font("Microsoft PhagsPa", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox4.Location = new System.Drawing.Point(389, 91);
            this.groupBox4.Name = "groupBox4";
            this.groupBox4.Size = new System.Drawing.Size(360, 240);
            this.groupBox4.TabIndex = 1;
            this.groupBox4.TabStop = false;
            this.groupBox4.Text = "Main Courses(Entrees)";
            // 
            // pbMain_Asoka
            // 
            this.pbMain_Asoka.Location = new System.Drawing.Point(182, 60);
            this.pbMain_Asoka.Name = "pbMain_Asoka";
            this.pbMain_Asoka.Size = new System.Drawing.Size(150, 119);
            this.pbMain_Asoka.TabIndex = 9;
            this.pbMain_Asoka.TabStop = false;
            // 
            // cbMain8_Asoka
            // 
            this.cbMain8_Asoka.AutoSize = true;
            this.cbMain8_Asoka.Location = new System.Drawing.Point(6, 210);
            this.cbMain8_Asoka.Name = "cbMain8_Asoka";
            this.cbMain8_Asoka.Size = new System.Drawing.Size(127, 19);
            this.cbMain8_Asoka.TabIndex = 8;
            this.cbMain8_Asoka.Text = "Eggplant Parmesan";
            this.cbMain8_Asoka.UseVisualStyleBackColor = true;
            // 
            // cbMain7_Asoka
            // 
            this.cbMain7_Asoka.AutoSize = true;
            this.cbMain7_Asoka.Location = new System.Drawing.Point(6, 185);
            this.cbMain7_Asoka.Name = "cbMain7_Asoka";
            this.cbMain7_Asoka.Size = new System.Drawing.Size(70, 19);
            this.cbMain7_Asoka.TabIndex = 7;
            this.cbMain7_Asoka.Text = "Sea Bass";
            this.cbMain7_Asoka.UseVisualStyleBackColor = true;
            // 
            // cbMain6_Asoka
            // 
            this.cbMain6_Asoka.AutoSize = true;
            this.cbMain6_Asoka.Location = new System.Drawing.Point(6, 160);
            this.cbMain6_Asoka.Name = "cbMain6_Asoka";
            this.cbMain6_Asoka.Size = new System.Drawing.Size(109, 19);
            this.cbMain6_Asoka.TabIndex = 6;
            this.cbMain6_Asoka.Text = "Pork Tenderloin";
            this.cbMain6_Asoka.UseVisualStyleBackColor = true;
            // 
            // cbMain5_Asoka
            // 
            this.cbMain5_Asoka.AutoSize = true;
            this.cbMain5_Asoka.Location = new System.Drawing.Point(6, 135);
            this.cbMain5_Asoka.Name = "cbMain5_Asoka";
            this.cbMain5_Asoka.Size = new System.Drawing.Size(87, 19);
            this.cbMain5_Asoka.TabIndex = 5;
            this.cbMain5_Asoka.Text = "Duck Confit";
            this.cbMain5_Asoka.UseVisualStyleBackColor = true;
            // 
            // cbMain4_Asoka
            // 
            this.cbMain4_Asoka.AutoSize = true;
            this.cbMain4_Asoka.Location = new System.Drawing.Point(6, 110);
            this.cbMain4_Asoka.Name = "cbMain4_Asoka";
            this.cbMain4_Asoka.Size = new System.Drawing.Size(80, 19);
            this.cbMain4_Asoka.TabIndex = 4;
            this.cbMain4_Asoka.Text = "Osso Buco";
            this.cbMain4_Asoka.UseVisualStyleBackColor = true;
            // 
            // cbMain3_Asoka
            // 
            this.cbMain3_Asoka.AutoSize = true;
            this.cbMain3_Asoka.Location = new System.Drawing.Point(6, 85);
            this.cbMain3_Asoka.Name = "cbMain3_Asoka";
            this.cbMain3_Asoka.Size = new System.Drawing.Size(94, 19);
            this.cbMain3_Asoka.TabIndex = 3;
            this.cbMain3_Asoka.Text = "Bouillabaisse";
            this.cbMain3_Asoka.UseVisualStyleBackColor = true;
            // 
            // cbMain2_Asoka
            // 
            this.cbMain2_Asoka.AutoSize = true;
            this.cbMain2_Asoka.Location = new System.Drawing.Point(6, 60);
            this.cbMain2_Asoka.Name = "cbMain2_Asoka";
            this.cbMain2_Asoka.Size = new System.Drawing.Size(143, 19);
            this.cbMain2_Asoka.TabIndex = 2;
            this.cbMain2_Asoka.Text = "Vegetarian Wellington";
            this.cbMain2_Asoka.UseVisualStyleBackColor = true;
            // 
            // cbMain1_Asoka
            // 
            this.cbMain1_Asoka.AutoSize = true;
            this.cbMain1_Asoka.Location = new System.Drawing.Point(6, 35);
            this.cbMain1_Asoka.Name = "cbMain1_Asoka";
            this.cbMain1_Asoka.Size = new System.Drawing.Size(111, 19);
            this.cbMain1_Asoka.TabIndex = 1;
            this.cbMain1_Asoka.Text = "Seared Ahi Tuna";
            this.cbMain1_Asoka.UseVisualStyleBackColor = true;
            // 
            // groupBox3
            // 
            this.groupBox3.Controls.Add(this.pbAppetizers_Asoka);
            this.groupBox3.Controls.Add(this.cbStarter5_Asoka);
            this.groupBox3.Controls.Add(this.cbStarter4_Asoka);
            this.groupBox3.Controls.Add(this.cbStarter3_Asoka);
            this.groupBox3.Controls.Add(this.cbStarter2_Asoka);
            this.groupBox3.Controls.Add(this.cbStarter1_Asoka);
            this.groupBox3.Font = new System.Drawing.Font("Microsoft PhagsPa", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox3.Location = new System.Drawing.Point(6, 6);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Size = new System.Drawing.Size(351, 190);
            this.groupBox3.TabIndex = 0;
            this.groupBox3.TabStop = false;
            this.groupBox3.Text = "Appetizers (Starters)";
            // 
            // pbAppetizers_Asoka
            // 
            this.pbAppetizers_Asoka.Location = new System.Drawing.Point(156, 35);
            this.pbAppetizers_Asoka.Name = "pbAppetizers_Asoka";
            this.pbAppetizers_Asoka.Size = new System.Drawing.Size(150, 119);
            this.pbAppetizers_Asoka.TabIndex = 5;
            this.pbAppetizers_Asoka.TabStop = false;
            // 
            // cbStarter5_Asoka
            // 
            this.cbStarter5_Asoka.AutoSize = true;
            this.cbStarter5_Asoka.Location = new System.Drawing.Point(7, 135);
            this.cbStarter5_Asoka.Name = "cbStarter5_Asoka";
            this.cbStarter5_Asoka.Size = new System.Drawing.Size(130, 19);
            this.cbStarter5_Asoka.TabIndex = 4;
            this.cbStarter5_Asoka.Text = "Stuffed Mushrooms";
            this.cbStarter5_Asoka.UseVisualStyleBackColor = true;
            // 
            // cbStarter4_Asoka
            // 
            this.cbStarter4_Asoka.AutoSize = true;
            this.cbStarter4_Asoka.Location = new System.Drawing.Point(7, 110);
            this.cbStarter4_Asoka.Name = "cbStarter4_Asoka";
            this.cbStarter4_Asoka.Size = new System.Drawing.Size(58, 19);
            this.cbStarter4_Asoka.TabIndex = 3;
            this.cbStarter4_Asoka.Text = "Caviar";
            this.cbStarter4_Asoka.UseVisualStyleBackColor = true;
            // 
            // cbStarter3_Asoka
            // 
            this.cbStarter3_Asoka.AutoSize = true;
            this.cbStarter3_Asoka.Location = new System.Drawing.Point(7, 85);
            this.cbStarter3_Asoka.Name = "cbStarter3_Asoka";
            this.cbStarter3_Asoka.Size = new System.Drawing.Size(106, 19);
            this.cbStarter3_Asoka.TabIndex = 2;
            this.cbStarter3_Asoka.Text = "Seared Scallops";
            this.cbStarter3_Asoka.UseVisualStyleBackColor = true;
            // 
            // cbStarter2_Asoka
            // 
            this.cbStarter2_Asoka.AutoSize = true;
            this.cbStarter2_Asoka.Location = new System.Drawing.Point(6, 60);
            this.cbStarter2_Asoka.Name = "cbStarter2_Asoka";
            this.cbStarter2_Asoka.Size = new System.Drawing.Size(64, 19);
            this.cbStarter2_Asoka.TabIndex = 1;
            this.cbStarter2_Asoka.Text = "Burrata";
            this.cbStarter2_Asoka.UseVisualStyleBackColor = true;
            // 
            // cbStarter1_Asoka
            // 
            this.cbStarter1_Asoka.AutoSize = true;
            this.cbStarter1_Asoka.Location = new System.Drawing.Point(7, 35);
            this.cbStarter1_Asoka.Name = "cbStarter1_Asoka";
            this.cbStarter1_Asoka.Size = new System.Drawing.Size(103, 19);
            this.cbStarter1_Asoka.TabIndex = 0;
            this.cbStarter1_Asoka.Text = "Lobster Bisque";
            this.cbStarter1_Asoka.UseVisualStyleBackColor = true;
            // 
            // tabPage6
            // 
            this.tabPage6.BackColor = System.Drawing.Color.DarkGray;
            this.tabPage6.Controls.Add(this.btnBack1_Asoka);
            this.tabPage6.Controls.Add(this.groupBox10);
            this.tabPage6.Controls.Add(this.groupBox9);
            this.tabPage6.Controls.Add(this.groupBox8);
            this.tabPage6.Controls.Add(this.groupBox7);
            this.tabPage6.Controls.Add(this.btnRemove_Asoka);
            this.tabPage6.Controls.Add(this.btnSubmitOrder_Asoka);
            this.tabPage6.Controls.Add(this.groupBox5);
            this.tabPage6.Location = new System.Drawing.Point(4, 23);
            this.tabPage6.Name = "tabPage6";
            this.tabPage6.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage6.Size = new System.Drawing.Size(1210, 415);
            this.tabPage6.TabIndex = 1;
            this.tabPage6.Text = "Drinks";
            // 
            // btnBack1_Asoka
            // 
            this.btnBack1_Asoka.BackColor = System.Drawing.Color.Red;
            this.btnBack1_Asoka.Font = new System.Drawing.Font("Microsoft PhagsPa", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnBack1_Asoka.ForeColor = System.Drawing.SystemColors.MenuBar;
            this.btnBack1_Asoka.Location = new System.Drawing.Point(1139, 3);
            this.btnBack1_Asoka.Name = "btnBack1_Asoka";
            this.btnBack1_Asoka.Size = new System.Drawing.Size(65, 26);
            this.btnBack1_Asoka.TabIndex = 15;
            this.btnBack1_Asoka.Text = "Food";
            this.btnBack1_Asoka.UseVisualStyleBackColor = false;
            this.btnBack1_Asoka.Click += new System.EventHandler(this.btnBack1_Asoka_Click);
            // 
            // groupBox10
            // 
            this.groupBox10.Controls.Add(this.pbHotBev_Asoka);
            this.groupBox10.Controls.Add(this.cbHotBev5_Pace);
            this.groupBox10.Controls.Add(this.cbHotBev4_Pace);
            this.groupBox10.Controls.Add(this.cbHotBev3_Asoka);
            this.groupBox10.Controls.Add(this.cbHotBev2_Asoka);
            this.groupBox10.Controls.Add(this.cbHotBev1_Asoka);
            this.groupBox10.Font = new System.Drawing.Font("Microsoft PhagsPa", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox10.Location = new System.Drawing.Point(402, 212);
            this.groupBox10.Name = "groupBox10";
            this.groupBox10.Size = new System.Drawing.Size(374, 192);
            this.groupBox10.TabIndex = 14;
            this.groupBox10.TabStop = false;
            this.groupBox10.Text = "Hot Beverages";
            // 
            // pbHotBev_Asoka
            // 
            this.pbHotBev_Asoka.Location = new System.Drawing.Point(206, 34);
            this.pbHotBev_Asoka.Name = "pbHotBev_Asoka";
            this.pbHotBev_Asoka.Size = new System.Drawing.Size(150, 119);
            this.pbHotBev_Asoka.TabIndex = 10;
            this.pbHotBev_Asoka.TabStop = false;
            // 
            // cbHotBev5_Pace
            // 
            this.cbHotBev5_Pace.AutoSize = true;
            this.cbHotBev5_Pace.Location = new System.Drawing.Point(15, 137);
            this.cbHotBev5_Pace.Name = "cbHotBev5_Pace";
            this.cbHotBev5_Pace.Size = new System.Drawing.Size(81, 19);
            this.cbHotBev5_Pace.TabIndex = 9;
            this.cbHotBev5_Pace.Text = "Hot Toddy";
            this.cbHotBev5_Pace.UseVisualStyleBackColor = true;
            // 
            // cbHotBev4_Pace
            // 
            this.cbHotBev4_Pace.AutoSize = true;
            this.cbHotBev4_Pace.Location = new System.Drawing.Point(15, 112);
            this.cbHotBev4_Pace.Name = "cbHotBev4_Pace";
            this.cbHotBev4_Pace.Size = new System.Drawing.Size(93, 19);
            this.cbHotBev4_Pace.TabIndex = 8;
            this.cbHotBev4_Pace.Text = "Mulled Wine";
            this.cbHotBev4_Pace.UseVisualStyleBackColor = true;
            // 
            // cbHotBev3_Asoka
            // 
            this.cbHotBev3_Asoka.AutoSize = true;
            this.cbHotBev3_Asoka.Location = new System.Drawing.Point(15, 87);
            this.cbHotBev3_Asoka.Name = "cbHotBev3_Asoka";
            this.cbHotBev3_Asoka.Size = new System.Drawing.Size(94, 19);
            this.cbHotBev3_Asoka.TabIndex = 7;
            this.cbHotBev3_Asoka.Text = "Matcha Latte";
            this.cbHotBev3_Asoka.UseVisualStyleBackColor = true;
            // 
            // cbHotBev2_Asoka
            // 
            this.cbHotBev2_Asoka.AutoSize = true;
            this.cbHotBev2_Asoka.Location = new System.Drawing.Point(15, 62);
            this.cbHotBev2_Asoka.Name = "cbHotBev2_Asoka";
            this.cbHotBev2_Asoka.Size = new System.Drawing.Size(90, 19);
            this.cbHotBev2_Asoka.TabIndex = 6;
            this.cbHotBev2_Asoka.Text = "Golden Milk";
            this.cbHotBev2_Asoka.UseVisualStyleBackColor = true;
            // 
            // cbHotBev1_Asoka
            // 
            this.cbHotBev1_Asoka.AutoSize = true;
            this.cbHotBev1_Asoka.Location = new System.Drawing.Point(15, 37);
            this.cbHotBev1_Asoka.Name = "cbHotBev1_Asoka";
            this.cbHotBev1_Asoka.Size = new System.Drawing.Size(100, 19);
            this.cbHotBev1_Asoka.TabIndex = 5;
            this.cbHotBev1_Asoka.Text = "Hot Chocolate";
            this.cbHotBev1_Asoka.UseVisualStyleBackColor = true;
            // 
            // groupBox9
            // 
            this.groupBox9.Controls.Add(this.pbNonBev_Asoka);
            this.groupBox9.Controls.Add(this.cbNonBev5_Asoka);
            this.groupBox9.Controls.Add(this.cbNonBev4_Asoka);
            this.groupBox9.Controls.Add(this.cbNonBev3_Asoka);
            this.groupBox9.Controls.Add(this.cbNonBev2_Asoka);
            this.groupBox9.Controls.Add(this.cbNonBev1_Asoka);
            this.groupBox9.Font = new System.Drawing.Font("Microsoft PhagsPa", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox9.Location = new System.Drawing.Point(402, 0);
            this.groupBox9.Name = "groupBox9";
            this.groupBox9.Size = new System.Drawing.Size(374, 203);
            this.groupBox9.TabIndex = 12;
            this.groupBox9.TabStop = false;
            this.groupBox9.Text = "Non-Alcoholic Beverages";
            // 
            // pbNonBev_Asoka
            // 
            this.pbNonBev_Asoka.Location = new System.Drawing.Point(206, 38);
            this.pbNonBev_Asoka.Name = "pbNonBev_Asoka";
            this.pbNonBev_Asoka.Size = new System.Drawing.Size(150, 119);
            this.pbNonBev_Asoka.TabIndex = 10;
            this.pbNonBev_Asoka.TabStop = false;
            // 
            // cbNonBev5_Asoka
            // 
            this.cbNonBev5_Asoka.AutoSize = true;
            this.cbNonBev5_Asoka.Location = new System.Drawing.Point(14, 142);
            this.cbNonBev5_Asoka.Name = "cbNonBev5_Asoka";
            this.cbNonBev5_Asoka.Size = new System.Drawing.Size(81, 19);
            this.cbNonBev5_Asoka.TabIndex = 9;
            this.cbNonBev5_Asoka.Text = "Lemonade";
            this.cbNonBev5_Asoka.UseVisualStyleBackColor = true;
            // 
            // cbNonBev4_Asoka
            // 
            this.cbNonBev4_Asoka.AutoSize = true;
            this.cbNonBev4_Asoka.Location = new System.Drawing.Point(14, 117);
            this.cbNonBev4_Asoka.Name = "cbNonBev4_Asoka";
            this.cbNonBev4_Asoka.Size = new System.Drawing.Size(124, 19);
            this.cbNonBev4_Asoka.TabIndex = 8;
            this.cbNonBev4_Asoka.Text = "%100 Mango Juice";
            this.cbNonBev4_Asoka.UseVisualStyleBackColor = true;
            // 
            // cbNonBev3_Asoka
            // 
            this.cbNonBev3_Asoka.AutoSize = true;
            this.cbNonBev3_Asoka.Location = new System.Drawing.Point(14, 92);
            this.cbNonBev3_Asoka.Name = "cbNonBev3_Asoka";
            this.cbNonBev3_Asoka.Size = new System.Drawing.Size(186, 19);
            this.cbNonBev3_Asoka.TabIndex = 7;
            this.cbNonBev3_Asoka.Text = "Freshly Squeezed Orange Juice";
            this.cbNonBev3_Asoka.UseVisualStyleBackColor = true;
            // 
            // cbNonBev2_Asoka
            // 
            this.cbNonBev2_Asoka.AutoSize = true;
            this.cbNonBev2_Asoka.Location = new System.Drawing.Point(14, 67);
            this.cbNonBev2_Asoka.Name = "cbNonBev2_Asoka";
            this.cbNonBev2_Asoka.Size = new System.Drawing.Size(109, 19);
            this.cbNonBev2_Asoka.TabIndex = 6;
            this.cbNonBev2_Asoka.Text = "Sparkilng Water";
            this.cbNonBev2_Asoka.UseVisualStyleBackColor = true;
            // 
            // cbNonBev1_Asoka
            // 
            this.cbNonBev1_Asoka.AutoSize = true;
            this.cbNonBev1_Asoka.Location = new System.Drawing.Point(14, 42);
            this.cbNonBev1_Asoka.Name = "cbNonBev1_Asoka";
            this.cbNonBev1_Asoka.Size = new System.Drawing.Size(112, 19);
            this.cbNonBev1_Asoka.TabIndex = 5;
            this.cbNonBev1_Asoka.Text = "Flavoured Water";
            this.cbNonBev1_Asoka.UseVisualStyleBackColor = true;
            // 
            // groupBox8
            // 
            this.groupBox8.Controls.Add(this.pbWines_Asoka);
            this.groupBox8.Controls.Add(this.cbWine5_Asoka);
            this.groupBox8.Controls.Add(this.cbWine4_Asoka);
            this.groupBox8.Controls.Add(this.cbWine3_Asoka);
            this.groupBox8.Controls.Add(this.cbWine2_Asoka);
            this.groupBox8.Controls.Add(this.cbWine1_Asoka);
            this.groupBox8.Font = new System.Drawing.Font("Microsoft PhagsPa", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox8.Location = new System.Drawing.Point(9, 209);
            this.groupBox8.Name = "groupBox8";
            this.groupBox8.Size = new System.Drawing.Size(348, 192);
            this.groupBox8.TabIndex = 13;
            this.groupBox8.TabStop = false;
            this.groupBox8.Text = "Wines";
            // 
            // pbWines_Asoka
            // 
            this.pbWines_Asoka.Location = new System.Drawing.Point(161, 40);
            this.pbWines_Asoka.Name = "pbWines_Asoka";
            this.pbWines_Asoka.Size = new System.Drawing.Size(150, 119);
            this.pbWines_Asoka.TabIndex = 6;
            this.pbWines_Asoka.TabStop = false;
            // 
            // cbWine5_Asoka
            // 
            this.cbWine5_Asoka.AutoSize = true;
            this.cbWine5_Asoka.Location = new System.Drawing.Point(10, 137);
            this.cbWine5_Asoka.Name = "cbWine5_Asoka";
            this.cbWine5_Asoka.Size = new System.Drawing.Size(51, 19);
            this.cbWine5_Asoka.TabIndex = 9;
            this.cbWine5_Asoka.Text = "Rose";
            this.cbWine5_Asoka.UseVisualStyleBackColor = true;
            // 
            // cbWine4_Asoka
            // 
            this.cbWine4_Asoka.AutoSize = true;
            this.cbWine4_Asoka.Location = new System.Drawing.Point(10, 112);
            this.cbWine4_Asoka.Name = "cbWine4_Asoka";
            this.cbWine4_Asoka.Size = new System.Drawing.Size(113, 19);
            this.cbWine4_Asoka.TabIndex = 8;
            this.cbWine4_Asoka.Text = "Sauvignon Blanc";
            this.cbWine4_Asoka.UseVisualStyleBackColor = true;
            // 
            // cbWine3_Asoka
            // 
            this.cbWine3_Asoka.AutoSize = true;
            this.cbWine3_Asoka.Location = new System.Drawing.Point(10, 87);
            this.cbWine3_Asoka.Name = "cbWine3_Asoka";
            this.cbWine3_Asoka.Size = new System.Drawing.Size(80, 19);
            this.cbWine3_Asoka.TabIndex = 7;
            this.cbWine3_Asoka.Text = "Pinot Noir";
            this.cbWine3_Asoka.UseVisualStyleBackColor = true;
            // 
            // cbWine2_Asoka
            // 
            this.cbWine2_Asoka.AutoSize = true;
            this.cbWine2_Asoka.Location = new System.Drawing.Point(10, 62);
            this.cbWine2_Asoka.Name = "cbWine2_Asoka";
            this.cbWine2_Asoka.Size = new System.Drawing.Size(76, 19);
            this.cbWine2_Asoka.TabIndex = 6;
            this.cbWine2_Asoka.Text = "Zinfandel";
            this.cbWine2_Asoka.UseVisualStyleBackColor = true;
            // 
            // cbWine1_Asoka
            // 
            this.cbWine1_Asoka.AutoSize = true;
            this.cbWine1_Asoka.Location = new System.Drawing.Point(10, 37);
            this.cbWine1_Asoka.Name = "cbWine1_Asoka";
            this.cbWine1_Asoka.Size = new System.Drawing.Size(91, 19);
            this.cbWine1_Asoka.TabIndex = 5;
            this.cbWine1_Asoka.Text = "Syrah/Shiraz";
            this.cbWine1_Asoka.UseVisualStyleBackColor = true;
            // 
            // groupBox7
            // 
            this.groupBox7.Controls.Add(this.pbCocktails_Asoka);
            this.groupBox7.Controls.Add(this.cbcocktail5_Asoka);
            this.groupBox7.Controls.Add(this.cbcocktail4_Asoka);
            this.groupBox7.Controls.Add(this.cbcocktail3_Asoka);
            this.groupBox7.Controls.Add(this.cbcocktail2_Asoka);
            this.groupBox7.Controls.Add(this.cbcocktail1_Asoka);
            this.groupBox7.Font = new System.Drawing.Font("Microsoft PhagsPa", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox7.Location = new System.Drawing.Point(9, 0);
            this.groupBox7.Name = "groupBox7";
            this.groupBox7.Size = new System.Drawing.Size(348, 203);
            this.groupBox7.TabIndex = 11;
            this.groupBox7.TabStop = false;
            this.groupBox7.Text = "Cocktails";
            // 
            // pbCocktails_Asoka
            // 
            this.pbCocktails_Asoka.Location = new System.Drawing.Point(161, 48);
            this.pbCocktails_Asoka.Name = "pbCocktails_Asoka";
            this.pbCocktails_Asoka.Size = new System.Drawing.Size(150, 119);
            this.pbCocktails_Asoka.TabIndex = 5;
            this.pbCocktails_Asoka.TabStop = false;
            // 
            // cbcocktail5_Asoka
            // 
            this.cbcocktail5_Asoka.AutoSize = true;
            this.cbcocktail5_Asoka.Location = new System.Drawing.Point(7, 148);
            this.cbcocktail5_Asoka.Name = "cbcocktail5_Asoka";
            this.cbcocktail5_Asoka.Size = new System.Drawing.Size(88, 19);
            this.cbcocktail5_Asoka.TabIndex = 4;
            this.cbcocktail5_Asoka.Text = "Pina Colada";
            this.cbcocktail5_Asoka.UseVisualStyleBackColor = true;
            // 
            // cbcocktail4_Asoka
            // 
            this.cbcocktail4_Asoka.AutoSize = true;
            this.cbcocktail4_Asoka.Location = new System.Drawing.Point(7, 123);
            this.cbcocktail4_Asoka.Name = "cbcocktail4_Asoka";
            this.cbcocktail4_Asoka.Size = new System.Drawing.Size(73, 19);
            this.cbcocktail4_Asoka.TabIndex = 3;
            this.cbcocktail4_Asoka.Text = "Magarita";
            this.cbcocktail4_Asoka.UseVisualStyleBackColor = true;
            // 
            // cbcocktail3_Asoka
            // 
            this.cbcocktail3_Asoka.AutoSize = true;
            this.cbcocktail3_Asoka.Location = new System.Drawing.Point(7, 98);
            this.cbcocktail3_Asoka.Name = "cbcocktail3_Asoka";
            this.cbcocktail3_Asoka.Size = new System.Drawing.Size(62, 19);
            this.cbcocktail3_Asoka.TabIndex = 2;
            this.cbcocktail3_Asoka.Text = "Negori";
            this.cbcocktail3_Asoka.UseVisualStyleBackColor = true;
            // 
            // cbcocktail2_Asoka
            // 
            this.cbcocktail2_Asoka.AutoSize = true;
            this.cbcocktail2_Asoka.Location = new System.Drawing.Point(6, 73);
            this.cbcocktail2_Asoka.Name = "cbcocktail2_Asoka";
            this.cbcocktail2_Asoka.Size = new System.Drawing.Size(92, 19);
            this.cbcocktail2_Asoka.TabIndex = 1;
            this.cbcocktail2_Asoka.Text = "Cosmoplitan";
            this.cbcocktail2_Asoka.UseVisualStyleBackColor = true;
            // 
            // cbcocktail1_Asoka
            // 
            this.cbcocktail1_Asoka.AutoSize = true;
            this.cbcocktail1_Asoka.Location = new System.Drawing.Point(7, 48);
            this.cbcocktail1_Asoka.Name = "cbcocktail1_Asoka";
            this.cbcocktail1_Asoka.Size = new System.Drawing.Size(98, 19);
            this.cbcocktail1_Asoka.TabIndex = 0;
            this.cbcocktail1_Asoka.Text = "Gin and Tonic";
            this.cbcocktail1_Asoka.UseVisualStyleBackColor = true;
            // 
            // btnRemove_Asoka
            // 
            this.btnRemove_Asoka.BackColor = System.Drawing.Color.Red;
            this.btnRemove_Asoka.Font = new System.Drawing.Font("Microsoft PhagsPa", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnRemove_Asoka.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.btnRemove_Asoka.Location = new System.Drawing.Point(1055, 332);
            this.btnRemove_Asoka.Name = "btnRemove_Asoka";
            this.btnRemove_Asoka.Size = new System.Drawing.Size(82, 44);
            this.btnRemove_Asoka.TabIndex = 7;
            this.btnRemove_Asoka.Text = "Remove Item(s)";
            this.btnRemove_Asoka.UseVisualStyleBackColor = false;
            // 
            // btnSubmitOrder_Asoka
            // 
            this.btnSubmitOrder_Asoka.BackColor = System.Drawing.Color.Lime;
            this.btnSubmitOrder_Asoka.Font = new System.Drawing.Font("Microsoft PhagsPa", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSubmitOrder_Asoka.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.btnSubmitOrder_Asoka.Location = new System.Drawing.Point(898, 332);
            this.btnSubmitOrder_Asoka.Name = "btnSubmitOrder_Asoka";
            this.btnSubmitOrder_Asoka.Size = new System.Drawing.Size(83, 44);
            this.btnSubmitOrder_Asoka.TabIndex = 6;
            this.btnSubmitOrder_Asoka.Text = "Submit Order";
            this.btnSubmitOrder_Asoka.UseVisualStyleBackColor = false;
            this.btnSubmitOrder_Asoka.Click += new System.EventHandler(this.btnSubmitOrder_Asoka_Click);
            // 
            // groupBox5
            // 
            this.groupBox5.Controls.Add(this.lbOrder_Asoka);
            this.groupBox5.Font = new System.Drawing.Font("Microsoft PhagsPa", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox5.Location = new System.Drawing.Point(799, 38);
            this.groupBox5.Name = "groupBox5";
            this.groupBox5.Size = new System.Drawing.Size(405, 288);
            this.groupBox5.TabIndex = 5;
            this.groupBox5.TabStop = false;
            this.groupBox5.Text = "Order Summary";
            // 
            // lbOrder_Asoka
            // 
            this.lbOrder_Asoka.FormattingEnabled = true;
            this.lbOrder_Asoka.ItemHeight = 15;
            this.lbOrder_Asoka.Location = new System.Drawing.Point(7, 22);
            this.lbOrder_Asoka.Name = "lbOrder_Asoka";
            this.lbOrder_Asoka.Size = new System.Drawing.Size(392, 244);
            this.lbOrder_Asoka.TabIndex = 0;
            // 
            // btnBackAsoka_pg2
            // 
            this.btnBackAsoka_pg2.BackColor = System.Drawing.Color.Crimson;
            this.btnBackAsoka_pg2.Font = new System.Drawing.Font("Microsoft PhagsPa", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnBackAsoka_pg2.ForeColor = System.Drawing.SystemColors.Info;
            this.btnBackAsoka_pg2.Location = new System.Drawing.Point(1167, 451);
            this.btnBackAsoka_pg2.Name = "btnBackAsoka_pg2";
            this.btnBackAsoka_pg2.Size = new System.Drawing.Size(54, 26);
            this.btnBackAsoka_pg2.TabIndex = 0;
            this.btnBackAsoka_pg2.Text = "Back";
            this.btnBackAsoka_pg2.UseVisualStyleBackColor = false;
            this.btnBackAsoka_pg2.Click += new System.EventHandler(this.btnBackAsoka_pg2_Click);
            // 
            // tabPage4
            // 
            this.tabPage4.BackColor = System.Drawing.Color.Silver;
            this.tabPage4.BackgroundImage = global::Restaurant_Reservation_System_FinalProject_26.Properties.Resources.Asoka2;
            this.tabPage4.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.tabPage4.Controls.Add(this.btnBackAsoka_pg3);
            this.tabPage4.Controls.Add(this.groupBox2);
            this.tabPage4.Controls.Add(this.groupBox1);
            this.tabPage4.Location = new System.Drawing.Point(4, 23);
            this.tabPage4.Name = "tabPage4";
            this.tabPage4.Size = new System.Drawing.Size(1224, 480);
            this.tabPage4.TabIndex = 3;
            this.tabPage4.Text = "Payment";
            // 
            // btnBackAsoka_pg3
            // 
            this.btnBackAsoka_pg3.BackColor = System.Drawing.Color.Crimson;
            this.btnBackAsoka_pg3.Font = new System.Drawing.Font("Microsoft PhagsPa", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnBackAsoka_pg3.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.btnBackAsoka_pg3.Location = new System.Drawing.Point(1091, 413);
            this.btnBackAsoka_pg3.Name = "btnBackAsoka_pg3";
            this.btnBackAsoka_pg3.Size = new System.Drawing.Size(84, 41);
            this.btnBackAsoka_pg3.TabIndex = 5;
            this.btnBackAsoka_pg3.Text = "Back";
            this.btnBackAsoka_pg3.UseVisualStyleBackColor = false;
            this.btnBackAsoka_pg3.Click += new System.EventHandler(this.btnBackAsoka_pg3_Click);
            // 
            // groupBox2
            // 
            this.groupBox2.BackColor = System.Drawing.Color.Transparent;
            this.groupBox2.Controls.Add(this.btnPay_Asoka);
            this.groupBox2.Controls.Add(this.lblSubTotal_Asoka);
            this.groupBox2.Controls.Add(this.lblTotal_Asoka);
            this.groupBox2.Controls.Add(this.label17);
            this.groupBox2.Controls.Add(this.lbSummary_Asoka);
            this.groupBox2.Controls.Add(this.label19);
            this.groupBox2.Font = new System.Drawing.Font("Microsoft PhagsPa", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox2.Location = new System.Drawing.Point(595, 19);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(421, 441);
            this.groupBox2.TabIndex = 1;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Reservation Summary";
            // 
            // btnPay_Asoka
            // 
            this.btnPay_Asoka.BackColor = System.Drawing.Color.Blue;
            this.btnPay_Asoka.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.btnPay_Asoka.Location = new System.Drawing.Point(142, 394);
            this.btnPay_Asoka.Name = "btnPay_Asoka";
            this.btnPay_Asoka.Size = new System.Drawing.Size(106, 41);
            this.btnPay_Asoka.TabIndex = 7;
            this.btnPay_Asoka.Text = "Pay";
            this.btnPay_Asoka.UseVisualStyleBackColor = false;
            this.btnPay_Asoka.Click += new System.EventHandler(this.btnPay_Asoka_Click);
            // 
            // lblSubTotal_Asoka
            // 
            this.lblSubTotal_Asoka.AutoSize = true;
            this.lblSubTotal_Asoka.Location = new System.Drawing.Point(70, 328);
            this.lblSubTotal_Asoka.Name = "lblSubTotal_Asoka";
            this.lblSubTotal_Asoka.Size = new System.Drawing.Size(16, 15);
            this.lblSubTotal_Asoka.TabIndex = 6;
            this.lblSubTotal_Asoka.Text = "...";
            // 
            // lblTotal_Asoka
            // 
            this.lblTotal_Asoka.AutoSize = true;
            this.lblTotal_Asoka.Location = new System.Drawing.Point(70, 365);
            this.lblTotal_Asoka.Name = "lblTotal_Asoka";
            this.lblTotal_Asoka.Size = new System.Drawing.Size(16, 15);
            this.lblTotal_Asoka.TabIndex = 5;
            this.lblTotal_Asoka.Text = "...";
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Location = new System.Drawing.Point(6, 328);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(69, 15);
            this.label17.TabIndex = 4;
            this.label17.Text = "SubTotal  R:";
            // 
            // lbSummary_Asoka
            // 
            this.lbSummary_Asoka.FormattingEnabled = true;
            this.lbSummary_Asoka.ItemHeight = 15;
            this.lbSummary_Asoka.Location = new System.Drawing.Point(6, 21);
            this.lbSummary_Asoka.Name = "lbSummary_Asoka";
            this.lbSummary_Asoka.Size = new System.Drawing.Size(409, 289);
            this.lbSummary_Asoka.TabIndex = 3;
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.Location = new System.Drawing.Point(6, 365);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(70, 15);
            this.label19.TabIndex = 2;
            this.label19.Text = "Total         R:";
            // 
            // groupBox1
            // 
            this.groupBox1.BackColor = System.Drawing.Color.Transparent;
            this.groupBox1.Controls.Add(this.pictureBox4);
            this.groupBox1.Controls.Add(this.pictureBox3);
            this.groupBox1.Controls.Add(this.pictureBox2);
            this.groupBox1.Controls.Add(this.txtCVV_Asoka);
            this.groupBox1.Controls.Add(this.label16);
            this.groupBox1.Controls.Add(this.txtExpirydate_Asoka);
            this.groupBox1.Controls.Add(this.label15);
            this.groupBox1.Controls.Add(this.pbAsoka);
            this.groupBox1.Controls.Add(this.txtcrdNo_Asoka);
            this.groupBox1.Controls.Add(this.label14);
            this.groupBox1.Controls.Add(this.txtcrdholder_Asoka);
            this.groupBox1.Controls.Add(this.label13);
            this.groupBox1.Font = new System.Drawing.Font("Microsoft PhagsPa", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox1.Location = new System.Drawing.Point(24, 19);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(421, 380);
            this.groupBox1.TabIndex = 0;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Payment Details";
            // 
            // pictureBox4
            // 
            this.pictureBox4.BackgroundImage = global::Restaurant_Reservation_System_FinalProject_26.Properties.Resources.paypal;
            this.pictureBox4.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pictureBox4.Location = new System.Drawing.Point(201, 308);
            this.pictureBox4.Name = "pictureBox4";
            this.pictureBox4.Size = new System.Drawing.Size(65, 48);
            this.pictureBox4.TabIndex = 11;
            this.pictureBox4.TabStop = false;
            // 
            // pictureBox3
            // 
            this.pictureBox3.BackgroundImage = global::Restaurant_Reservation_System_FinalProject_26.Properties.Resources.mastercard;
            this.pictureBox3.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pictureBox3.Location = new System.Drawing.Point(112, 308);
            this.pictureBox3.Name = "pictureBox3";
            this.pictureBox3.Size = new System.Drawing.Size(59, 48);
            this.pictureBox3.TabIndex = 10;
            this.pictureBox3.TabStop = false;
            // 
            // pictureBox2
            // 
            this.pictureBox2.BackgroundImage = global::Restaurant_Reservation_System_FinalProject_26.Properties.Resources.visa;
            this.pictureBox2.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pictureBox2.Location = new System.Drawing.Point(28, 308);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(53, 48);
            this.pictureBox2.TabIndex = 9;
            this.pictureBox2.TabStop = false;
            // 
            // txtCVV_Asoka
            // 
            this.txtCVV_Asoka.BackColor = System.Drawing.SystemColors.ScrollBar;
            this.txtCVV_Asoka.Location = new System.Drawing.Point(157, 251);
            this.txtCVV_Asoka.Name = "txtCVV_Asoka";
            this.txtCVV_Asoka.Size = new System.Drawing.Size(98, 22);
            this.txtCVV_Asoka.TabIndex = 8;
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Font = new System.Drawing.Font("Microsoft PhagsPa", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label16.Location = new System.Drawing.Point(154, 234);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(30, 14);
            this.label16.TabIndex = 7;
            this.label16.Text = "CVV:";
            // 
            // txtExpirydate_Asoka
            // 
            this.txtExpirydate_Asoka.BackColor = System.Drawing.SystemColors.ScrollBar;
            this.txtExpirydate_Asoka.Location = new System.Drawing.Point(10, 251);
            this.txtExpirydate_Asoka.Name = "txtExpirydate_Asoka";
            this.txtExpirydate_Asoka.Size = new System.Drawing.Size(98, 22);
            this.txtExpirydate_Asoka.TabIndex = 6;
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Font = new System.Drawing.Font("Microsoft PhagsPa", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label15.Location = new System.Drawing.Point(7, 234);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(63, 14);
            this.label15.TabIndex = 5;
            this.label15.Text = "Expiry date:";
            // 
            // pbAsoka
            // 
            this.pbAsoka.Location = new System.Drawing.Point(10, 139);
            this.pbAsoka.Name = "pbAsoka";
            this.pbAsoka.Size = new System.Drawing.Size(42, 35);
            this.pbAsoka.TabIndex = 4;
            this.pbAsoka.TabStop = false;
            // 
            // txtcrdNo_Asoka
            // 
            this.txtcrdNo_Asoka.BackColor = System.Drawing.SystemColors.ScrollBar;
            this.txtcrdNo_Asoka.Location = new System.Drawing.Point(58, 152);
            this.txtcrdNo_Asoka.Name = "txtcrdNo_Asoka";
            this.txtcrdNo_Asoka.Size = new System.Drawing.Size(272, 22);
            this.txtcrdNo_Asoka.TabIndex = 3;
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Font = new System.Drawing.Font("Microsoft PhagsPa", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label14.Location = new System.Drawing.Point(7, 122);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(74, 14);
            this.label14.TabIndex = 2;
            this.label14.Text = "Card Number:";
            // 
            // txtcrdholder_Asoka
            // 
            this.txtcrdholder_Asoka.BackColor = System.Drawing.SystemColors.ScrollBar;
            this.txtcrdholder_Asoka.Location = new System.Drawing.Point(10, 55);
            this.txtcrdholder_Asoka.Name = "txtcrdholder_Asoka";
            this.txtcrdholder_Asoka.Size = new System.Drawing.Size(320, 22);
            this.txtcrdholder_Asoka.TabIndex = 1;
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Font = new System.Drawing.Font("Microsoft PhagsPa", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label13.Location = new System.Drawing.Point(7, 36);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(101, 14);
            this.label13.TabIndex = 0;
            this.label13.Text = "Cardholder\'s name:";
            // 
            // tabPage5
            // 
            this.tabPage5.BackColor = System.Drawing.Color.Silver;
            this.tabPage5.BackgroundImage = global::Restaurant_Reservation_System_FinalProject_26.Properties.Resources.Asoka2;
            this.tabPage5.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.tabPage5.Controls.Add(this.label18);
            this.tabPage5.Controls.Add(this.rtxtReview_Asoka);
            this.tabPage5.Controls.Add(this.btnReview_Asoka);
            this.tabPage5.Controls.Add(this.lbReview_Asoka);
            this.tabPage5.Controls.Add(this.pictureBox5);
            this.tabPage5.Location = new System.Drawing.Point(4, 23);
            this.tabPage5.Name = "tabPage5";
            this.tabPage5.Size = new System.Drawing.Size(1224, 480);
            this.tabPage5.TabIndex = 4;
            this.tabPage5.Text = "Reviews";
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.BackColor = System.Drawing.Color.Transparent;
            this.label18.Font = new System.Drawing.Font("Microsoft PhagsPa", 11F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label18.ForeColor = System.Drawing.SystemColors.Desktop;
            this.label18.Location = new System.Drawing.Point(378, 321);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(248, 20);
            this.label18.TabIndex = 9;
            this.label18.Text = "Please leave a review down below:";
            // 
            // rtxtReview_Asoka
            // 
            this.rtxtReview_Asoka.Location = new System.Drawing.Point(382, 344);
            this.rtxtReview_Asoka.Name = "rtxtReview_Asoka";
            this.rtxtReview_Asoka.Size = new System.Drawing.Size(413, 76);
            this.rtxtReview_Asoka.TabIndex = 8;
            this.rtxtReview_Asoka.Text = "";
            // 
            // btnReview_Asoka
            // 
            this.btnReview_Asoka.BackColor = System.Drawing.SystemColors.HotTrack;
            this.btnReview_Asoka.Font = new System.Drawing.Font("Microsoft PhagsPa", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnReview_Asoka.ForeColor = System.Drawing.SystemColors.Info;
            this.btnReview_Asoka.Location = new System.Drawing.Point(819, 363);
            this.btnReview_Asoka.Name = "btnReview_Asoka";
            this.btnReview_Asoka.Size = new System.Drawing.Size(95, 38);
            this.btnReview_Asoka.TabIndex = 7;
            this.btnReview_Asoka.Text = "Comment";
            this.btnReview_Asoka.UseVisualStyleBackColor = false;
            // 
            // lbReview_Asoka
            // 
            this.lbReview_Asoka.FormattingEnabled = true;
            this.lbReview_Asoka.ItemHeight = 14;
            this.lbReview_Asoka.Location = new System.Drawing.Point(382, 14);
            this.lbReview_Asoka.Name = "lbReview_Asoka";
            this.lbReview_Asoka.Size = new System.Drawing.Size(632, 270);
            this.lbReview_Asoka.TabIndex = 6;
            // 
            // pictureBox5
            // 
            this.pictureBox5.BackgroundImage = global::Restaurant_Reservation_System_FinalProject_26.Properties.Resources.Asoka2;
            this.pictureBox5.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pictureBox5.Location = new System.Drawing.Point(15, 14);
            this.pictureBox5.Name = "pictureBox5";
            this.pictureBox5.Size = new System.Drawing.Size(314, 228);
            this.pictureBox5.TabIndex = 5;
            this.pictureBox5.TabStop = false;
            // 
            // Form7
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.MenuHighlight;
            this.ClientSize = new System.Drawing.Size(1256, 522);
            this.Controls.Add(this.tabControl1);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "Form7";
            this.Text = "Asoka";
            this.tabControl1.ResumeLayout(false);
            this.tabPage2.ResumeLayout(false);
            this.tabPage2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.tabPage3.ResumeLayout(false);
            this.tabControl2.ResumeLayout(false);
            this.tabPage1.ResumeLayout(false);
            this.tabPage1.PerformLayout();
            this.groupBox6.ResumeLayout(false);
            this.groupBox6.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pbDeserts_Asoka)).EndInit();
            this.groupBox4.ResumeLayout(false);
            this.groupBox4.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pbMain_Asoka)).EndInit();
            this.groupBox3.ResumeLayout(false);
            this.groupBox3.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pbAppetizers_Asoka)).EndInit();
            this.tabPage6.ResumeLayout(false);
            this.groupBox10.ResumeLayout(false);
            this.groupBox10.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pbHotBev_Asoka)).EndInit();
            this.groupBox9.ResumeLayout(false);
            this.groupBox9.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pbNonBev_Asoka)).EndInit();
            this.groupBox8.ResumeLayout(false);
            this.groupBox8.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pbWines_Asoka)).EndInit();
            this.groupBox7.ResumeLayout(false);
            this.groupBox7.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pbCocktails_Asoka)).EndInit();
            this.groupBox5.ResumeLayout(false);
            this.tabPage4.ResumeLayout(false);
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbAsoka)).EndInit();
            this.tabPage5.ResumeLayout(false);
            this.tabPage5.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox5)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TabControl tabControl1;
        private System.Windows.Forms.TabPage tabPage2;
        private System.Windows.Forms.TabPage tabPage3;
        private System.Windows.Forms.TabPage tabPage4;
        private System.Windows.Forms.TabPage tabPage5;
        private System.Windows.Forms.Button btnSubmit_Asoka;
        private System.Windows.Forms.TextBox txtAsoka;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.TextBox txtOther_Asoka;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.ComboBox cbReserveType_Asoka;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.DateTimePicker dateTime_Asoka;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.TextBox txtPhone_Asoka;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.TextBox txtEmail_Asoka;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.TextBox txtLName_Asoka;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox txtFName_Asoka;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.PictureBox pbAsoka;
        private System.Windows.Forms.TextBox txtcrdNo_Asoka;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.TextBox txtcrdholder_Asoka;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.PictureBox pictureBox4;
        private System.Windows.Forms.PictureBox pictureBox3;
        private System.Windows.Forms.PictureBox pictureBox2;
        private System.Windows.Forms.TextBox txtCVV_Asoka;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.TextBox txtExpirydate_Asoka;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Label lblSubTotal_Asoka;
        private System.Windows.Forms.Label lblTotal_Asoka;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.ListBox lbSummary_Asoka;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.Button btnPay_Asoka;
        private System.Windows.Forms.Button btnBackAsoka_pg3;
        private System.Windows.Forms.Button btnHomeAsoka;
        private System.Windows.Forms.Button btnBackAsoka_pg2;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.RichTextBox rtxtReview_Asoka;
        private System.Windows.Forms.Button btnReview_Asoka;
        private System.Windows.Forms.ListBox lbReview_Asoka;
        private System.Windows.Forms.PictureBox pictureBox5;
        private System.Windows.Forms.TabControl tabControl2;
        private System.Windows.Forms.TabPage tabPage1;
        private System.Windows.Forms.GroupBox groupBox6;
        private System.Windows.Forms.PictureBox pbDeserts_Asoka;
        private System.Windows.Forms.CheckBox cbDesert5_Asoka;
        private System.Windows.Forms.CheckBox cbDesert4_Asoka;
        private System.Windows.Forms.CheckBox cbDesert3_Asoka;
        private System.Windows.Forms.CheckBox cbDesert2_Asoka;
        private System.Windows.Forms.CheckBox cbDesert1_Asoka;
        private System.Windows.Forms.GroupBox groupBox4;
        private System.Windows.Forms.PictureBox pbMain_Asoka;
        private System.Windows.Forms.CheckBox cbMain8_Asoka;
        private System.Windows.Forms.CheckBox cbMain7_Asoka;
        private System.Windows.Forms.CheckBox cbMain6_Asoka;
        private System.Windows.Forms.CheckBox cbMain5_Asoka;
        private System.Windows.Forms.CheckBox cbMain4_Asoka;
        private System.Windows.Forms.CheckBox cbMain3_Asoka;
        private System.Windows.Forms.CheckBox cbMain2_Asoka;
        private System.Windows.Forms.CheckBox cbMain1_Asoka;
        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.PictureBox pbAppetizers_Asoka;
        private System.Windows.Forms.CheckBox cbStarter5_Asoka;
        private System.Windows.Forms.CheckBox cbStarter4_Asoka;
        private System.Windows.Forms.CheckBox cbStarter3_Asoka;
        private System.Windows.Forms.CheckBox cbStarter2_Asoka;
        private System.Windows.Forms.CheckBox cbStarter1_Asoka;
        private System.Windows.Forms.TabPage tabPage6;
        private System.Windows.Forms.Button btnRemove_Asoka;
        private System.Windows.Forms.Button btnSubmitOrder_Asoka;
        private System.Windows.Forms.GroupBox groupBox5;
        private System.Windows.Forms.ListBox lbOrder_Asoka;
        private System.Windows.Forms.Label label21;
        private System.Windows.Forms.RichTextBox rtxtAllergies_Asoka;
        private System.Windows.Forms.CheckBox cbAllergies_Asoka;
        private System.Windows.Forms.Button btnNext_Asoka;
        private System.Windows.Forms.Button btnSkip_Asoka;
        private System.Windows.Forms.GroupBox groupBox10;
        private System.Windows.Forms.PictureBox pbHotBev_Asoka;
        private System.Windows.Forms.CheckBox cbHotBev5_Pace;
        private System.Windows.Forms.CheckBox cbHotBev4_Pace;
        private System.Windows.Forms.CheckBox cbHotBev3_Asoka;
        private System.Windows.Forms.CheckBox cbHotBev2_Asoka;
        private System.Windows.Forms.CheckBox cbHotBev1_Asoka;
        private System.Windows.Forms.GroupBox groupBox9;
        private System.Windows.Forms.PictureBox pbNonBev_Asoka;
        private System.Windows.Forms.CheckBox cbNonBev5_Asoka;
        private System.Windows.Forms.CheckBox cbNonBev4_Asoka;
        private System.Windows.Forms.CheckBox cbNonBev3_Asoka;
        private System.Windows.Forms.CheckBox cbNonBev2_Asoka;
        private System.Windows.Forms.CheckBox cbNonBev1_Asoka;
        private System.Windows.Forms.GroupBox groupBox8;
        private System.Windows.Forms.PictureBox pbWines_Asoka;
        private System.Windows.Forms.CheckBox cbWine5_Asoka;
        private System.Windows.Forms.CheckBox cbWine4_Asoka;
        private System.Windows.Forms.CheckBox cbWine3_Asoka;
        private System.Windows.Forms.CheckBox cbWine2_Asoka;
        private System.Windows.Forms.CheckBox cbWine1_Asoka;
        private System.Windows.Forms.GroupBox groupBox7;
        private System.Windows.Forms.PictureBox pbCocktails_Asoka;
        private System.Windows.Forms.CheckBox cbcocktail5_Asoka;
        private System.Windows.Forms.CheckBox cbcocktail4_Asoka;
        private System.Windows.Forms.CheckBox cbcocktail3_Asoka;
        private System.Windows.Forms.CheckBox cbcocktail2_Asoka;
        private System.Windows.Forms.CheckBox cbcocktail1_Asoka;
        private System.Windows.Forms.TextBox TxtNoOfGuests_Asoka;
        private System.Windows.Forms.Label lblNoOfSeats_Asoka;
        private System.Windows.Forms.Button btnBack1_Asoka;
        private System.Windows.Forms.ComboBox cbTime_Asoka;
        private System.Windows.Forms.Label label20;
    }
}