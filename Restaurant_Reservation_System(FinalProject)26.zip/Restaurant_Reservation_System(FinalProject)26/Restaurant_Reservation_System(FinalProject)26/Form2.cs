﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Restaurant_Reservation_System_FinalProject_26
{
    public partial class Form2 : Form
    {
        public Form2()
        {
            InitializeComponent();
            tabControl1.SelectedIndex = 1;
        }

        private void lblLogin_Click(object sender, EventArgs e)
        {
            tabControl1.SelectedTab = tabPage2;
            lblLogin.ForeColor = Color.Red;
        }

        private void lblSignUp_Click(object sender, EventArgs e)
        {
            tabControl1.SelectedTab = tabPage1;
            lblSignUp.ForeColor = Color.Red;
        }

        private void btnUserLogin_Click(object sender, EventArgs e)
        {
            Form4 frm4 = new Form4();
            frm4.Show();
            this.Hide();
        }

        private void btnAdminLogin_Click(object sender, EventArgs e)
        {
            Form3 frm3 = new Form3();
            frm3.Show();
            this.Hide();
        }

        private void btnSignUp_Click(object sender, EventArgs e)
        {
            tabControl1.SelectedTab = tabPage2;
        }
    }
}
