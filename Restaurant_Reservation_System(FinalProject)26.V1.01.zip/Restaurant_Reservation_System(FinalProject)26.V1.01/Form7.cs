﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Net.Mime.MediaTypeNames;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace Restaurant_Reservation_System_FinalProject_26
{
    public partial class Form7 : Form
    {
        public Form7()
        {
            InitializeComponent();
        }

        public Form7(string name, string surname, string email, string phone_number)
        {
            InitializeComponent();
        }

        private void btnSubmit_Asoka_Click(object sender, EventArgs e)
        {
            tabControl1.SelectedTab = tabPage3;
        }

        private void btnPay_Asoka_Click(object sender, EventArgs e)
        {
            tabControl1.SelectedTab = tabPage5;
        }

        private void btnBackAsoka_pg3_Click(object sender, EventArgs e)
        {
            tabControl1.SelectedTab = tabPage3;
        }

        private void btnHomeAsoka_Click(object sender, EventArgs e)
        {
            Form4 frm4 = new Form4();
            frm4.Show();
            this.Close();
        }

        private void btnBackAsoka_pg2_Click(object sender, EventArgs e)
        {
            tabControl1.SelectedTab= tabPage2;
        }

        private void btnNext_Asoka_Click(object sender, EventArgs e)
        {
            tabControl2.SelectedTab = tabPage6;
        }

        private void btnSubmitOrder_Asoka_Click(object sender, EventArgs e)
        {
            tabControl1.SelectedTab = tabPage4;
        }

        private void btnSkip_Asoka_Click(object sender, EventArgs e)
        {
            tabControl1.SelectedTab = tabPage4;
        }

        private void btnBack1_Asoka_Click(object sender, EventArgs e)
        {
            tabControl2.SelectedTab = tabPage1;
        }

        private void Form7_Load(object sender, EventArgs e)
        {

        }
    }
}
