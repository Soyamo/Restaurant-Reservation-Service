﻿namespace Restaurant_Reservation_System_FinalProject_26
{
    partial class Form6
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form6));
            this.tabControl1 = new System.Windows.Forms.TabControl();
            this.tabPage2 = new System.Windows.Forms.TabPage();
            this.cbTime_Pace = new System.Windows.Forms.ComboBox();
            this.label20 = new System.Windows.Forms.Label();
            this.lblNoOfSeats_Pace = new System.Windows.Forms.Label();
            this.TxtNoOfGuests_Pace = new System.Windows.Forms.TextBox();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.btnHomePace = new System.Windows.Forms.Button();
            this.btnSubmit_Pace = new System.Windows.Forms.Button();
            this.txtRequest_Pace = new System.Windows.Forms.TextBox();
            this.label12 = new System.Windows.Forms.Label();
            this.txtOther_Pace = new System.Windows.Forms.TextBox();
            this.label11 = new System.Windows.Forms.Label();
            this.cbReserveType_Pace = new System.Windows.Forms.ComboBox();
            this.label10 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.dateTime_Pace = new System.Windows.Forms.DateTimePicker();
            this.label8 = new System.Windows.Forms.Label();
            this.txtPhone_Pace = new System.Windows.Forms.TextBox();
            this.label7 = new System.Windows.Forms.Label();
            this.txtEmail_Pace = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.txtLName_Pace = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.txtFName_Pace = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.tabPage3 = new System.Windows.Forms.TabPage();
            this.tabControl2 = new System.Windows.Forms.TabControl();
            this.tabPage1 = new System.Windows.Forms.TabPage();
            this.btnSkip_Pace = new System.Windows.Forms.Button();
            this.btnNext_Pace = new System.Windows.Forms.Button();
            this.label21 = new System.Windows.Forms.Label();
            this.rtxtAllergies_Pace = new System.Windows.Forms.RichTextBox();
            this.cbAllergies_Pace = new System.Windows.Forms.CheckBox();
            this.groupBox6 = new System.Windows.Forms.GroupBox();
            this.pbDeserts_Pace = new System.Windows.Forms.PictureBox();
            this.cbDesert5_Pace = new System.Windows.Forms.CheckBox();
            this.cbDesert4_Pace = new System.Windows.Forms.CheckBox();
            this.cbDesert3_Pace = new System.Windows.Forms.CheckBox();
            this.cbDesert2_Pace = new System.Windows.Forms.CheckBox();
            this.cbDesert1_Pace = new System.Windows.Forms.CheckBox();
            this.groupBox4 = new System.Windows.Forms.GroupBox();
            this.pbMain_Pace = new System.Windows.Forms.PictureBox();
            this.cbMain8_Pace = new System.Windows.Forms.CheckBox();
            this.cbMain7_Pace = new System.Windows.Forms.CheckBox();
            this.cbMain6_Pace = new System.Windows.Forms.CheckBox();
            this.cbMain5_Pace = new System.Windows.Forms.CheckBox();
            this.cbMain4_Pace = new System.Windows.Forms.CheckBox();
            this.cbMain3_Pace = new System.Windows.Forms.CheckBox();
            this.cbMain2_Pace = new System.Windows.Forms.CheckBox();
            this.cbMain1_Pace = new System.Windows.Forms.CheckBox();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.pbAppetizers_Pace = new System.Windows.Forms.PictureBox();
            this.cbStarter5_Pace = new System.Windows.Forms.CheckBox();
            this.cbStarter4_Pace = new System.Windows.Forms.CheckBox();
            this.cbStarter3_Pace = new System.Windows.Forms.CheckBox();
            this.cbStarter2_Pace = new System.Windows.Forms.CheckBox();
            this.cbStarter1_Pace = new System.Windows.Forms.CheckBox();
            this.tabPage6 = new System.Windows.Forms.TabPage();
            this.btnBack1_Pace = new System.Windows.Forms.Button();
            this.groupBox10 = new System.Windows.Forms.GroupBox();
            this.pbHotBev_Pace = new System.Windows.Forms.PictureBox();
            this.cbHotBev5_Pace = new System.Windows.Forms.CheckBox();
            this.cbHotBev4_Pace = new System.Windows.Forms.CheckBox();
            this.cbHotBev3_Pace = new System.Windows.Forms.CheckBox();
            this.cbHotBev2_Pace = new System.Windows.Forms.CheckBox();
            this.cbHotBev1_Pace = new System.Windows.Forms.CheckBox();
            this.groupBox9 = new System.Windows.Forms.GroupBox();
            this.pictureBox8 = new System.Windows.Forms.PictureBox();
            this.cbNonBev5_Pace = new System.Windows.Forms.CheckBox();
            this.cbNonBev4_Pace = new System.Windows.Forms.CheckBox();
            this.cbNonBev3_Vino = new System.Windows.Forms.CheckBox();
            this.cbNonBev2_Pace = new System.Windows.Forms.CheckBox();
            this.cbNonBev1_Pace = new System.Windows.Forms.CheckBox();
            this.groupBox8 = new System.Windows.Forms.GroupBox();
            this.pictureBox7 = new System.Windows.Forms.PictureBox();
            this.cbWine5_Pace = new System.Windows.Forms.CheckBox();
            this.cbWine4_Pace = new System.Windows.Forms.CheckBox();
            this.cbWine3_Pace = new System.Windows.Forms.CheckBox();
            this.cbWine2_Pace = new System.Windows.Forms.CheckBox();
            this.cbWine1_Pace = new System.Windows.Forms.CheckBox();
            this.groupBox7 = new System.Windows.Forms.GroupBox();
            this.pbCocktails_Pace = new System.Windows.Forms.PictureBox();
            this.cbcocktail5_Pace = new System.Windows.Forms.CheckBox();
            this.cbcocktail4_Pace = new System.Windows.Forms.CheckBox();
            this.cbcocktail3_Pace = new System.Windows.Forms.CheckBox();
            this.cbcocktail2_Pace = new System.Windows.Forms.CheckBox();
            this.cbcocktail1_Pace = new System.Windows.Forms.CheckBox();
            this.btnRemove_Pace = new System.Windows.Forms.Button();
            this.btnSubmitOrder_Pace = new System.Windows.Forms.Button();
            this.groupBox5 = new System.Windows.Forms.GroupBox();
            this.lbOrder_Pace = new System.Windows.Forms.ListBox();
            this.btnBackPace_pg2 = new System.Windows.Forms.Button();
            this.tabPage4 = new System.Windows.Forms.TabPage();
            this.btnBackPace_pg3 = new System.Windows.Forms.Button();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.btnPay_Pace = new System.Windows.Forms.Button();
            this.lblSubTotal_Pace = new System.Windows.Forms.Label();
            this.lblTotal_Pace = new System.Windows.Forms.Label();
            this.label17 = new System.Windows.Forms.Label();
            this.lbSummary_Pace = new System.Windows.Forms.ListBox();
            this.label19 = new System.Windows.Forms.Label();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.pictureBox4 = new System.Windows.Forms.PictureBox();
            this.pictureBox3 = new System.Windows.Forms.PictureBox();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.txtCVV_Pace = new System.Windows.Forms.TextBox();
            this.label16 = new System.Windows.Forms.Label();
            this.txtExpirydate_Pace = new System.Windows.Forms.TextBox();
            this.label15 = new System.Windows.Forms.Label();
            this.pbPace = new System.Windows.Forms.PictureBox();
            this.txtcrdNo_Pace = new System.Windows.Forms.TextBox();
            this.label14 = new System.Windows.Forms.Label();
            this.txtcrdholder_Pace = new System.Windows.Forms.TextBox();
            this.label13 = new System.Windows.Forms.Label();
            this.tabPage5 = new System.Windows.Forms.TabPage();
            this.label18 = new System.Windows.Forms.Label();
            this.rtxtReview_Pace = new System.Windows.Forms.RichTextBox();
            this.btnReview_Pace = new System.Windows.Forms.Button();
            this.lbReview_Pace = new System.Windows.Forms.ListBox();
            this.pictureBox5 = new System.Windows.Forms.PictureBox();
            this.tabControl1.SuspendLayout();
            this.tabPage2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.tabPage3.SuspendLayout();
            this.tabControl2.SuspendLayout();
            this.tabPage1.SuspendLayout();
            this.groupBox6.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pbDeserts_Pace)).BeginInit();
            this.groupBox4.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pbMain_Pace)).BeginInit();
            this.groupBox3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pbAppetizers_Pace)).BeginInit();
            this.tabPage6.SuspendLayout();
            this.groupBox10.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pbHotBev_Pace)).BeginInit();
            this.groupBox9.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox8)).BeginInit();
            this.groupBox8.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox7)).BeginInit();
            this.groupBox7.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pbCocktails_Pace)).BeginInit();
            this.groupBox5.SuspendLayout();
            this.tabPage4.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.groupBox1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbPace)).BeginInit();
            this.tabPage5.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox5)).BeginInit();
            this.SuspendLayout();
            // 
            // tabControl1
            // 
            this.tabControl1.Controls.Add(this.tabPage2);
            this.tabControl1.Controls.Add(this.tabPage3);
            this.tabControl1.Controls.Add(this.tabPage4);
            this.tabControl1.Controls.Add(this.tabPage5);
            this.tabControl1.Cursor = System.Windows.Forms.Cursors.Hand;
            this.tabControl1.Font = new System.Drawing.Font("Microsoft PhagsPa", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tabControl1.Location = new System.Drawing.Point(12, 12);
            this.tabControl1.Name = "tabControl1";
            this.tabControl1.SelectedIndex = 0;
            this.tabControl1.Size = new System.Drawing.Size(1230, 503);
            this.tabControl1.TabIndex = 2;
            // 
            // tabPage2
            // 
            this.tabPage2.BackColor = System.Drawing.Color.Silver;
            this.tabPage2.BackgroundImage = global::Restaurant_Reservation_System_FinalProject_26.Properties.Resources.pace1;
            this.tabPage2.Controls.Add(this.cbTime_Pace);
            this.tabPage2.Controls.Add(this.label20);
            this.tabPage2.Controls.Add(this.lblNoOfSeats_Pace);
            this.tabPage2.Controls.Add(this.TxtNoOfGuests_Pace);
            this.tabPage2.Controls.Add(this.pictureBox1);
            this.tabPage2.Controls.Add(this.btnHomePace);
            this.tabPage2.Controls.Add(this.btnSubmit_Pace);
            this.tabPage2.Controls.Add(this.txtRequest_Pace);
            this.tabPage2.Controls.Add(this.label12);
            this.tabPage2.Controls.Add(this.txtOther_Pace);
            this.tabPage2.Controls.Add(this.label11);
            this.tabPage2.Controls.Add(this.cbReserveType_Pace);
            this.tabPage2.Controls.Add(this.label10);
            this.tabPage2.Controls.Add(this.label9);
            this.tabPage2.Controls.Add(this.dateTime_Pace);
            this.tabPage2.Controls.Add(this.label8);
            this.tabPage2.Controls.Add(this.txtPhone_Pace);
            this.tabPage2.Controls.Add(this.label7);
            this.tabPage2.Controls.Add(this.txtEmail_Pace);
            this.tabPage2.Controls.Add(this.label6);
            this.tabPage2.Controls.Add(this.txtLName_Pace);
            this.tabPage2.Controls.Add(this.label5);
            this.tabPage2.Controls.Add(this.txtFName_Pace);
            this.tabPage2.Controls.Add(this.label4);
            this.tabPage2.Controls.Add(this.label3);
            this.tabPage2.Controls.Add(this.label2);
            this.tabPage2.Controls.Add(this.label1);
            this.tabPage2.Location = new System.Drawing.Point(4, 23);
            this.tabPage2.Name = "tabPage2";
            this.tabPage2.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage2.Size = new System.Drawing.Size(1222, 476);
            this.tabPage2.TabIndex = 1;
            this.tabPage2.Text = "Reserving";
            // 
            // cbTime_Pace
            // 
            this.cbTime_Pace.FormattingEnabled = true;
            this.cbTime_Pace.Items.AddRange(new object[] {
            "Choose time to book:",
            "09:00 pm",
            "11:00 pm",
            "13:00 pm",
            "15:00 pm",
            "18:00 pm",
            "21:00 pm"});
            this.cbTime_Pace.Location = new System.Drawing.Point(387, 316);
            this.cbTime_Pace.Name = "cbTime_Pace";
            this.cbTime_Pace.Size = new System.Drawing.Size(121, 22);
            this.cbTime_Pace.TabIndex = 55;
            // 
            // label20
            // 
            this.label20.AutoSize = true;
            this.label20.BackColor = System.Drawing.Color.Transparent;
            this.label20.Font = new System.Drawing.Font("Microsoft PhagsPa", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label20.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.label20.Location = new System.Drawing.Point(383, 293);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(45, 20);
            this.label20.TabIndex = 54;
            this.label20.Text = "Time:";
            // 
            // lblNoOfSeats_Pace
            // 
            this.lblNoOfSeats_Pace.AutoSize = true;
            this.lblNoOfSeats_Pace.BackColor = System.Drawing.Color.Transparent;
            this.lblNoOfSeats_Pace.Font = new System.Drawing.Font("Microsoft PhagsPa", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblNoOfSeats_Pace.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.lblNoOfSeats_Pace.Location = new System.Drawing.Point(25, 352);
            this.lblNoOfSeats_Pace.Name = "lblNoOfSeats_Pace";
            this.lblNoOfSeats_Pace.Size = new System.Drawing.Size(54, 15);
            this.lblNoOfSeats_Pace.TabIndex = 50;
            this.lblNoOfSeats_Pace.Text = "Seats left";
            // 
            // TxtNoOfGuests_Pace
            // 
            this.TxtNoOfGuests_Pace.Location = new System.Drawing.Point(26, 327);
            this.TxtNoOfGuests_Pace.Name = "TxtNoOfGuests_Pace";
            this.TxtNoOfGuests_Pace.Size = new System.Drawing.Size(109, 22);
            this.TxtNoOfGuests_Pace.TabIndex = 49;
            // 
            // pictureBox1
            // 
            this.pictureBox1.BackgroundImage = global::Restaurant_Reservation_System_FinalProject_26.Properties.Resources.pacee;
            this.pictureBox1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pictureBox1.Location = new System.Drawing.Point(1026, 6);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(190, 152);
            this.pictureBox1.TabIndex = 48;
            this.pictureBox1.TabStop = false;
            // 
            // btnHomePace
            // 
            this.btnHomePace.BackColor = System.Drawing.Color.Crimson;
            this.btnHomePace.Font = new System.Drawing.Font("Microsoft PhagsPa", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnHomePace.ForeColor = System.Drawing.Color.LavenderBlush;
            this.btnHomePace.Location = new System.Drawing.Point(1051, 391);
            this.btnHomePace.Name = "btnHomePace";
            this.btnHomePace.Size = new System.Drawing.Size(89, 40);
            this.btnHomePace.TabIndex = 46;
            this.btnHomePace.Text = "Home";
            this.btnHomePace.UseVisualStyleBackColor = false;
            this.btnHomePace.Click += new System.EventHandler(this.btnHomePace_Click);
            // 
            // btnSubmit_Pace
            // 
            this.btnSubmit_Pace.BackColor = System.Drawing.Color.Lime;
            this.btnSubmit_Pace.Font = new System.Drawing.Font("Microsoft PhagsPa", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSubmit_Pace.ForeColor = System.Drawing.SystemColors.HighlightText;
            this.btnSubmit_Pace.Location = new System.Drawing.Point(753, 348);
            this.btnSubmit_Pace.Name = "btnSubmit_Pace";
            this.btnSubmit_Pace.Size = new System.Drawing.Size(135, 41);
            this.btnSubmit_Pace.TabIndex = 45;
            this.btnSubmit_Pace.Text = "Submit";
            this.btnSubmit_Pace.UseVisualStyleBackColor = false;
            this.btnSubmit_Pace.Click += new System.EventHandler(this.btnSubmit_Pace_Click);
            // 
            // txtRequest_Pace
            // 
            this.txtRequest_Pace.Location = new System.Drawing.Point(705, 291);
            this.txtRequest_Pace.Name = "txtRequest_Pace";
            this.txtRequest_Pace.Size = new System.Drawing.Size(199, 22);
            this.txtRequest_Pace.TabIndex = 44;
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.BackColor = System.Drawing.Color.Transparent;
            this.label12.Font = new System.Drawing.Font("Microsoft PhagsPa", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label12.ForeColor = System.Drawing.SystemColors.Info;
            this.label12.Location = new System.Drawing.Point(700, 268);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(143, 20);
            this.label12.TabIndex = 43;
            this.label12.Text = "Any special requests";
            // 
            // txtOther_Pace
            // 
            this.txtOther_Pace.Location = new System.Drawing.Point(701, 218);
            this.txtOther_Pace.Name = "txtOther_Pace";
            this.txtOther_Pace.Size = new System.Drawing.Size(199, 22);
            this.txtOther_Pace.TabIndex = 42;
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.BackColor = System.Drawing.Color.Transparent;
            this.label11.Font = new System.Drawing.Font("Microsoft PhagsPa", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label11.ForeColor = System.Drawing.SystemColors.Info;
            this.label11.Location = new System.Drawing.Point(700, 195);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(204, 20);
            this.label11.TabIndex = 41;
            this.label11.Text = "If Other above, please specify";
            // 
            // cbReserveType_Pace
            // 
            this.cbReserveType_Pace.FormattingEnabled = true;
            this.cbReserveType_Pace.Items.AddRange(new object[] {
            "Choose reservation type...",
            "Wedding Reception",
            "Corporate event",
            "Birthday Celebration",
            "Anniversary",
            "Rehersal Dinner",
            "Holiday Party"});
            this.cbReserveType_Pace.Location = new System.Drawing.Point(704, 144);
            this.cbReserveType_Pace.Name = "cbReserveType_Pace";
            this.cbReserveType_Pace.Size = new System.Drawing.Size(196, 22);
            this.cbReserveType_Pace.TabIndex = 40;
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.BackColor = System.Drawing.Color.Transparent;
            this.label10.Font = new System.Drawing.Font("Microsoft PhagsPa", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label10.ForeColor = System.Drawing.SystemColors.Info;
            this.label10.Location = new System.Drawing.Point(701, 121);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(122, 20);
            this.label10.TabIndex = 39;
            this.label10.Text = "Reservation Type";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.BackColor = System.Drawing.Color.Transparent;
            this.label9.Font = new System.Drawing.Font("Microsoft PhagsPa", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.ForeColor = System.Drawing.SystemColors.Info;
            this.label9.Location = new System.Drawing.Point(383, 172);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(86, 20);
            this.label9.TabIndex = 38;
            this.label9.Text = "Reservation";
            // 
            // dateTime_Pace
            // 
            this.dateTime_Pace.Location = new System.Drawing.Point(387, 195);
            this.dateTime_Pace.Name = "dateTime_Pace";
            this.dateTime_Pace.Size = new System.Drawing.Size(200, 22);
            this.dateTime_Pace.TabIndex = 37;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.BackColor = System.Drawing.Color.Transparent;
            this.label8.Font = new System.Drawing.Font("Microsoft PhagsPa", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.ForeColor = System.Drawing.SystemColors.Info;
            this.label8.Location = new System.Drawing.Point(24, 304);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(97, 20);
            this.label8.TabIndex = 35;
            this.label8.Text = "No. of Guests";
            // 
            // txtPhone_Pace
            // 
            this.txtPhone_Pace.Location = new System.Drawing.Point(28, 266);
            this.txtPhone_Pace.Name = "txtPhone_Pace";
            this.txtPhone_Pace.ReadOnly = true;
            this.txtPhone_Pace.Size = new System.Drawing.Size(285, 22);
            this.txtPhone_Pace.TabIndex = 34;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.BackColor = System.Drawing.Color.Transparent;
            this.label7.Font = new System.Drawing.Font("Microsoft PhagsPa", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.ForeColor = System.Drawing.SystemColors.Info;
            this.label7.Location = new System.Drawing.Point(24, 243);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(50, 20);
            this.label7.TabIndex = 33;
            this.label7.Text = "Phone";
            // 
            // txtEmail_Pace
            // 
            this.txtEmail_Pace.Location = new System.Drawing.Point(26, 206);
            this.txtEmail_Pace.Name = "txtEmail_Pace";
            this.txtEmail_Pace.ReadOnly = true;
            this.txtEmail_Pace.Size = new System.Drawing.Size(285, 22);
            this.txtEmail_Pace.TabIndex = 32;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.BackColor = System.Drawing.Color.Transparent;
            this.label6.Font = new System.Drawing.Font("Microsoft PhagsPa", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.ForeColor = System.Drawing.SystemColors.Info;
            this.label6.Location = new System.Drawing.Point(22, 183);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(52, 20);
            this.label6.TabIndex = 31;
            this.label6.Text = "E-mail";
            // 
            // txtLName_Pace
            // 
            this.txtLName_Pace.Location = new System.Drawing.Point(310, 127);
            this.txtLName_Pace.Name = "txtLName_Pace";
            this.txtLName_Pace.ReadOnly = true;
            this.txtLName_Pace.Size = new System.Drawing.Size(199, 22);
            this.txtLName_Pace.TabIndex = 30;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.BackColor = System.Drawing.Color.Transparent;
            this.label5.ForeColor = System.Drawing.SystemColors.Info;
            this.label5.Location = new System.Drawing.Point(307, 152);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(59, 14);
            this.label5.TabIndex = 29;
            this.label5.Text = "Last Name";
            // 
            // txtFName_Pace
            // 
            this.txtFName_Pace.Location = new System.Drawing.Point(26, 127);
            this.txtFName_Pace.Name = "txtFName_Pace";
            this.txtFName_Pace.ReadOnly = true;
            this.txtFName_Pace.Size = new System.Drawing.Size(199, 22);
            this.txtFName_Pace.TabIndex = 28;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.BackColor = System.Drawing.Color.Transparent;
            this.label4.ForeColor = System.Drawing.SystemColors.Info;
            this.label4.Location = new System.Drawing.Point(23, 152);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(60, 14);
            this.label4.TabIndex = 27;
            this.label4.Text = "First Name";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.BackColor = System.Drawing.Color.Transparent;
            this.label3.Font = new System.Drawing.Font("Microsoft PhagsPa", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.ForeColor = System.Drawing.SystemColors.Info;
            this.label3.Location = new System.Drawing.Point(22, 104);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(76, 20);
            this.label3.TabIndex = 26;
            this.label3.Text = "Full Name";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.BackColor = System.Drawing.Color.Transparent;
            this.label2.Font = new System.Drawing.Font("Microsoft PhagsPa", 11F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.SystemColors.Info;
            this.label2.Location = new System.Drawing.Point(22, 66);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(630, 20);
            this.label2.TabIndex = 25;
            this.label2.Text = "Please fill the form below accurately to enable us to serve you better!.. Welcome" +
    " to Pace!";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.Color.Transparent;
            this.label1.Font = new System.Drawing.Font("Microsoft PhagsPa", 16F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.SystemColors.Info;
            this.label1.Location = new System.Drawing.Point(21, 23);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(157, 29);
            this.label1.TabIndex = 24;
            this.label1.Text = "Reserve Table";
            // 
            // tabPage3
            // 
            this.tabPage3.BackColor = System.Drawing.Color.Silver;
            this.tabPage3.BackgroundImage = global::Restaurant_Reservation_System_FinalProject_26.Properties.Resources.pace1;
            this.tabPage3.Controls.Add(this.tabControl2);
            this.tabPage3.Controls.Add(this.btnBackPace_pg2);
            this.tabPage3.Location = new System.Drawing.Point(4, 23);
            this.tabPage3.Name = "tabPage3";
            this.tabPage3.Size = new System.Drawing.Size(1222, 476);
            this.tabPage3.TabIndex = 2;
            this.tabPage3.Text = "Menu";
            // 
            // tabControl2
            // 
            this.tabControl2.Controls.Add(this.tabPage1);
            this.tabControl2.Controls.Add(this.tabPage6);
            this.tabControl2.Location = new System.Drawing.Point(4, 9);
            this.tabControl2.Name = "tabControl2";
            this.tabControl2.SelectedIndex = 0;
            this.tabControl2.Size = new System.Drawing.Size(1218, 438);
            this.tabControl2.TabIndex = 3;
            // 
            // tabPage1
            // 
            this.tabPage1.BackColor = System.Drawing.Color.DarkGray;
            this.tabPage1.Controls.Add(this.btnSkip_Pace);
            this.tabPage1.Controls.Add(this.btnNext_Pace);
            this.tabPage1.Controls.Add(this.label21);
            this.tabPage1.Controls.Add(this.rtxtAllergies_Pace);
            this.tabPage1.Controls.Add(this.cbAllergies_Pace);
            this.tabPage1.Controls.Add(this.groupBox6);
            this.tabPage1.Controls.Add(this.groupBox4);
            this.tabPage1.Controls.Add(this.groupBox3);
            this.tabPage1.Location = new System.Drawing.Point(4, 23);
            this.tabPage1.Name = "tabPage1";
            this.tabPage1.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage1.Size = new System.Drawing.Size(1210, 411);
            this.tabPage1.TabIndex = 0;
            this.tabPage1.Text = "Food";
            // 
            // btnSkip_Pace
            // 
            this.btnSkip_Pace.BackColor = System.Drawing.Color.Green;
            this.btnSkip_Pace.Font = new System.Drawing.Font("Microsoft PhagsPa", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSkip_Pace.ForeColor = System.Drawing.SystemColors.Control;
            this.btnSkip_Pace.Location = new System.Drawing.Point(1143, 3);
            this.btnSkip_Pace.Name = "btnSkip_Pace";
            this.btnSkip_Pace.Size = new System.Drawing.Size(64, 23);
            this.btnSkip_Pace.TabIndex = 11;
            this.btnSkip_Pace.Text = "Skip";
            this.btnSkip_Pace.UseVisualStyleBackColor = false;
            this.btnSkip_Pace.Click += new System.EventHandler(this.btnSkip_Pace_Click);
            // 
            // btnNext_Pace
            // 
            this.btnNext_Pace.BackColor = System.Drawing.Color.Blue;
            this.btnNext_Pace.Font = new System.Drawing.Font("Microsoft PhagsPa", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnNext_Pace.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.btnNext_Pace.Location = new System.Drawing.Point(1076, 341);
            this.btnNext_Pace.Name = "btnNext_Pace";
            this.btnNext_Pace.Size = new System.Drawing.Size(88, 34);
            this.btnNext_Pace.TabIndex = 6;
            this.btnNext_Pace.Text = "Next";
            this.btnNext_Pace.UseVisualStyleBackColor = false;
            this.btnNext_Pace.Click += new System.EventHandler(this.btnNext_Pace_Click);
            // 
            // label21
            // 
            this.label21.AutoSize = true;
            this.label21.Font = new System.Drawing.Font("Microsoft PhagsPa", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label21.Location = new System.Drawing.Point(832, 117);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(196, 15);
            this.label21.TabIndex = 5;
            this.label21.Text = "Please specify your allergies below...";
            // 
            // rtxtAllergies_Pace
            // 
            this.rtxtAllergies_Pace.Location = new System.Drawing.Point(835, 141);
            this.rtxtAllergies_Pace.Name = "rtxtAllergies_Pace";
            this.rtxtAllergies_Pace.Size = new System.Drawing.Size(299, 96);
            this.rtxtAllergies_Pace.TabIndex = 4;
            this.rtxtAllergies_Pace.Text = "";
            // 
            // cbAllergies_Pace
            // 
            this.cbAllergies_Pace.AutoSize = true;
            this.cbAllergies_Pace.Font = new System.Drawing.Font("Microsoft PhagsPa", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cbAllergies_Pace.Location = new System.Drawing.Point(835, 75);
            this.cbAllergies_Pace.Name = "cbAllergies_Pace";
            this.cbAllergies_Pace.Size = new System.Drawing.Size(210, 19);
            this.cbAllergies_Pace.TabIndex = 3;
            this.cbAllergies_Pace.Text = "If you have allergies, click the box...";
            this.cbAllergies_Pace.UseVisualStyleBackColor = true;
            // 
            // groupBox6
            // 
            this.groupBox6.Controls.Add(this.pbDeserts_Pace);
            this.groupBox6.Controls.Add(this.cbDesert5_Pace);
            this.groupBox6.Controls.Add(this.cbDesert4_Pace);
            this.groupBox6.Controls.Add(this.cbDesert3_Pace);
            this.groupBox6.Controls.Add(this.cbDesert2_Pace);
            this.groupBox6.Controls.Add(this.cbDesert1_Pace);
            this.groupBox6.Font = new System.Drawing.Font("Microsoft PhagsPa", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox6.Location = new System.Drawing.Point(6, 202);
            this.groupBox6.Name = "groupBox6";
            this.groupBox6.Size = new System.Drawing.Size(351, 186);
            this.groupBox6.TabIndex = 1;
            this.groupBox6.TabStop = false;
            this.groupBox6.Text = "Deserts";
            // 
            // pbDeserts_Pace
            // 
            this.pbDeserts_Pace.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pbDeserts_Pace.Location = new System.Drawing.Point(156, 48);
            this.pbDeserts_Pace.Name = "pbDeserts_Pace";
            this.pbDeserts_Pace.Size = new System.Drawing.Size(150, 119);
            this.pbDeserts_Pace.TabIndex = 6;
            this.pbDeserts_Pace.TabStop = false;
            // 
            // cbDesert5_Pace
            // 
            this.cbDesert5_Pace.AutoSize = true;
            this.cbDesert5_Pace.Location = new System.Drawing.Point(7, 148);
            this.cbDesert5_Pace.Name = "cbDesert5_Pace";
            this.cbDesert5_Pace.Size = new System.Drawing.Size(115, 19);
            this.cbDesert5_Pace.TabIndex = 5;
            this.cbDesert5_Pace.Text = "Apple Tarte Tatin";
            this.cbDesert5_Pace.UseVisualStyleBackColor = true;
            // 
            // cbDesert4_Pace
            // 
            this.cbDesert4_Pace.AutoSize = true;
            this.cbDesert4_Pace.Location = new System.Drawing.Point(7, 123);
            this.cbDesert4_Pace.Name = "cbDesert4_Pace";
            this.cbDesert4_Pace.Size = new System.Drawing.Size(85, 19);
            this.cbDesert4_Pace.TabIndex = 4;
            this.cbDesert4_Pace.Text = "Opera Cake";
            this.cbDesert4_Pace.UseVisualStyleBackColor = true;
            // 
            // cbDesert3_Pace
            // 
            this.cbDesert3_Pace.AutoSize = true;
            this.cbDesert3_Pace.Location = new System.Drawing.Point(7, 98);
            this.cbDesert3_Pace.Name = "cbDesert3_Pace";
            this.cbDesert3_Pace.Size = new System.Drawing.Size(92, 19);
            this.cbDesert3_Pace.TabIndex = 3;
            this.cbDesert3_Pace.Text = "Banoffee Pie";
            this.cbDesert3_Pace.UseVisualStyleBackColor = true;
            // 
            // cbDesert2_Pace
            // 
            this.cbDesert2_Pace.AutoSize = true;
            this.cbDesert2_Pace.Location = new System.Drawing.Point(7, 73);
            this.cbDesert2_Pace.Name = "cbDesert2_Pace";
            this.cbDesert2_Pace.Size = new System.Drawing.Size(90, 19);
            this.cbDesert2_Pace.TabIndex = 2;
            this.cbDesert2_Pace.Text = "Mille-Feuille";
            this.cbDesert2_Pace.UseVisualStyleBackColor = true;
            // 
            // cbDesert1_Pace
            // 
            this.cbDesert1_Pace.AutoSize = true;
            this.cbDesert1_Pace.Location = new System.Drawing.Point(7, 48);
            this.cbDesert1_Pace.Name = "cbDesert1_Pace";
            this.cbDesert1_Pace.Size = new System.Drawing.Size(119, 19);
            this.cbDesert1_Pace.TabIndex = 1;
            this.cbDesert1_Pace.Text = "Molten Lava Cake";
            this.cbDesert1_Pace.UseVisualStyleBackColor = true;
            this.cbDesert1_Pace.CheckedChanged += new System.EventHandler(this.cbDesert1_Pace_CheckedChanged);
            // 
            // groupBox4
            // 
            this.groupBox4.Controls.Add(this.pbMain_Pace);
            this.groupBox4.Controls.Add(this.cbMain8_Pace);
            this.groupBox4.Controls.Add(this.cbMain7_Pace);
            this.groupBox4.Controls.Add(this.cbMain6_Pace);
            this.groupBox4.Controls.Add(this.cbMain5_Pace);
            this.groupBox4.Controls.Add(this.cbMain4_Pace);
            this.groupBox4.Controls.Add(this.cbMain3_Pace);
            this.groupBox4.Controls.Add(this.cbMain2_Pace);
            this.groupBox4.Controls.Add(this.cbMain1_Pace);
            this.groupBox4.Font = new System.Drawing.Font("Microsoft PhagsPa", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox4.Location = new System.Drawing.Point(413, 54);
            this.groupBox4.Name = "groupBox4";
            this.groupBox4.Size = new System.Drawing.Size(360, 240);
            this.groupBox4.TabIndex = 1;
            this.groupBox4.TabStop = false;
            this.groupBox4.Text = "Main Courses(Entrees)";
            // 
            // pbMain_Pace
            // 
            this.pbMain_Pace.Location = new System.Drawing.Point(174, 60);
            this.pbMain_Pace.Name = "pbMain_Pace";
            this.pbMain_Pace.Size = new System.Drawing.Size(150, 119);
            this.pbMain_Pace.TabIndex = 9;
            this.pbMain_Pace.TabStop = false;
            // 
            // cbMain8_Pace
            // 
            this.cbMain8_Pace.AutoSize = true;
            this.cbMain8_Pace.Location = new System.Drawing.Point(6, 210);
            this.cbMain8_Pace.Name = "cbMain8_Pace";
            this.cbMain8_Pace.Size = new System.Drawing.Size(84, 19);
            this.cbMain8_Pace.TabIndex = 8;
            this.cbMain8_Pace.Text = "Coussoulet";
            this.cbMain8_Pace.UseVisualStyleBackColor = true;
            // 
            // cbMain7_Pace
            // 
            this.cbMain7_Pace.AutoSize = true;
            this.cbMain7_Pace.Location = new System.Drawing.Point(6, 185);
            this.cbMain7_Pace.Name = "cbMain7_Pace";
            this.cbMain7_Pace.Size = new System.Drawing.Size(115, 19);
            this.cbMain7_Pace.TabIndex = 7;
            this.cbMain7_Pace.Text = "Grilled Swordfish";
            this.cbMain7_Pace.UseVisualStyleBackColor = true;
            // 
            // cbMain6_Pace
            // 
            this.cbMain6_Pace.AutoSize = true;
            this.cbMain6_Pace.Location = new System.Drawing.Point(6, 160);
            this.cbMain6_Pace.Name = "cbMain6_Pace";
            this.cbMain6_Pace.Size = new System.Drawing.Size(138, 19);
            this.cbMain6_Pace.TabIndex = 6;
            this.cbMain6_Pace.Text = "Vegetarian Moussaka";
            this.cbMain6_Pace.UseVisualStyleBackColor = true;
            // 
            // cbMain5_Pace
            // 
            this.cbMain5_Pace.AutoSize = true;
            this.cbMain5_Pace.Location = new System.Drawing.Point(6, 135);
            this.cbMain5_Pace.Name = "cbMain5_Pace";
            this.cbMain5_Pace.Size = new System.Drawing.Size(133, 19);
            this.cbMain5_Pace.TabIndex = 5;
            this.cbMain5_Pace.Text = "Spaghetti Carbonara";
            this.cbMain5_Pace.UseVisualStyleBackColor = true;
            // 
            // cbMain4_Pace
            // 
            this.cbMain4_Pace.AutoSize = true;
            this.cbMain4_Pace.Location = new System.Drawing.Point(6, 110);
            this.cbMain4_Pace.Name = "cbMain4_Pace";
            this.cbMain4_Pace.Size = new System.Drawing.Size(123, 19);
            this.cbMain4_Pace.TabIndex = 4;
            this.cbMain4_Pace.Text = "Moules Marinieres";
            this.cbMain4_Pace.UseVisualStyleBackColor = true;
            // 
            // cbMain3_Pace
            // 
            this.cbMain3_Pace.AutoSize = true;
            this.cbMain3_Pace.Location = new System.Drawing.Point(6, 85);
            this.cbMain3_Pace.Name = "cbMain3_Pace";
            this.cbMain3_Pace.Size = new System.Drawing.Size(143, 19);
            this.cbMain3_Pace.TabIndex = 3;
            this.cbMain3_Pace.Text = "Stuffed Chicken Breast";
            this.cbMain3_Pace.UseVisualStyleBackColor = true;
            // 
            // cbMain2_Pace
            // 
            this.cbMain2_Pace.AutoSize = true;
            this.cbMain2_Pace.Location = new System.Drawing.Point(6, 60);
            this.cbMain2_Pace.Name = "cbMain2_Pace";
            this.cbMain2_Pace.Size = new System.Drawing.Size(92, 19);
            this.cbMain2_Pace.TabIndex = 2;
            this.cbMain2_Pace.Text = "Veal Marsala";
            this.cbMain2_Pace.UseVisualStyleBackColor = true;
            // 
            // cbMain1_Pace
            // 
            this.cbMain1_Pace.AutoSize = true;
            this.cbMain1_Pace.Location = new System.Drawing.Point(6, 35);
            this.cbMain1_Pace.Name = "cbMain1_Pace";
            this.cbMain1_Pace.Size = new System.Drawing.Size(57, 19);
            this.cbMain1_Pace.TabIndex = 1;
            this.cbMain1_Pace.Text = "Paella";
            this.cbMain1_Pace.UseVisualStyleBackColor = true;
            // 
            // groupBox3
            // 
            this.groupBox3.Controls.Add(this.pbAppetizers_Pace);
            this.groupBox3.Controls.Add(this.cbStarter5_Pace);
            this.groupBox3.Controls.Add(this.cbStarter4_Pace);
            this.groupBox3.Controls.Add(this.cbStarter3_Pace);
            this.groupBox3.Controls.Add(this.cbStarter2_Pace);
            this.groupBox3.Controls.Add(this.cbStarter1_Pace);
            this.groupBox3.Font = new System.Drawing.Font("Microsoft PhagsPa", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox3.Location = new System.Drawing.Point(6, 6);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Size = new System.Drawing.Size(351, 190);
            this.groupBox3.TabIndex = 0;
            this.groupBox3.TabStop = false;
            this.groupBox3.Text = "Appetizers (Starters)";
            // 
            // pbAppetizers_Pace
            // 
            this.pbAppetizers_Pace.Location = new System.Drawing.Point(156, 35);
            this.pbAppetizers_Pace.Name = "pbAppetizers_Pace";
            this.pbAppetizers_Pace.Size = new System.Drawing.Size(150, 119);
            this.pbAppetizers_Pace.TabIndex = 5;
            this.pbAppetizers_Pace.TabStop = false;
            // 
            // cbStarter5_Pace
            // 
            this.cbStarter5_Pace.AutoSize = true;
            this.cbStarter5_Pace.Location = new System.Drawing.Point(7, 135);
            this.cbStarter5_Pace.Name = "cbStarter5_Pace";
            this.cbStarter5_Pace.Size = new System.Drawing.Size(83, 19);
            this.cbStarter5_Pace.TabIndex = 4;
            this.cbStarter5_Pace.Text = "Crab Cakes";
            this.cbStarter5_Pace.UseVisualStyleBackColor = true;
            // 
            // cbStarter4_Pace
            // 
            this.cbStarter4_Pace.AutoSize = true;
            this.cbStarter4_Pace.Location = new System.Drawing.Point(7, 110);
            this.cbStarter4_Pace.Name = "cbStarter4_Pace";
            this.cbStarter4_Pace.Size = new System.Drawing.Size(139, 19);
            this.cbStarter4_Pace.TabIndex = 3;
            this.cbStarter4_Pace.Text = "Prosciutto and Melon";
            this.cbStarter4_Pace.UseVisualStyleBackColor = true;
            // 
            // cbStarter3_Pace
            // 
            this.cbStarter3_Pace.AutoSize = true;
            this.cbStarter3_Pace.Location = new System.Drawing.Point(7, 85);
            this.cbStarter3_Pace.Name = "cbStarter3_Pace";
            this.cbStarter3_Pace.Size = new System.Drawing.Size(107, 19);
            this.cbStarter3_Pace.TabIndex = 2;
            this.cbStarter3_Pace.Text = "Shrimp Cocktail";
            this.cbStarter3_Pace.UseVisualStyleBackColor = true;
            // 
            // cbStarter2_Pace
            // 
            this.cbStarter2_Pace.AutoSize = true;
            this.cbStarter2_Pace.Location = new System.Drawing.Point(6, 60);
            this.cbStarter2_Pace.Name = "cbStarter2_Pace";
            this.cbStarter2_Pace.Size = new System.Drawing.Size(66, 19);
            this.cbStarter2_Pace.TabIndex = 1;
            this.cbStarter2_Pace.Text = "Ceviche";
            this.cbStarter2_Pace.UseVisualStyleBackColor = true;
            // 
            // cbStarter1_Pace
            // 
            this.cbStarter1_Pace.AutoSize = true;
            this.cbStarter1_Pace.Location = new System.Drawing.Point(7, 35);
            this.cbStarter1_Pace.Name = "cbStarter1_Pace";
            this.cbStarter1_Pace.Size = new System.Drawing.Size(69, 19);
            this.cbStarter1_Pace.TabIndex = 0;
            this.cbStarter1_Pace.Text = "Arancini";
            this.cbStarter1_Pace.UseVisualStyleBackColor = true;
            // 
            // tabPage6
            // 
            this.tabPage6.BackColor = System.Drawing.Color.DarkGray;
            this.tabPage6.Controls.Add(this.btnBack1_Pace);
            this.tabPage6.Controls.Add(this.groupBox10);
            this.tabPage6.Controls.Add(this.groupBox9);
            this.tabPage6.Controls.Add(this.groupBox8);
            this.tabPage6.Controls.Add(this.groupBox7);
            this.tabPage6.Controls.Add(this.btnRemove_Pace);
            this.tabPage6.Controls.Add(this.btnSubmitOrder_Pace);
            this.tabPage6.Controls.Add(this.groupBox5);
            this.tabPage6.Location = new System.Drawing.Point(4, 23);
            this.tabPage6.Name = "tabPage6";
            this.tabPage6.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage6.Size = new System.Drawing.Size(1210, 411);
            this.tabPage6.TabIndex = 1;
            this.tabPage6.Text = "Drinks";
            // 
            // btnBack1_Pace
            // 
            this.btnBack1_Pace.BackColor = System.Drawing.Color.Red;
            this.btnBack1_Pace.Font = new System.Drawing.Font("Microsoft PhagsPa", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnBack1_Pace.ForeColor = System.Drawing.SystemColors.MenuBar;
            this.btnBack1_Pace.Location = new System.Drawing.Point(1138, 3);
            this.btnBack1_Pace.Name = "btnBack1_Pace";
            this.btnBack1_Pace.Size = new System.Drawing.Size(60, 30);
            this.btnBack1_Pace.TabIndex = 16;
            this.btnBack1_Pace.Text = "Food";
            this.btnBack1_Pace.UseVisualStyleBackColor = false;
            this.btnBack1_Pace.Click += new System.EventHandler(this.btnBack1_Pace_Click);
            // 
            // groupBox10
            // 
            this.groupBox10.Controls.Add(this.pbHotBev_Pace);
            this.groupBox10.Controls.Add(this.cbHotBev5_Pace);
            this.groupBox10.Controls.Add(this.cbHotBev4_Pace);
            this.groupBox10.Controls.Add(this.cbHotBev3_Pace);
            this.groupBox10.Controls.Add(this.cbHotBev2_Pace);
            this.groupBox10.Controls.Add(this.cbHotBev1_Pace);
            this.groupBox10.Font = new System.Drawing.Font("Microsoft PhagsPa", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox10.Location = new System.Drawing.Point(396, 212);
            this.groupBox10.Name = "groupBox10";
            this.groupBox10.Size = new System.Drawing.Size(335, 192);
            this.groupBox10.TabIndex = 14;
            this.groupBox10.TabStop = false;
            this.groupBox10.Text = "Hot Beverages";
            // 
            // pbHotBev_Pace
            // 
            this.pbHotBev_Pace.Location = new System.Drawing.Point(163, 37);
            this.pbHotBev_Pace.Name = "pbHotBev_Pace";
            this.pbHotBev_Pace.Size = new System.Drawing.Size(150, 119);
            this.pbHotBev_Pace.TabIndex = 10;
            this.pbHotBev_Pace.TabStop = false;
            // 
            // cbHotBev5_Pace
            // 
            this.cbHotBev5_Pace.AutoSize = true;
            this.cbHotBev5_Pace.Location = new System.Drawing.Point(15, 137);
            this.cbHotBev5_Pace.Name = "cbHotBev5_Pace";
            this.cbHotBev5_Pace.Size = new System.Drawing.Size(71, 19);
            this.cbHotBev5_Pace.TabIndex = 9;
            this.cbHotBev5_Pace.Text = "Espresso";
            this.cbHotBev5_Pace.UseVisualStyleBackColor = true;
            // 
            // cbHotBev4_Pace
            // 
            this.cbHotBev4_Pace.AutoSize = true;
            this.cbHotBev4_Pace.Location = new System.Drawing.Point(15, 112);
            this.cbHotBev4_Pace.Name = "cbHotBev4_Pace";
            this.cbHotBev4_Pace.Size = new System.Drawing.Size(70, 19);
            this.cbHotBev4_Pace.TabIndex = 8;
            this.cbHotBev4_Pace.Text = "Chai Tea";
            this.cbHotBev4_Pace.UseVisualStyleBackColor = true;
            // 
            // cbHotBev3_Pace
            // 
            this.cbHotBev3_Pace.AutoSize = true;
            this.cbHotBev3_Pace.Location = new System.Drawing.Point(15, 87);
            this.cbHotBev3_Pace.Name = "cbHotBev3_Pace";
            this.cbHotBev3_Pace.Size = new System.Drawing.Size(86, 19);
            this.cbHotBev3_Pace.TabIndex = 7;
            this.cbHotBev3_Pace.Text = "Oolong Tea";
            this.cbHotBev3_Pace.UseVisualStyleBackColor = true;
            // 
            // cbHotBev2_Pace
            // 
            this.cbHotBev2_Pace.AutoSize = true;
            this.cbHotBev2_Pace.Location = new System.Drawing.Point(15, 62);
            this.cbHotBev2_Pace.Name = "cbHotBev2_Pace";
            this.cbHotBev2_Pace.Size = new System.Drawing.Size(80, 19);
            this.cbHotBev2_Pace.TabIndex = 6;
            this.cbHotBev2_Pace.Text = "Macchiato";
            this.cbHotBev2_Pace.UseVisualStyleBackColor = true;
            // 
            // cbHotBev1_Pace
            // 
            this.cbHotBev1_Pace.AutoSize = true;
            this.cbHotBev1_Pace.Location = new System.Drawing.Point(15, 37);
            this.cbHotBev1_Pace.Name = "cbHotBev1_Pace";
            this.cbHotBev1_Pace.Size = new System.Drawing.Size(82, 19);
            this.cbHotBev1_Pace.TabIndex = 5;
            this.cbHotBev1_Pace.Text = "Americano";
            this.cbHotBev1_Pace.UseVisualStyleBackColor = true;
            // 
            // groupBox9
            // 
            this.groupBox9.Controls.Add(this.pictureBox8);
            this.groupBox9.Controls.Add(this.cbNonBev5_Pace);
            this.groupBox9.Controls.Add(this.cbNonBev4_Pace);
            this.groupBox9.Controls.Add(this.cbNonBev3_Vino);
            this.groupBox9.Controls.Add(this.cbNonBev2_Pace);
            this.groupBox9.Controls.Add(this.cbNonBev1_Pace);
            this.groupBox9.Font = new System.Drawing.Font("Microsoft PhagsPa", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox9.Location = new System.Drawing.Point(396, 0);
            this.groupBox9.Name = "groupBox9";
            this.groupBox9.Size = new System.Drawing.Size(335, 203);
            this.groupBox9.TabIndex = 12;
            this.groupBox9.TabStop = false;
            this.groupBox9.Text = "Non-Alcoholic Beverages";
            // 
            // pictureBox8
            // 
            this.pictureBox8.Location = new System.Drawing.Point(163, 48);
            this.pictureBox8.Name = "pictureBox8";
            this.pictureBox8.Size = new System.Drawing.Size(150, 119);
            this.pictureBox8.TabIndex = 10;
            this.pictureBox8.TabStop = false;
            // 
            // cbNonBev5_Pace
            // 
            this.cbNonBev5_Pace.AutoSize = true;
            this.cbNonBev5_Pace.Location = new System.Drawing.Point(13, 142);
            this.cbNonBev5_Pace.Name = "cbNonBev5_Pace";
            this.cbNonBev5_Pace.Size = new System.Drawing.Size(117, 19);
            this.cbNonBev5_Pace.TabIndex = 9;
            this.cbNonBev5_Pace.Text = "100% Apple Juice";
            this.cbNonBev5_Pace.UseVisualStyleBackColor = true;
            // 
            // cbNonBev4_Pace
            // 
            this.cbNonBev4_Pace.AutoSize = true;
            this.cbNonBev4_Pace.Location = new System.Drawing.Point(14, 117);
            this.cbNonBev4_Pace.Name = "cbNonBev4_Pace";
            this.cbNonBev4_Pace.Size = new System.Drawing.Size(61, 19);
            this.cbNonBev4_Pace.TabIndex = 8;
            this.cbNonBev4_Pace.Text = "Ice Tea";
            this.cbNonBev4_Pace.UseVisualStyleBackColor = true;
            // 
            // cbNonBev3_Vino
            // 
            this.cbNonBev3_Vino.AutoSize = true;
            this.cbNonBev3_Vino.Location = new System.Drawing.Point(14, 92);
            this.cbNonBev3_Vino.Name = "cbNonBev3_Vino";
            this.cbNonBev3_Vino.Size = new System.Drawing.Size(109, 19);
            this.cbNonBev3_Vino.TabIndex = 7;
            this.cbNonBev3_Vino.Text = "Sparkling Water";
            this.cbNonBev3_Vino.UseVisualStyleBackColor = true;
            // 
            // cbNonBev2_Pace
            // 
            this.cbNonBev2_Pace.AutoSize = true;
            this.cbNonBev2_Pace.Location = new System.Drawing.Point(14, 67);
            this.cbNonBev2_Pace.Name = "cbNonBev2_Pace";
            this.cbNonBev2_Pace.Size = new System.Drawing.Size(73, 19);
            this.cbNonBev2_Pace.TabIndex = 6;
            this.cbNonBev2_Pace.Text = "MockTail";
            this.cbNonBev2_Pace.UseVisualStyleBackColor = true;
            // 
            // cbNonBev1_Pace
            // 
            this.cbNonBev1_Pace.AutoSize = true;
            this.cbNonBev1_Pace.Location = new System.Drawing.Point(14, 42);
            this.cbNonBev1_Pace.Name = "cbNonBev1_Pace";
            this.cbNonBev1_Pace.Size = new System.Drawing.Size(81, 19);
            this.cbNonBev1_Pace.TabIndex = 5;
            this.cbNonBev1_Pace.Text = "Lemonade";
            this.cbNonBev1_Pace.UseVisualStyleBackColor = true;
            // 
            // groupBox8
            // 
            this.groupBox8.Controls.Add(this.pictureBox7);
            this.groupBox8.Controls.Add(this.cbWine5_Pace);
            this.groupBox8.Controls.Add(this.cbWine4_Pace);
            this.groupBox8.Controls.Add(this.cbWine3_Pace);
            this.groupBox8.Controls.Add(this.cbWine2_Pace);
            this.groupBox8.Controls.Add(this.cbWine1_Pace);
            this.groupBox8.Font = new System.Drawing.Font("Microsoft PhagsPa", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox8.Location = new System.Drawing.Point(3, 209);
            this.groupBox8.Name = "groupBox8";
            this.groupBox8.Size = new System.Drawing.Size(348, 192);
            this.groupBox8.TabIndex = 13;
            this.groupBox8.TabStop = false;
            this.groupBox8.Text = "Wines";
            // 
            // pictureBox7
            // 
            this.pictureBox7.Location = new System.Drawing.Point(161, 40);
            this.pictureBox7.Name = "pictureBox7";
            this.pictureBox7.Size = new System.Drawing.Size(150, 119);
            this.pictureBox7.TabIndex = 6;
            this.pictureBox7.TabStop = false;
            // 
            // cbWine5_Pace
            // 
            this.cbWine5_Pace.AutoSize = true;
            this.cbWine5_Pace.Location = new System.Drawing.Point(10, 137);
            this.cbWine5_Pace.Name = "cbWine5_Pace";
            this.cbWine5_Pace.Size = new System.Drawing.Size(90, 19);
            this.cbWine5_Pace.TabIndex = 9;
            this.cbWine5_Pace.Text = "Chardonnay";
            this.cbWine5_Pace.UseVisualStyleBackColor = true;
            // 
            // cbWine4_Pace
            // 
            this.cbWine4_Pace.AutoSize = true;
            this.cbWine4_Pace.Location = new System.Drawing.Point(10, 112);
            this.cbWine4_Pace.Name = "cbWine4_Pace";
            this.cbWine4_Pace.Size = new System.Drawing.Size(61, 19);
            this.cbWine4_Pace.TabIndex = 8;
            this.cbWine4_Pace.Text = "Merlot";
            this.cbWine4_Pace.UseVisualStyleBackColor = true;
            // 
            // cbWine3_Pace
            // 
            this.cbWine3_Pace.AutoSize = true;
            this.cbWine3_Pace.Location = new System.Drawing.Point(10, 87);
            this.cbWine3_Pace.Name = "cbWine3_Pace";
            this.cbWine3_Pace.Size = new System.Drawing.Size(67, 19);
            this.cbWine3_Pace.TabIndex = 7;
            this.cbWine3_Pace.Text = "Riesling";
            this.cbWine3_Pace.UseVisualStyleBackColor = true;
            // 
            // cbWine2_Pace
            // 
            this.cbWine2_Pace.AutoSize = true;
            this.cbWine2_Pace.Location = new System.Drawing.Point(10, 62);
            this.cbWine2_Pace.Name = "cbWine2_Pace";
            this.cbWine2_Pace.Size = new System.Drawing.Size(72, 19);
            this.cbWine2_Pace.TabIndex = 6;
            this.cbWine2_Pace.Text = "Prosecco";
            this.cbWine2_Pace.UseVisualStyleBackColor = true;
            // 
            // cbWine1_Pace
            // 
            this.cbWine1_Pace.AutoSize = true;
            this.cbWine1_Pace.Location = new System.Drawing.Point(10, 37);
            this.cbWine1_Pace.Name = "cbWine1_Pace";
            this.cbWine1_Pace.Size = new System.Drawing.Size(51, 19);
            this.cbWine1_Pace.TabIndex = 5;
            this.cbWine1_Pace.Text = "Rose";
            this.cbWine1_Pace.UseVisualStyleBackColor = true;
            // 
            // groupBox7
            // 
            this.groupBox7.Controls.Add(this.pbCocktails_Pace);
            this.groupBox7.Controls.Add(this.cbcocktail5_Pace);
            this.groupBox7.Controls.Add(this.cbcocktail4_Pace);
            this.groupBox7.Controls.Add(this.cbcocktail3_Pace);
            this.groupBox7.Controls.Add(this.cbcocktail2_Pace);
            this.groupBox7.Controls.Add(this.cbcocktail1_Pace);
            this.groupBox7.Font = new System.Drawing.Font("Microsoft PhagsPa", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox7.Location = new System.Drawing.Point(3, 0);
            this.groupBox7.Name = "groupBox7";
            this.groupBox7.Size = new System.Drawing.Size(348, 203);
            this.groupBox7.TabIndex = 11;
            this.groupBox7.TabStop = false;
            this.groupBox7.Text = "Cocktails";
            // 
            // pbCocktails_Pace
            // 
            this.pbCocktails_Pace.Location = new System.Drawing.Point(161, 48);
            this.pbCocktails_Pace.Name = "pbCocktails_Pace";
            this.pbCocktails_Pace.Size = new System.Drawing.Size(150, 119);
            this.pbCocktails_Pace.TabIndex = 5;
            this.pbCocktails_Pace.TabStop = false;
            // 
            // cbcocktail5_Pace
            // 
            this.cbcocktail5_Pace.AutoSize = true;
            this.cbcocktail5_Pace.Location = new System.Drawing.Point(7, 148);
            this.cbcocktail5_Pace.Name = "cbcocktail5_Pace";
            this.cbcocktail5_Pace.Size = new System.Drawing.Size(97, 19);
            this.cbcocktail5_Pace.TabIndex = 4;
            this.cbcocktail5_Pace.Text = "Whiskey Sour";
            this.cbcocktail5_Pace.UseVisualStyleBackColor = true;
            // 
            // cbcocktail4_Pace
            // 
            this.cbcocktail4_Pace.AutoSize = true;
            this.cbcocktail4_Pace.Location = new System.Drawing.Point(7, 123);
            this.cbcocktail4_Pace.Name = "cbcocktail4_Pace";
            this.cbcocktail4_Pace.Size = new System.Drawing.Size(88, 19);
            this.cbcocktail4_Pace.TabIndex = 3;
            this.cbcocktail4_Pace.Text = "Pina Colada";
            this.cbcocktail4_Pace.UseVisualStyleBackColor = true;
            // 
            // cbcocktail3_Pace
            // 
            this.cbcocktail3_Pace.AutoSize = true;
            this.cbcocktail3_Pace.Location = new System.Drawing.Point(7, 98);
            this.cbcocktail3_Pace.Name = "cbcocktail3_Pace";
            this.cbcocktail3_Pace.Size = new System.Drawing.Size(84, 19);
            this.cbcocktail3_Pace.TabIndex = 2;
            this.cbcocktail3_Pace.Text = "Manhattan";
            this.cbcocktail3_Pace.UseVisualStyleBackColor = true;
            // 
            // cbcocktail2_Pace
            // 
            this.cbcocktail2_Pace.AutoSize = true;
            this.cbcocktail2_Pace.Location = new System.Drawing.Point(7, 73);
            this.cbcocktail2_Pace.Name = "cbcocktail2_Pace";
            this.cbcocktail2_Pace.Size = new System.Drawing.Size(64, 19);
            this.cbcocktail2_Pace.TabIndex = 1;
            this.cbcocktail2_Pace.Text = "Martini";
            this.cbcocktail2_Pace.UseVisualStyleBackColor = true;
            // 
            // cbcocktail1_Pace
            // 
            this.cbcocktail1_Pace.AutoSize = true;
            this.cbcocktail1_Pace.Location = new System.Drawing.Point(7, 48);
            this.cbcocktail1_Pace.Name = "cbcocktail1_Pace";
            this.cbcocktail1_Pace.Size = new System.Drawing.Size(61, 19);
            this.cbcocktail1_Pace.TabIndex = 0;
            this.cbcocktail1_Pace.Text = "Mojito";
            this.cbcocktail1_Pace.UseVisualStyleBackColor = true;
            // 
            // btnRemove_Pace
            // 
            this.btnRemove_Pace.BackColor = System.Drawing.Color.Red;
            this.btnRemove_Pace.Font = new System.Drawing.Font("Microsoft PhagsPa", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnRemove_Pace.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.btnRemove_Pace.Location = new System.Drawing.Point(1076, 327);
            this.btnRemove_Pace.Name = "btnRemove_Pace";
            this.btnRemove_Pace.Size = new System.Drawing.Size(82, 44);
            this.btnRemove_Pace.TabIndex = 7;
            this.btnRemove_Pace.Text = "Remove Item(s)";
            this.btnRemove_Pace.UseVisualStyleBackColor = false;
            // 
            // btnSubmitOrder_Pace
            // 
            this.btnSubmitOrder_Pace.BackColor = System.Drawing.Color.Lime;
            this.btnSubmitOrder_Pace.Font = new System.Drawing.Font("Microsoft PhagsPa", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSubmitOrder_Pace.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.btnSubmitOrder_Pace.Location = new System.Drawing.Point(877, 327);
            this.btnSubmitOrder_Pace.Name = "btnSubmitOrder_Pace";
            this.btnSubmitOrder_Pace.Size = new System.Drawing.Size(83, 44);
            this.btnSubmitOrder_Pace.TabIndex = 6;
            this.btnSubmitOrder_Pace.Text = "Submit Order";
            this.btnSubmitOrder_Pace.UseVisualStyleBackColor = false;
            this.btnSubmitOrder_Pace.Click += new System.EventHandler(this.btnSubmitOrder_Pace_Click);
            // 
            // groupBox5
            // 
            this.groupBox5.Controls.Add(this.lbOrder_Pace);
            this.groupBox5.Font = new System.Drawing.Font("Microsoft PhagsPa", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox5.Location = new System.Drawing.Point(799, 33);
            this.groupBox5.Name = "groupBox5";
            this.groupBox5.Size = new System.Drawing.Size(405, 288);
            this.groupBox5.TabIndex = 5;
            this.groupBox5.TabStop = false;
            this.groupBox5.Text = "Order Summary";
            // 
            // lbOrder_Pace
            // 
            this.lbOrder_Pace.FormattingEnabled = true;
            this.lbOrder_Pace.ItemHeight = 15;
            this.lbOrder_Pace.Location = new System.Drawing.Point(7, 22);
            this.lbOrder_Pace.Name = "lbOrder_Pace";
            this.lbOrder_Pace.Size = new System.Drawing.Size(392, 244);
            this.lbOrder_Pace.TabIndex = 0;
            // 
            // btnBackPace_pg2
            // 
            this.btnBackPace_pg2.BackColor = System.Drawing.Color.Crimson;
            this.btnBackPace_pg2.Font = new System.Drawing.Font("Microsoft PhagsPa", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnBackPace_pg2.ForeColor = System.Drawing.SystemColors.Info;
            this.btnBackPace_pg2.Location = new System.Drawing.Point(1164, 446);
            this.btnBackPace_pg2.Name = "btnBackPace_pg2";
            this.btnBackPace_pg2.Size = new System.Drawing.Size(58, 27);
            this.btnBackPace_pg2.TabIndex = 0;
            this.btnBackPace_pg2.Text = "Back";
            this.btnBackPace_pg2.UseVisualStyleBackColor = false;
            this.btnBackPace_pg2.Click += new System.EventHandler(this.btnBackPace_pg2_Click);
            // 
            // tabPage4
            // 
            this.tabPage4.BackColor = System.Drawing.Color.Silver;
            this.tabPage4.BackgroundImage = global::Restaurant_Reservation_System_FinalProject_26.Properties.Resources.pace1;
            this.tabPage4.Controls.Add(this.btnBackPace_pg3);
            this.tabPage4.Controls.Add(this.groupBox2);
            this.tabPage4.Controls.Add(this.groupBox1);
            this.tabPage4.Location = new System.Drawing.Point(4, 23);
            this.tabPage4.Name = "tabPage4";
            this.tabPage4.Size = new System.Drawing.Size(1222, 476);
            this.tabPage4.TabIndex = 3;
            this.tabPage4.Text = "Payment";
            // 
            // btnBackPace_pg3
            // 
            this.btnBackPace_pg3.BackColor = System.Drawing.Color.Crimson;
            this.btnBackPace_pg3.Font = new System.Drawing.Font("Microsoft PhagsPa", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnBackPace_pg3.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.btnBackPace_pg3.Location = new System.Drawing.Point(1124, 409);
            this.btnBackPace_pg3.Name = "btnBackPace_pg3";
            this.btnBackPace_pg3.Size = new System.Drawing.Size(84, 41);
            this.btnBackPace_pg3.TabIndex = 8;
            this.btnBackPace_pg3.Text = "Back";
            this.btnBackPace_pg3.UseVisualStyleBackColor = false;
            this.btnBackPace_pg3.Click += new System.EventHandler(this.btnBackPace_pg3_Click);
            // 
            // groupBox2
            // 
            this.groupBox2.BackColor = System.Drawing.Color.Transparent;
            this.groupBox2.Controls.Add(this.btnPay_Pace);
            this.groupBox2.Controls.Add(this.lblSubTotal_Pace);
            this.groupBox2.Controls.Add(this.lblTotal_Pace);
            this.groupBox2.Controls.Add(this.label17);
            this.groupBox2.Controls.Add(this.lbSummary_Pace);
            this.groupBox2.Controls.Add(this.label19);
            this.groupBox2.Font = new System.Drawing.Font("Microsoft PhagsPa", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox2.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.groupBox2.Location = new System.Drawing.Point(592, 15);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(421, 441);
            this.groupBox2.TabIndex = 3;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Reservation Summary";
            // 
            // btnPay_Pace
            // 
            this.btnPay_Pace.BackColor = System.Drawing.Color.Blue;
            this.btnPay_Pace.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.btnPay_Pace.Location = new System.Drawing.Point(132, 394);
            this.btnPay_Pace.Name = "btnPay_Pace";
            this.btnPay_Pace.Size = new System.Drawing.Size(106, 41);
            this.btnPay_Pace.TabIndex = 7;
            this.btnPay_Pace.Text = "Pay";
            this.btnPay_Pace.UseVisualStyleBackColor = false;
            this.btnPay_Pace.Click += new System.EventHandler(this.btnPay_Pace_Click);
            // 
            // lblSubTotal_Pace
            // 
            this.lblSubTotal_Pace.AutoSize = true;
            this.lblSubTotal_Pace.Location = new System.Drawing.Point(70, 328);
            this.lblSubTotal_Pace.Name = "lblSubTotal_Pace";
            this.lblSubTotal_Pace.Size = new System.Drawing.Size(16, 15);
            this.lblSubTotal_Pace.TabIndex = 6;
            this.lblSubTotal_Pace.Text = "...";
            // 
            // lblTotal_Pace
            // 
            this.lblTotal_Pace.AutoSize = true;
            this.lblTotal_Pace.Location = new System.Drawing.Point(70, 365);
            this.lblTotal_Pace.Name = "lblTotal_Pace";
            this.lblTotal_Pace.Size = new System.Drawing.Size(16, 15);
            this.lblTotal_Pace.TabIndex = 5;
            this.lblTotal_Pace.Text = "...";
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Location = new System.Drawing.Point(6, 328);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(69, 15);
            this.label17.TabIndex = 4;
            this.label17.Text = "SubTotal  R:";
            // 
            // lbSummary_Pace
            // 
            this.lbSummary_Pace.FormattingEnabled = true;
            this.lbSummary_Pace.ItemHeight = 15;
            this.lbSummary_Pace.Location = new System.Drawing.Point(6, 21);
            this.lbSummary_Pace.Name = "lbSummary_Pace";
            this.lbSummary_Pace.Size = new System.Drawing.Size(409, 289);
            this.lbSummary_Pace.TabIndex = 3;
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.Location = new System.Drawing.Point(6, 365);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(67, 15);
            this.label19.TabIndex = 2;
            this.label19.Text = "Total        R:";
            // 
            // groupBox1
            // 
            this.groupBox1.BackColor = System.Drawing.Color.Transparent;
            this.groupBox1.Controls.Add(this.pictureBox4);
            this.groupBox1.Controls.Add(this.pictureBox3);
            this.groupBox1.Controls.Add(this.pictureBox2);
            this.groupBox1.Controls.Add(this.txtCVV_Pace);
            this.groupBox1.Controls.Add(this.label16);
            this.groupBox1.Controls.Add(this.txtExpirydate_Pace);
            this.groupBox1.Controls.Add(this.label15);
            this.groupBox1.Controls.Add(this.pbPace);
            this.groupBox1.Controls.Add(this.txtcrdNo_Pace);
            this.groupBox1.Controls.Add(this.label14);
            this.groupBox1.Controls.Add(this.txtcrdholder_Pace);
            this.groupBox1.Controls.Add(this.label13);
            this.groupBox1.Font = new System.Drawing.Font("Microsoft PhagsPa", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox1.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.groupBox1.Location = new System.Drawing.Point(21, 15);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(421, 380);
            this.groupBox1.TabIndex = 2;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Payment Details";
            // 
            // pictureBox4
            // 
            this.pictureBox4.BackgroundImage = global::Restaurant_Reservation_System_FinalProject_26.Properties.Resources.paypal;
            this.pictureBox4.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pictureBox4.Location = new System.Drawing.Point(201, 308);
            this.pictureBox4.Name = "pictureBox4";
            this.pictureBox4.Size = new System.Drawing.Size(65, 48);
            this.pictureBox4.TabIndex = 11;
            this.pictureBox4.TabStop = false;
            // 
            // pictureBox3
            // 
            this.pictureBox3.BackgroundImage = global::Restaurant_Reservation_System_FinalProject_26.Properties.Resources.mastercard;
            this.pictureBox3.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pictureBox3.Location = new System.Drawing.Point(112, 308);
            this.pictureBox3.Name = "pictureBox3";
            this.pictureBox3.Size = new System.Drawing.Size(59, 48);
            this.pictureBox3.TabIndex = 10;
            this.pictureBox3.TabStop = false;
            // 
            // pictureBox2
            // 
            this.pictureBox2.BackgroundImage = global::Restaurant_Reservation_System_FinalProject_26.Properties.Resources.visa;
            this.pictureBox2.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pictureBox2.Location = new System.Drawing.Point(28, 308);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(53, 48);
            this.pictureBox2.TabIndex = 9;
            this.pictureBox2.TabStop = false;
            // 
            // txtCVV_Pace
            // 
            this.txtCVV_Pace.Location = new System.Drawing.Point(157, 251);
            this.txtCVV_Pace.Name = "txtCVV_Pace";
            this.txtCVV_Pace.Size = new System.Drawing.Size(98, 22);
            this.txtCVV_Pace.TabIndex = 8;
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Font = new System.Drawing.Font("Microsoft PhagsPa", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label16.Location = new System.Drawing.Point(154, 234);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(30, 14);
            this.label16.TabIndex = 7;
            this.label16.Text = "CVV:";
            // 
            // txtExpirydate_Pace
            // 
            this.txtExpirydate_Pace.Location = new System.Drawing.Point(10, 251);
            this.txtExpirydate_Pace.Name = "txtExpirydate_Pace";
            this.txtExpirydate_Pace.Size = new System.Drawing.Size(98, 22);
            this.txtExpirydate_Pace.TabIndex = 6;
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Font = new System.Drawing.Font("Microsoft PhagsPa", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label15.Location = new System.Drawing.Point(7, 234);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(63, 14);
            this.label15.TabIndex = 5;
            this.label15.Text = "Expiry date:";
            // 
            // pbPace
            // 
            this.pbPace.Location = new System.Drawing.Point(10, 139);
            this.pbPace.Name = "pbPace";
            this.pbPace.Size = new System.Drawing.Size(42, 35);
            this.pbPace.TabIndex = 4;
            this.pbPace.TabStop = false;
            // 
            // txtcrdNo_Pace
            // 
            this.txtcrdNo_Pace.Location = new System.Drawing.Point(58, 152);
            this.txtcrdNo_Pace.Name = "txtcrdNo_Pace";
            this.txtcrdNo_Pace.Size = new System.Drawing.Size(272, 22);
            this.txtcrdNo_Pace.TabIndex = 3;
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Font = new System.Drawing.Font("Microsoft PhagsPa", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label14.Location = new System.Drawing.Point(7, 122);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(74, 14);
            this.label14.TabIndex = 2;
            this.label14.Text = "Card Number:";
            // 
            // txtcrdholder_Pace
            // 
            this.txtcrdholder_Pace.Location = new System.Drawing.Point(10, 55);
            this.txtcrdholder_Pace.Name = "txtcrdholder_Pace";
            this.txtcrdholder_Pace.Size = new System.Drawing.Size(320, 22);
            this.txtcrdholder_Pace.TabIndex = 1;
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Font = new System.Drawing.Font("Microsoft PhagsPa", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label13.Location = new System.Drawing.Point(7, 36);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(101, 14);
            this.label13.TabIndex = 0;
            this.label13.Text = "Cardholder\'s name:";
            // 
            // tabPage5
            // 
            this.tabPage5.BackColor = System.Drawing.Color.Silver;
            this.tabPage5.BackgroundImage = global::Restaurant_Reservation_System_FinalProject_26.Properties.Resources.pace1;
            this.tabPage5.Controls.Add(this.label18);
            this.tabPage5.Controls.Add(this.rtxtReview_Pace);
            this.tabPage5.Controls.Add(this.btnReview_Pace);
            this.tabPage5.Controls.Add(this.lbReview_Pace);
            this.tabPage5.Controls.Add(this.pictureBox5);
            this.tabPage5.Location = new System.Drawing.Point(4, 23);
            this.tabPage5.Name = "tabPage5";
            this.tabPage5.Size = new System.Drawing.Size(1222, 476);
            this.tabPage5.TabIndex = 4;
            this.tabPage5.Text = "Reviews";
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.BackColor = System.Drawing.Color.Transparent;
            this.label18.Font = new System.Drawing.Font("Microsoft PhagsPa", 11F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label18.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.label18.Location = new System.Drawing.Point(380, 323);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(248, 20);
            this.label18.TabIndex = 9;
            this.label18.Text = "Please leave a review down below:";
            // 
            // rtxtReview_Pace
            // 
            this.rtxtReview_Pace.Location = new System.Drawing.Point(384, 346);
            this.rtxtReview_Pace.Name = "rtxtReview_Pace";
            this.rtxtReview_Pace.Size = new System.Drawing.Size(413, 76);
            this.rtxtReview_Pace.TabIndex = 8;
            this.rtxtReview_Pace.Text = "";
            // 
            // btnReview_Pace
            // 
            this.btnReview_Pace.BackColor = System.Drawing.SystemColors.HotTrack;
            this.btnReview_Pace.Font = new System.Drawing.Font("Microsoft PhagsPa", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnReview_Pace.ForeColor = System.Drawing.SystemColors.Info;
            this.btnReview_Pace.Location = new System.Drawing.Point(821, 365);
            this.btnReview_Pace.Name = "btnReview_Pace";
            this.btnReview_Pace.Size = new System.Drawing.Size(95, 38);
            this.btnReview_Pace.TabIndex = 7;
            this.btnReview_Pace.Text = "Comment";
            this.btnReview_Pace.UseVisualStyleBackColor = false;
            // 
            // lbReview_Pace
            // 
            this.lbReview_Pace.FormattingEnabled = true;
            this.lbReview_Pace.ItemHeight = 14;
            this.lbReview_Pace.Location = new System.Drawing.Point(384, 16);
            this.lbReview_Pace.Name = "lbReview_Pace";
            this.lbReview_Pace.Size = new System.Drawing.Size(632, 270);
            this.lbReview_Pace.TabIndex = 6;
            // 
            // pictureBox5
            // 
            this.pictureBox5.BackgroundImage = global::Restaurant_Reservation_System_FinalProject_26.Properties.Resources.pace;
            this.pictureBox5.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pictureBox5.Location = new System.Drawing.Point(17, 16);
            this.pictureBox5.Name = "pictureBox5";
            this.pictureBox5.Size = new System.Drawing.Size(314, 228);
            this.pictureBox5.TabIndex = 5;
            this.pictureBox5.TabStop = false;
            // 
            // Form6
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.MenuHighlight;
            this.ClientSize = new System.Drawing.Size(1253, 522);
            this.Controls.Add(this.tabControl1);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "Form6";
            this.Text = "Pace";
            this.tabControl1.ResumeLayout(false);
            this.tabPage2.ResumeLayout(false);
            this.tabPage2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.tabPage3.ResumeLayout(false);
            this.tabControl2.ResumeLayout(false);
            this.tabPage1.ResumeLayout(false);
            this.tabPage1.PerformLayout();
            this.groupBox6.ResumeLayout(false);
            this.groupBox6.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pbDeserts_Pace)).EndInit();
            this.groupBox4.ResumeLayout(false);
            this.groupBox4.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pbMain_Pace)).EndInit();
            this.groupBox3.ResumeLayout(false);
            this.groupBox3.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pbAppetizers_Pace)).EndInit();
            this.tabPage6.ResumeLayout(false);
            this.groupBox10.ResumeLayout(false);
            this.groupBox10.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pbHotBev_Pace)).EndInit();
            this.groupBox9.ResumeLayout(false);
            this.groupBox9.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox8)).EndInit();
            this.groupBox8.ResumeLayout(false);
            this.groupBox8.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox7)).EndInit();
            this.groupBox7.ResumeLayout(false);
            this.groupBox7.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pbCocktails_Pace)).EndInit();
            this.groupBox5.ResumeLayout(false);
            this.tabPage4.ResumeLayout(false);
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbPace)).EndInit();
            this.tabPage5.ResumeLayout(false);
            this.tabPage5.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox5)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TabControl tabControl1;
        private System.Windows.Forms.TabPage tabPage2;
        private System.Windows.Forms.TabPage tabPage3;
        private System.Windows.Forms.TabPage tabPage4;
        private System.Windows.Forms.TabPage tabPage5;
        private System.Windows.Forms.Button btnSubmit_Pace;
        private System.Windows.Forms.TextBox txtRequest_Pace;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.TextBox txtOther_Pace;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.ComboBox cbReserveType_Pace;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.DateTimePicker dateTime_Pace;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.TextBox txtPhone_Pace;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.TextBox txtEmail_Pace;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.TextBox txtLName_Pace;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox txtFName_Pace;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.Button btnPay_Pace;
        private System.Windows.Forms.Label lblSubTotal_Pace;
        private System.Windows.Forms.Label lblTotal_Pace;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.ListBox lbSummary_Pace;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.PictureBox pictureBox4;
        private System.Windows.Forms.PictureBox pictureBox3;
        private System.Windows.Forms.PictureBox pictureBox2;
        private System.Windows.Forms.TextBox txtCVV_Pace;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.TextBox txtExpirydate_Pace;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.PictureBox pbPace;
        private System.Windows.Forms.TextBox txtcrdNo_Pace;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.TextBox txtcrdholder_Pace;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Button btnBackPace_pg3;
        private System.Windows.Forms.Button btnHomePace;
        private System.Windows.Forms.Button btnBackPace_pg2;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.RichTextBox rtxtReview_Pace;
        private System.Windows.Forms.Button btnReview_Pace;
        private System.Windows.Forms.ListBox lbReview_Pace;
        private System.Windows.Forms.PictureBox pictureBox5;
        private System.Windows.Forms.TabControl tabControl2;
        private System.Windows.Forms.TabPage tabPage1;
        private System.Windows.Forms.GroupBox groupBox6;
        private System.Windows.Forms.PictureBox pbDeserts_Pace;
        private System.Windows.Forms.CheckBox cbDesert5_Pace;
        private System.Windows.Forms.CheckBox cbDesert4_Pace;
        private System.Windows.Forms.CheckBox cbDesert3_Pace;
        private System.Windows.Forms.CheckBox cbDesert2_Pace;
        private System.Windows.Forms.CheckBox cbDesert1_Pace;
        private System.Windows.Forms.GroupBox groupBox4;
        private System.Windows.Forms.PictureBox pbMain_Pace;
        private System.Windows.Forms.CheckBox cbMain8_Pace;
        private System.Windows.Forms.CheckBox cbMain7_Pace;
        private System.Windows.Forms.CheckBox cbMain6_Pace;
        private System.Windows.Forms.CheckBox cbMain5_Pace;
        private System.Windows.Forms.CheckBox cbMain4_Pace;
        private System.Windows.Forms.CheckBox cbMain3_Pace;
        private System.Windows.Forms.CheckBox cbMain2_Pace;
        private System.Windows.Forms.CheckBox cbMain1_Pace;
        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.PictureBox pbAppetizers_Pace;
        private System.Windows.Forms.CheckBox cbStarter5_Pace;
        private System.Windows.Forms.CheckBox cbStarter4_Pace;
        private System.Windows.Forms.CheckBox cbStarter3_Pace;
        private System.Windows.Forms.CheckBox cbStarter2_Pace;
        private System.Windows.Forms.CheckBox cbStarter1_Pace;
        private System.Windows.Forms.TabPage tabPage6;
        private System.Windows.Forms.Button btnRemove_Pace;
        private System.Windows.Forms.Button btnSubmitOrder_Pace;
        private System.Windows.Forms.GroupBox groupBox5;
        private System.Windows.Forms.ListBox lbOrder_Pace;
        private System.Windows.Forms.Button btnNext_Pace;
        private System.Windows.Forms.Label label21;
        private System.Windows.Forms.RichTextBox rtxtAllergies_Pace;
        private System.Windows.Forms.CheckBox cbAllergies_Pace;
        private System.Windows.Forms.Button btnSkip_Pace;
        private System.Windows.Forms.GroupBox groupBox10;
        private System.Windows.Forms.PictureBox pbHotBev_Pace;
        private System.Windows.Forms.CheckBox cbHotBev5_Pace;
        private System.Windows.Forms.CheckBox cbHotBev4_Pace;
        private System.Windows.Forms.CheckBox cbHotBev3_Pace;
        private System.Windows.Forms.CheckBox cbHotBev2_Pace;
        private System.Windows.Forms.CheckBox cbHotBev1_Pace;
        private System.Windows.Forms.GroupBox groupBox9;
        private System.Windows.Forms.PictureBox pictureBox8;
        private System.Windows.Forms.CheckBox cbNonBev5_Pace;
        private System.Windows.Forms.CheckBox cbNonBev4_Pace;
        private System.Windows.Forms.CheckBox cbNonBev3_Vino;
        private System.Windows.Forms.CheckBox cbNonBev2_Pace;
        private System.Windows.Forms.CheckBox cbNonBev1_Pace;
        private System.Windows.Forms.GroupBox groupBox8;
        private System.Windows.Forms.PictureBox pictureBox7;
        private System.Windows.Forms.CheckBox cbWine5_Pace;
        private System.Windows.Forms.CheckBox cbWine4_Pace;
        private System.Windows.Forms.CheckBox cbWine3_Pace;
        private System.Windows.Forms.CheckBox cbWine2_Pace;
        private System.Windows.Forms.CheckBox cbWine1_Pace;
        private System.Windows.Forms.GroupBox groupBox7;
        private System.Windows.Forms.PictureBox pbCocktails_Pace;
        private System.Windows.Forms.CheckBox cbcocktail5_Pace;
        private System.Windows.Forms.CheckBox cbcocktail4_Pace;
        private System.Windows.Forms.CheckBox cbcocktail3_Pace;
        private System.Windows.Forms.CheckBox cbcocktail2_Pace;
        private System.Windows.Forms.CheckBox cbcocktail1_Pace;
        private System.Windows.Forms.Label lblNoOfSeats_Pace;
        private System.Windows.Forms.TextBox TxtNoOfGuests_Pace;
        private System.Windows.Forms.Button btnBack1_Pace;
        private System.Windows.Forms.ComboBox cbTime_Pace;
        private System.Windows.Forms.Label label20;
    }
}