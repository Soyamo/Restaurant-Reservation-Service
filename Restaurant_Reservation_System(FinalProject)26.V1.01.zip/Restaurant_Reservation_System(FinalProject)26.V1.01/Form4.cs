﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace Restaurant_Reservation_System_FinalProject_26
{
    public partial class Form4 : Form
    {
        string conString = @"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=|DataDirectory|\restaurant_service.mdf;Integrated Security=True";
        SqlDataAdapter adapter;
        SqlConnection cnn;
        DataSet ds;
        SqlCommand cmd;

        public Form4()
        {

        }

        public Form4(string firstName, string lastName)
        {
            InitializeComponent();
            tabControl1.SelectedIndex = 0;
            lblHomeUserName.Text = firstName + " " + lastName;
           
        }

        private void pbRes1_Click(object sender, EventArgs e)
        {
            Form5 Res1 = new Form5();
            Res1.Show();
            this.Hide();
        }

        private void pbRes2_Click(object sender, EventArgs e)
        {
            Form6 Res2 = new Form6();
            Res2.Show();
            this.Hide();
        }

        private void pbRes3_Click(object sender, EventArgs e)
        {
           Form7 Res3 = new Form7();
           Res3.Show();
           this.Hide();
        }

        private void btnHomeLogOff_Click(object sender, EventArgs e)
        {
            Form2 frm2 = new Form2();
            frm2.Show();
            this.Close();
        }

        private void Form4_Load(object sender, EventArgs e)
        {

        }
    }
}
