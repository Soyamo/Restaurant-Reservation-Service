﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Net.Mime.MediaTypeNames;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace Restaurant_Reservation_System_FinalProject_26
{
    public partial class Form6 : Form
    {
        public Form6()
        {
            InitializeComponent();
        }

        public Form6(string name, string surname, string email, string phone_number)
        {
            InitializeComponent();
            txtFName_Pace.Text = name;
            txtLName_Pace.Text = surname;
            txtEmail_Pace.Text = email;
            txtPhone_Pace.Text = phone_number;
        }

        private void btnSubmit_Pace_Click(object sender, EventArgs e)
        {
            tabControl1.SelectedTab = tabPage3;
        }

        private void btnPay_Pace_Click(object sender, EventArgs e)
        {
            tabControl1.SelectedTab = tabPage5;
        }

        private void btnBackPace_pg3_Click(object sender, EventArgs e)
        {
            tabControl1.SelectedTab = tabPage3;
        }

        private void btnHomePace_Click(object sender, EventArgs e)
        {
            Form4 frm4 = new Form4();
            frm4.Show();
            this.Close();
        }

        private void btnBackPace_pg2_Click(object sender, EventArgs e)
        {
            tabControl1.SelectedTab= tabPage2;
        }

        private void btnNext_Pace_Click(object sender, EventArgs e)
        {
            tabControl2.SelectedTab = tabPage6;
        }

        private void btnSubmitOrder_Pace_Click(object sender, EventArgs e)
        {
            tabControl1.SelectedTab = tabPage4;
        }

        private void btnSkip_Pace_Click(object sender, EventArgs e)
        {
            tabControl1.SelectedTab = tabPage4;
        }

        private void btnBack1_Pace_Click(object sender, EventArgs e)
        {
            tabControl2.SelectedTab= tabPage1;
        }

        private void cbDesert1_Pace_CheckedChanged(object sender, EventArgs e)
        {

        }
    }
}
